import Foundation

final class YlDashAutoRecoveryController {
  typealias Sample = YlDashAutoRecoveryPolicy.Sample
  typealias Scheduler = (Double, @escaping () -> Void) -> Void
  private(set) var policy = YlDashAutoRecoveryPolicy()
  private(set) var events: [[String: Any]] = []
  init(clock: @escaping () -> Double = { ProcessInfo.processInfo.systemUptime },
       schedule: @escaping Scheduler = { delay, action in DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: action) }) {}
  func invalidate() {}
  func resetForSource() {}
  func tick(_ sample: Sample?, prepare: @escaping YlOpenCoordinator.Preparation,
            currentSample: @escaping () -> Sample?, commit: @escaping YlOpenCoordinator.Commit) {}
}
