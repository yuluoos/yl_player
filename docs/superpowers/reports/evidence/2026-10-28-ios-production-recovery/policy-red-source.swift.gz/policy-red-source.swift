import Foundation

struct YlDashAutoRecoveryPolicy {
  struct Variant: Equatable {
    let id: String, width: Int, height: Int
    let bandwidth: Double
  }
  struct Sample {
    let time: Double, generation: UInt64, allowed: Bool
    let catalog: [Variant], current: Variant?
    let position: Double, remaining: Double, bufferAhead: Double
    let bytes: Int64, transfer: Double, requests: Int, overdue: Int
    var intentRevision: UInt64 = 0
    var credentialRevision: UInt64 = 0
  }
  struct Ticket {
    let id: UUID, generation: UInt64, attempt: Int, due: Double
    let intentRevision: UInt64, credentialRevision: UInt64
    let catalog: [Variant]
  }
  private(set) var attempts = 0
  private(set) var decision: [String: Any] = [:]
  mutating func invalidateIntent() {}
  mutating func observe(_ s: Sample) -> Ticket? { nil }
  func authorizes(_ ticket: Ticket, _ s: Sample) -> Bool { false }
  mutating func finish(_ ticket: Ticket) {}
}
