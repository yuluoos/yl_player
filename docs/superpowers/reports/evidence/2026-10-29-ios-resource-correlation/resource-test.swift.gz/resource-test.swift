  func testProxyResourceTokenIsStableOnlyWithinOneProxy() throws {
    let server = try DashHTTPServer(); defer { server.close() }
    server.handler = { _ in (200, [:], Data([1, 2])) }
    let lock = NSLock(); var rows: [[String: Any]] = []
    YlHlsMediaProxy.diagnosticRequestObserver = { row in lock.withLock { rows.append(row) } }
    defer { YlHlsMediaProxy.diagnosticRequestObserver = nil }
    let origin = server.url("/private?credential=secret")
    let first = try YlHlsMediaProxy(originURL: origin, headers: [:], configuration: .init(map: [:]))
    let second = try YlHlsMediaProxy(originURL: origin, headers: [:], configuration: .init(map: [:]))
    defer { first.cancelAll(); second.cancelAll() }
    var tokens: [String] = []
    for (proxy, target) in [(first, origin), (first, origin), (first, server.url("/other")), (second, origin)] {
      let done = expectation(description: "resource observation")
      URLSession.shared.dataTask(with: try proxy.proxyURL(for: target)) { data, _, error in
        XCTAssertNil(error); XCTAssertEqual(data, Data([1, 2])); done.fulfill()
      }.resume()
      wait(for: [done], timeout: 3)
      XCTAssertTrue(try XCTUnwrap(YlHlsMediaProxy.diagnosticRequestCapture).wait(timeout: 2))
      let row = try XCTUnwrap(lock.withLock { rows.last })
      let token = try XCTUnwrap(row["resourceToken"] as? String)
      XCTAssertEqual(token.count, 64)
      XCTAssertTrue(token.allSatisfy { "0123456789abcdef".contains($0) })
      tokens.append(token)
      let serialized = String(decoding: try JSONSerialization.data(withJSONObject: row), as: UTF8.self)
      for secret in ["secret", "credential", "private", "http:"] { XCTAssertFalse(serialized.contains(secret)) }
    }
    XCTAssertEqual(rows.count, 4)
    XCTAssertEqual(tokens[0], tokens[1], "Same URL within one proxy must be comparable")
    XCTAssertNotEqual(tokens[0], tokens[2], "Different resources must remain distinct")
    XCTAssertNotEqual(tokens[0], tokens[3], "Tokens must not link separate proxies")
  }

