sh /Users/runner/work/yl_player/yl_player/tool/check_apple_consumer.sh --platform macos --manager cocoapods --link
