sh /Users/runner/work/yl_player/yl_player/tool/check_apple_consumer.sh --platform ios --manager cocoapods --link
