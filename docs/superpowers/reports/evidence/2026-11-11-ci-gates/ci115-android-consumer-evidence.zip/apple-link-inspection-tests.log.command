python3 -B /home/runner/work/yl_player/yl_player/tool/consumer_fixtures/apple_flutter/test_link_inspection.py
