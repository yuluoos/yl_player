/home/runner/work/_temp/yl-consumers/android/android/gradlew -p /home/runner/work/_temp/yl-consumers/android/android :app:assembleDebug --stacktrace
