import 'mitv_observed_subscription_test.dart' as live;
import 'mitv_attempts_test.dart' as attempts;
import '../test/modules/live/features/live_attempt_diagnostics_test.dart' as diagnostics;
void main() { attempts.main(); live.main(); diagnostics.main(); }
