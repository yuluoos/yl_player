import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:integration_test/integration_test.dart';
import 'package:isar_community/isar.dart';
import 'package:tvs/app/init.dart';
import 'package:tvs/models/app_error.dart';
import 'package:tvs/models/app_settings.dart';
import 'package:tvs/models/live_channel.dart';
import 'package:tvs/models/play_history.dart';
import 'package:tvs/models/skip_setting.dart';
import 'package:tvs/models/subscription.dart';
import 'package:tvs/pages/live/widgets/live_player_view.dart';
import 'package:tvs/providers/audio/audio_session_bridge.dart';
import 'package:tvs/providers/isar_provider.dart';
import 'package:tvs/providers/live_player_provider.dart';
import 'package:tvs/utils/live_player_controller.dart';
import 'package:tvs/utils/live_source_manager.dart';
import 'package:tvs/utils/live_performance_trace.dart';
import 'package:yl_player/yl_player.dart';

import 'support/live_acceptance_capture.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  testWidgets('ten independent forbidden sources produce eight ordered diagnostics', (tester) async {
    final dir = await Directory.systemTemp.createTemp('mitv-attempts-');
    final database = await Isar.open([SubscriptionSchema, PlayHistorySchema, AppSettingsSchema, SkipSettingSchema], name:'attempts',directory:dir.path);
    final audio = AudioSessionBridge();
    await configureAudioSessionAtStartup(audio);
    final owner = ProviderContainer(retry: (_,_)=>null,overrides:[isarProvider.overrideWithValue(database),audioSessionBridgeProvider.overrideWithValue(audio)]);
    final server = await HttpServer.bind(InternetAddress.loopbackIPv4,0);
    final requests = <int>[];
    server.listen((request) async {
      requests.add(int.parse(request.uri.pathSegments.first));
      request.response.statusCode=403;
      await request.response.close();
    });
    final notifier = owner.read(livePlayerProvider.notifier);
    try {
      await tester.pumpWidget(UncontrolledProviderScope(container:owner, child:const MaterialApp(home:Scaffold(body:LivePlayerView()))));
      await notifier.play(LiveChannel(name:'Owned denials',urls:[for(var i=1;i<=10;i++) 'http://127.0.0.1:${server.port}/$i/index.m3u8?token=owned-sensitive'])).timeout(const Duration(seconds:90));
      final state=owner.read(livePlayerProvider) as LivePlayerError;
      debugPrint('P05_ATTEMPTS requests=$requests codes=${'network.http_forbidden'.allMatches(state.diagnostics).length}');
      expect(requests, [for(var i=1;i<=10;i++) i]);
      for(final value in [state.message,state.diagnostics]){
        expect(RegExp(r'源 (\d+)/10').allMatches(value).map((m)=>int.parse(m[1]!)).toList(),[1,2,3,4,5,6,7,8]);
        expect(value,contains('另有 2 次失败'));expect(value,isNot(contains('owned-sensitive')));expect(value,isNot(contains('127.0.0.1')));
      }
      expect('network.http_forbidden'.allMatches(state.diagnostics).length,8);
      expect('diagnosticId='.allMatches(state.diagnostics).length,8);
    } finally {
      await notifier.stop();await tester.pumpWidget(const SizedBox.shrink());owner.dispose();await notifier.disposalComplete;
      await server.close(force:true);await database.close();await dir.delete(recursive:true);
    }
  });
}
