import Foundation
import Network
import CryptoKit
struct YlHlsProxyConnectionCapture {
  let key: Data
  let observer: ([String: Any]) -> Void
  static func token(key: Data, localAddress: String?, localPort: NSNumber?,
    remoteAddress: String?, remotePort: NSNumber?) -> String? {
    guard let localAddress, let local = IPv4Address(localAddress),
      let remoteAddress, let remote = IPv4Address(remoteAddress),
      let localPort, let remotePort,
      let clientPort = UInt16(exactly: localPort.intValue), clientPort > 0,
      let serverPort = UInt16(exactly: remotePort.intValue), serverPort > 0 else { return nil }
    var bytes = Data("yl-connection-v1\n".utf8)
    bytes.append(local.rawValue)
    bytes.append(contentsOf: [UInt8(clientPort >> 8), UInt8(clientPort & 255)])
    bytes.append(remote.rawValue)
    bytes.append(contentsOf: [UInt8(serverPort >> 8), UInt8(serverPort & 255)])
    return HMAC<SHA256>.authenticationCode(for: bytes, using: SymmetricKey(data: key))
      .map { String(format: "%02x", $0) }.joined()
  }
}


let key = Data(String(repeating: "0123456789abcdef", count: 4).utf8)
let token = YlHlsProxyConnectionCapture.token(key: key, localAddress: "127.0.0.1", localPort: 54321, remoteAddress: "127.0.0.1", remotePort: 8080)
precondition(token == "b93437e984e46bdf0227cb06708354812141a850a8190a619cc23d4cfe6dbb8e")
precondition(YlHlsProxyConnectionCapture.token(key: key, localAddress: nil, localPort: nil, remoteAddress: nil, remotePort: nil) == nil)
precondition(YlHlsProxyConnectionCapture.token(key: key, localAddress: "::1", localPort: 54321, remoteAddress: "::1", remotePort: 8080) == nil)
print("Connection token vector and unavailable endpoints passed")
