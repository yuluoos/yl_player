import Foundation
import Network
import CryptoKit
let key = Data(String(repeating: "0123456789abcdef", count: 4).utf8)
let token = YlHlsProxyConnectionCapture.token(key: key, localAddress: "127.0.0.1", localPort: 54321, remoteAddress: "127.0.0.1", remotePort: 8080)
precondition(token == "b93437e984e46bdf0227cb06708354812141a850a8190a619cc23d4cfe6dbb8e")
precondition(YlHlsProxyConnectionCapture.token(key: key, localAddress: nil, localPort: nil, remoteAddress: nil, remotePort: nil) == nil)
precondition(YlHlsProxyConnectionCapture.token(key: key, localAddress: "::1", localPort: 54321, remoteAddress: "::1", remotePort: 8080) == nil)
print("Connection token vector and unavailable endpoints passed")
