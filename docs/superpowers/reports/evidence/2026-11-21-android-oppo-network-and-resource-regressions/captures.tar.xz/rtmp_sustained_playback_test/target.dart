import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:yl_player/yl_player.dart';
import 'rtmp_playback_test.dart' as rtmp;
import 'support/apple_strict_support.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  testWidgets('owned RTMP advances for ten minutes on one connection', (
    tester,
  ) async {
    final player = await appleController(tester);
    final before = await rtmp.control('normal');
    expect(before['active'], 0);
    final session = await rtmp.render(player);
    var lastPosition = player.state.timeline.position;
    final clock = Stopwatch()..start();
    while (clock.elapsed < const Duration(minutes: 10)) {
      await Future<void>.delayed(const Duration(seconds: 5));
      final state = player.state;
      expect(state.sessionId, session.id);
      expect(state.failure, isNull);
      expect(state.timeline.position, greaterThan(lastPosition));
      lastPosition = state.timeline.position;
      debugPrint(
        'YL_FOLLOWUP_SOAK=${jsonEncode({'elapsedMs': clock.elapsedMilliseconds, 'positionMs': lastPosition.inMilliseconds, 'status': state.status.name, 'rebufferCount': state.metrics.rebufferCount, 'sessionId': session.id.value})}',
      );
    }
    await player.stop();
    await stateWhere(player, (s) => s.status == YlPlaybackStatus.idle);
    final peer = await rtmp.peerWhere((s) => s['active'] == 0);
    expect(peer['accepted'], (before['accepted'] as int) + 1);
    expect(peer['closed'], (before['closed'] as int) + 1);
    expect(player.state.sessionId, isNull);
  }, timeout: const Timeout(Duration(minutes: 13)));
}
