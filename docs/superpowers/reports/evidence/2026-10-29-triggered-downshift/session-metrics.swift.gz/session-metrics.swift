import Foundation
final class Metrics: NSObject, URLSessionTaskDelegate {
  var rows: [[String:Any]] = []
  let invalidated=DispatchSemaphore(value:0)
  func urlSession(_ session: URLSession, didBecomeInvalidWithError error: Error?) { invalidated.signal() }
  func urlSession(_ session: URLSession, task: URLSessionTask, didFinishCollecting metrics: URLSessionTaskMetrics) {
    rows = metrics.transactionMetrics.map { m in
      ["requestHeaders": m.countOfRequestHeaderBytesSent, "requestBody": m.countOfRequestBodyBytesSent,
       "responseHeaders": m.countOfResponseHeaderBytesReceived, "responseBody": m.countOfResponseBodyBytesReceived,
       "requestStartPresent": m.requestStartDate != nil, "requestEndPresent": m.requestEndDate != nil,
       "responseStartPresent": m.responseStartDate != nil, "responseEndPresent": m.responseEndDate != nil,
       "reused": m.isReusedConnection]
    }
  }
}
let delegate=Metrics(), done=DispatchSemaphore(value:0)
let config=URLSessionConfiguration.ephemeral
config.timeoutIntervalForRequest=3;config.timeoutIntervalForResource=5
let session=URLSession(configuration:config,delegate:delegate,delegateQueue:nil)
var result:[String:Any]=[:]
let url=URL(string:CommandLine.arguments[1])!
session.dataTask(with:url) { data,response,error in
  result=["bodyBytes": data?.count ?? 0, "status": (response as? HTTPURLResponse)?.statusCode ?? 0,
          "errorCode": (error as NSError?)?.code ?? 0]
  done.signal()
}.resume()
if done.wait(timeout:.now()+8) == .timedOut { result=["probeTimedOut":true] }
session.finishTasksAndInvalidate()
result["sessionInvalidated"] = delegate.invalidated.wait(timeout:.now()+3) == .success
result["transactions"]=delegate.rows
let data=try JSONSerialization.data(withJSONObject:result,options:[.prettyPrinted,.sortedKeys])
print(String(data:data,encoding:.utf8)!)
