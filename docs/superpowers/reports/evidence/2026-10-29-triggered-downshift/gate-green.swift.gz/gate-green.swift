import Foundation
private struct AbrDiagnosticFaultGate {
  private var first: Double?, last: Double?, lastPosition: Double?
  private var identity: Int?, count = 0, fired = false
  mutating func observe(elapsed: Double, generation: Int, frames: Int, width: Int,
    position: Double, rate: Float, itemStatus: Int, seekPending: Bool,
    installedElapsed: Double?, attempts: Int) -> [String: Any]? {
    guard !fired else { return nil }
    guard let installedElapsed, installedElapsed.isFinite, elapsed.isFinite, position.isFinite,
      elapsed > installedElapsed, generation > 0, (1...2).contains(attempts),
      position >= 0, position <= 70, rate > 0, itemStatus == 1, !seekPending else {
      first = nil; last = nil; lastPosition = nil; count = 0; return nil
    }
    if frames <= 0 {
      if let last, elapsed - last > 0.5 { first = nil; count = 0 }
      return nil
    }
    guard width == 640 else { first = nil; last = nil; lastPosition = nil; count = 0; return nil }
    if identity != generation || last.map({ elapsed <= $0 || elapsed - $0 > 0.5 }) == true ||
        lastPosition.map({ position <= $0 }) == true {
      first = nil; count = 0
    }
    if first == nil { first = elapsed }
    identity = generation; last = elapsed; lastPosition = position; count += frames
    guard let first, elapsed - first >= 2, count >= 48 else { return nil }
    fired = true
    return ["version": 1, "elapsed": elapsed, "generation": generation, "position": position,
      "installedElapsed": installedElapsed, "attempts": attempts, "firstHighElapsed": first,
      "lastHighElapsed": elapsed, "highFrames": count]
  }
}
func check(_ condition: @autoclosure () -> Bool, _ description: String) {
  if !condition() { print("FAIL: \(description)"); exit(1) }
}
var gate = AbrDiagnosticFaultGate()
func sample(_ t: Double, _ g: Int = 1, _ w: Int = 640, _ pos: Double? = nil, _ install: Double? = 9) -> [String: Any]? {
  gate.observe(elapsed:t,generation:g,frames:1,width:w,position:pos ?? t,
    rate:1,itemStatus:1,seekPending:false,installedElapsed:install,attempts:2)
}
check(sample(8,1,640,nil,nil)==nil,"no installation")
for i in 0..<48 { check(sample(10+Double(i)/24)==nil,"requires two seconds") }
let ready=sample(12)
check(ready != nil,"published high baseline should trigger")
check(ready?["highFrames"] as? Int == 49,"count exact published frames")
check(sample(13)==nil,"only one trigger")
gate = AbrDiagnosticFaultGate()
for i in 0..<48 { _=sample(10+Double(i)/24) }
check(sample(12,1,320)==nil,"low breaks continuous high")
check(sample(13)==nil,"new high starts new baseline")
check(sample(14,2)==nil,"generation change resets")
check(sample(71,2,640,71)==nil,"leave observation time")
print("gate assertions passed")
