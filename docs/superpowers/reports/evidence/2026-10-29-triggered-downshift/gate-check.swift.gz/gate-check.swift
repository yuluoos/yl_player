func check(_ condition: @autoclosure () -> Bool, _ description: String) {
  if !condition() { print("FAIL: \(description)"); exit(1) }
}
private var gate = AbrDiagnosticFaultGate()
func sample(_ t: Double, _ g: Int = 1, _ w: Int = 640, _ pos: Double? = nil, _ install: Double? = 9) -> [String: Any]? {
  gate.observe(elapsed:t,generation:g,frames:1,width:w,position:pos ?? t,
    rate:1,itemStatus:1,seekPending:false,installedElapsed:install,attempts:2)
}
check(sample(8,1,640,nil,nil)==nil,"no installation")
for i in 0..<48 { check(sample(10+Double(i)/24)==nil,"requires two seconds") }
let ready=sample(12)
check(ready != nil,"published high baseline should trigger")
check(ready?["highFrames"] as? Int == 49,"count exact published frames")
check(sample(13)==nil,"only one trigger")
gate = AbrDiagnosticFaultGate()
for i in 0..<48 { _=sample(10+Double(i)/24) }
check(sample(12,1,320)==nil,"low breaks continuous high")
check(sample(13)==nil,"new high starts new baseline")
check(sample(14,2)==nil,"generation change resets")
check(sample(71,2,640,71)==nil,"leave observation time")
print("gate assertions passed")
