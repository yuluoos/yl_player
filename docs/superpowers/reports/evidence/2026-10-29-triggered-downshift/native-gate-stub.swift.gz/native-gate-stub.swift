private struct AbrDiagnosticFaultGate {
  mutating func observe(elapsed: Double, generation: Int, frames: Int, width: Int,
    position: Double, rate: Float, itemStatus: Int, seekPending: Bool,
    installedElapsed: Double?, attempts: Int) -> [String: Any]? { nil }
}
