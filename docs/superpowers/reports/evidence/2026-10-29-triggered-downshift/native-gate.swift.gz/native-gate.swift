private struct AbrDiagnosticFaultGate {
  private var first: Double?, last: Double?, lastPosition: Double?
  private var identity: Int?, count = 0, fired = false
  mutating func observe(elapsed: Double, generation: Int, frames: Int, width: Int,
    position: Double, rate: Float, itemStatus: Int, seekPending: Bool,
    installedElapsed: Double?, attempts: Int) -> [String: Any]? {
    guard !fired else { return nil }
    guard let installedElapsed, installedElapsed.isFinite, elapsed.isFinite, position.isFinite,
      elapsed > installedElapsed, generation > 0, (1...2).contains(attempts),
      position >= 0, position <= 70, rate > 0, itemStatus == 1, !seekPending else {
      first = nil; last = nil; lastPosition = nil; count = 0; return nil
    }
    if frames <= 0 {
      if let last, elapsed - last > 0.5 { first = nil; count = 0 }
      return nil
    }
    guard width == 640 else { first = nil; last = nil; lastPosition = nil; count = 0; return nil }
    if identity != generation || last.map({ elapsed <= $0 || elapsed - $0 > 0.5 }) == true ||
        lastPosition.map({ position <= $0 }) == true {
      first = nil; count = 0
    }
    if first == nil { first = elapsed }
    identity = generation; last = elapsed; lastPosition = position; count += frames
    guard let first, elapsed - first >= 2, count >= 48 else { return nil }
    fired = true
    return ["version": 1, "elapsed": elapsed, "generation": generation, "position": position,
      "installedElapsed": installedElapsed, "attempts": attempts, "firstHighElapsed": first,
      "lastHighElapsed": elapsed, "highFrames": count]
  }
}
