from pathlib import Path
import json,hashlib
sha=lambda b:hashlib.sha256(b).hexdigest();base=Path('/private/tmp/yl-preroll');root=Path('docs/superpowers/reports/evidence')
prior=json.loads(Path('/private/tmp/yl-prewarm/prior-evidence.json').read_text());prior.append(dict(group='2026-10-28-ios-candidate-preparation'))
verified=[]
for r in prior:
 d=root/r['group'];manifest=(d/'SHA256SUMS').read_bytes()
 if 'manifestSha256' in r:assert sha(manifest)==r['manifestSha256']
 for l in manifest.decode().splitlines():
  h,p=l.split('  ',1);assert sha((d/p).read_bytes())==h,(r['group'],p)
 verified.append(dict(group=r['group'],files=len(manifest.decode().splitlines()),manifestSha256=sha(manifest)))
(base/'prior-evidence.json').write_text(json.dumps(verified,indent=2)+'\n')
result={}
for group in ['media','fixed-media']:
 receipts=[(p.parent.name,json.loads(p.read_text())) for p in sorted((base/group).glob('*/receipt.json'))]
 assert len(receipts)==(2 if group=='media' else 4)
 for name,r in receipts:
  assert r['binaryHashes']==receipts[0][1]['binaryHashes'];assert r['binaryIdentityUnchanged'] and r['ownedProcessExited']
  if group=='fixed-media':assert r['passed']
 identity=json.loads((base/group/'source-identity.json').read_text())
 if group=='fixed-media':
  for p,h in identity.items():assert sha(Path(p).read_bytes())==h,p
 result[group]=dict(runs=[dict(name=n,passed=r['passed']) for n,r in receipts],binaryHashEntries=len(receipts[0][1]['binaryHashes']),sameBinaryWithinGroup=True,sourceIdentity=identity)
result['priorEvidenceGroups']=len(verified);result['priorManifestFiles']=sum(r['files'] for r in verified)
(base/'series-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(result['priorManifestFiles'])
