from pathlib import Path
import json,hashlib,subprocess,gzip,tarfile,io
base=Path('docs/superpowers/reports/evidence/2026-10-28-ios-route-pause')
sha=lambda b:hashlib.sha256(b).hexdigest()
lines=(base/'SHA256SUMS').read_text().splitlines()
for line in lines:
 h,p=line.split('  ',1);assert sha((base/p).read_bytes())==h,p
raw=json.loads((base/'raw-provenance.json').read_text());bundles=[]
for r in raw:
 p=base/r['archive']
 if 'bundleFiles' in r:
  if 'archiveParts' in r:
   data=b''.join((base/part['path']).read_bytes() for part in r['archiveParts']);assert sha(data)==r['archiveSha256']
   t=tarfile.open(fileobj=io.BytesIO(data),mode='r:gz')
  else:t=tarfile.open(p,'r:gz')
  with t:assert sum(m.isfile() for m in t.getmembers())==r['bundleFiles']
  bundles.append(r['source'])
 else:
  data=p.read_bytes();data=gzip.decompress(data) if p.name.endswith('.gz') else data
  assert sha(data)==r['sourceSha256'],r['source']
assert len(bundles)==10
before=json.loads(subprocess.check_output(['git','show','HEAD:tool/release_readiness/inventory.json'],text=True));after=json.loads(Path('tool/release_readiness/inventory.json').read_text())
for a,b in zip(before['rows'],after['rows']):
 for k in ['requirement','platform','implementation','verification','acceptance']:assert a[k]==b[k]
changed=[k for k in before['source']['files'] if before['source']['files'][k]!=after['source']['files'].get(k)]
assert changed==['packages/yl_player_apple/darwin/yl_player_apple/Sources/yl_player_apple/Engines/AvPlayer/YlAvPlayerBackend.swift']
assert set(before['source']['files'])==set(after['source']['files'])
result=dict(manifestEntriesVerified=len(lines),completeXcresultBundlesVerified=len(bundles),rawProvenanceEntriesVerified=len(raw),all102RowStatesUnchanged=True,changedProductionFiles=changed)
(base/'final-verification.json').write_text(json.dumps(result,indent=2)+'\n')
files=sorted(p for p in base.rglob('*') if p.is_file() and p.name!='SHA256SUMS');assert max(p.stat().st_size for p in files)<=16*1024*1024
(base/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+str(p.relative_to(base))+'\n' for p in files))
print(result)
