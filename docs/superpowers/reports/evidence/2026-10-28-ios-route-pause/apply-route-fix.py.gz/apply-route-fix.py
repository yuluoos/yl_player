from pathlib import Path
p=Path('packages/yl_player_apple/darwin/yl_player_apple/Sources/yl_player_apple/Engines/AvPlayer/YlAvPlayerBackend.swift');s=p.read_text()
s=s.replace('  private let player: AVPlayer\n','  private let player: AVPlayer\n  private let notificationCenter: NotificationCenter\n  #if os(iOS)\n  private var audioRouteObserver: NSObjectProtocol?\n  #endif\n')
s=s.replace('    self.player = player\n','    self.player = player\n    self.notificationCenter = notificationCenter\n')
s=s.replace('    timeControlObservation?.invalidate()\n    if let periodicObserver', '    timeControlObservation?.invalidate()\n    removeAudioRouteObserver()\n    if let periodicObserver',1)
s=s.replace('    let binding = callbackBinding\n    timeControlObservation =', '''    let binding = callbackBinding
    #if os(iOS)
    // AVPlayer pauses on route removal even when the app owns AVAudioSession.
    // Mirror that privacy pause into transport intent; it is not a network stall.
    audioRouteObserver = notificationCenter.addObserver(forName: AVAudioSession.routeChangeNotification,
      object: nil, queue: .main) { [weak self] notification in
        guard let self, self.callbackBinding === binding,
          let raw = notification.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt,
          AVAudioSession.RouteChangeReason(rawValue: raw) == .oldDeviceUnavailable,
          self.active, !self.disposed, !self.stopped,
          self.status != "completed", self.status != "error",
          self.playRequested || self.player.rate > 0 else { return }
        self.recordPlaybackDiagnostic(event: "audioRouteLoss")
        try? self.pause()
        self.status = "paused"
        self.emitState()
      }
    #endif
    timeControlObservation =''',1)
s=s.replace('  private func checkAlive() throws {', '''  private func removeAudioRouteObserver() {
    #if os(iOS)
    if let observer = audioRouteObserver { notificationCenter.removeObserver(observer) }
    audioRouteObserver = nil
    #endif
  }

  private func checkAlive() throws {''',1)
s=s.replace('  func dispose() {\n    airPlayObservation?', '  func dispose() {\n    removeAudioRouteObserver()\n    airPlayObservation?',1)
p.write_text(s)
Path('/private/tmp/yl-preroll/route-backend-green.swift').write_text(s)
