from pathlib import Path
import json,collections
base=Path('/private/tmp/yl-preroll');result={}
for root in [base/'media',base/'fixed-media']:
 for p in sorted(root.glob('*/receipt.json')):
  d=p.parent;r=json.loads(p.read_text());rows=[json.loads(l) for l in (d/'rows.jsonl').read_text().splitlines()]
  policy=[json.loads(l) for l in (d/'policy-decisions.jsonl').read_text().splitlines()]
  signals=set();action=root/(d.name+'-action.json')
  def walk(x):
   if isinstance(x,dict):
    for k,v in x.items():
     if k=='emittedOutput':signals.update(l for l in v.splitlines() if 'signal=' in l or '[YLPlayer][AVPlayer]' in l or '[YL-ABR] backendFailure' in l)
     elif isinstance(v,(list,dict)):walk(v)
   elif isinstance(x,list):
    for v in x:walk(v)
  if action.exists():walk(json.loads(action.read_text()))
  transitions=[];previous=None
  for row in rows:
   key=[row.get(k) for k in ['backendStatus','rate','timeControlStatus','width','backendFailureCode','likelyToKeepUp']]
   if key!=previous:transitions.append({k:row.get(k) for k in ['elapsed','position','backendStatus','rate','timeControlStatus','width','backendFailureCode','likelyToKeepUp','proxy','loadedRanges']})
   previous=key
  result[d.name]=dict(passed=r['passed'],identity=r.get('binaryIdentityUnchanged'),cleanup=r.get('ownedProcessExited'),policy=r.get('policyObservation'),continuity=r.get('continuityObservation'),end=rows[-1],signals=sorted(signals),transitions=transitions,windows=[r for r in policy if r.get('windowBitrate') is not None])
(base/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
for k,v in result.items():print(k,v['passed'],v['end']['position'],v['policy']['attempts'],v['continuity']['replacementBoundaries'],v['signals'])
