from pathlib import Path
import subprocess,json,time,hashlib
root=Path.cwd();base=Path('/private/tmp/yl-preroll');out=base/'fixed-media';out.mkdir(exist_ok=False)
planned=[('fixed-original-1','down-and-recover-v1'),('fixed-original-2','down-and-recover-v1'),('fixed-auto-1','stall-headroom-zero-latency-diagnostic-v1'),('fixed-auto-2','stall-headroom-zero-latency-diagnostic-v1')]
(out/'planned.json').write_text(json.dumps(planned,indent=2)+'\n')
files=list(json.loads((base/'media/source-identity.json').read_text()))
identity={}
for name in files:
 p=Path(name);data=p.read_bytes();identity[name]=hashlib.sha256(data).hexdigest();dest=base/'fixed-source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
(out/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n');results=[]
for name,profile in planned:
 for p,h in identity.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
 cmd=['python3','-B','tool/playback_network/abr_accesslog.py','--products','/private/tmp/yl-boundary-device-build/Build/Products','--directory',str(out/name),'--physical-device','00008140-000C49CC3493001C','--owned-host','192.168.50.196','--duration-seconds','120','--profile',profile,'--recovery-action','auto-reload']
 if name.startswith('fixed-auto'):cmd+=['--profiles',str(base/'latency-profiles.json')]
 print('START',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('x') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,exitCode=p.returncode,seconds=time.monotonic()-start));(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,p.returncode,flush=True)
 for kind,c in [('tests',['get','test-results','summary']),('action',['get','log','--type','action'])]:
  x=subprocess.run(['xcrun','xcresulttool',*c,'--path',str(out/(name+'.xcresult'))],capture_output=True,text=True)
  (out/(name+'-'+kind+'.json')).write_text(x.stdout)
 if p.returncode:break
