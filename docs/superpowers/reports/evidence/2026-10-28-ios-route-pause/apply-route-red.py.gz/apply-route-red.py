from pathlib import Path
import sys
p=Path('tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift');s=p.read_text();s=s.replace('  @MainActor func testCandidateMetadataPreparationRejectsExpiredAndFailedAssets()',Path('/private/tmp/yl-preroll/route-test.swift').read_text()+'  @MainActor func testCandidateMetadataPreparationRejectsExpiredAndFailedAssets()');p.write_text(s)
sys.path.insert(0,'tool/consumer_fixtures/apple_flutter');from media_delivery_fixture_adapter import native_test_source
for platform in ['ios','macos']:Path('packages/yl_player/example/'+platform+'/RunnerTests/'+p.name).write_bytes(native_test_source(p))
p=Path('tool/consumer_fixtures/apple_flutter/main_example_tests.py');p.write_text(p.read_text().replace("'ios': 828", "'ios': 829"))
p=Path('packages/yl_player_apple/darwin/yl_player_apple/Sources/yl_player_apple/Engines/AvPlayer/YlAvPlayerBackend.swift');s=p.read_text().replace('    player: AVPlayer = AVPlayer(),','    player: AVPlayer = AVPlayer(),\n    notificationCenter: NotificationCenter = .default,');p.write_text(s)
Path('/private/tmp/yl-preroll/route-backend-red.swift').write_text(s)
