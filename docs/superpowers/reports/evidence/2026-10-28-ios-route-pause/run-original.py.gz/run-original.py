from pathlib import Path
import subprocess,json,time,hashlib,shutil
root=Path.cwd();base=Path('/private/tmp/yl-preroll');out=base/'media';out.mkdir(exist_ok=False)
planned=[('frozen-auto-1','down-and-recover-v1'),('frozen-auto-2','down-and-recover-v1')]
(out/'planned.json').write_text(json.dumps(planned,indent=2)+'\n')
shutil.copyfile('/private/tmp/yl-device-followup/latency-profiles.json',base/'latency-profiles.json')
files=['tool/playback_network/abr_accesslog.py','tool/playback_network/abr_device.py','tool/playback_network/network_profile.py','tool/playback_network/profiles.json','tool/playback_network/prepare_fixture.py','tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift','packages/yl_player/example/ios/RunnerTests/YlDashResourceLoaderTests.swift']+[str(p) for p in (root/'packages/yl_player_apple/darwin/yl_player_apple/Sources/yl_player_apple').rglob('*.swift') if p.name in ['YlHlsMediaProxy.swift','YlHlsResourceLoader.swift','YlAvPlayerBackend.swift']]
identity={}
for name in files:
 p=Path(name);p=p.relative_to(root) if p.is_absolute() else p
 data=p.read_bytes();identity[str(p)]=hashlib.sha256(data).hexdigest();dest=base/'capture-source'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
(out/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
results=[]
for name,profile in planned:
 cmd=['python3','-B','tool/playback_network/abr_accesslog.py','--products','/private/tmp/yl-boundary-device-build/Build/Products','--directory',str(out/name),'--physical-device','00008140-000C49CC3493001C','--owned-host','192.168.50.196','--duration-seconds','120','--profile',profile,'--recovery-action','auto-reload']
 if name.startswith('latency'):cmd+=['--profiles',str(base/'latency-profiles.json')]
 print('START',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  try:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=360);code=p.returncode
  except subprocess.TimeoutExpired:code=124
 results.append(dict(name=name,command=cmd,exitCode=code,seconds=time.monotonic()-start));(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,code,flush=True)
 for kind,command in [('tests',['get','test-results','summary']),('action',['get','log','--type','action'])]:
  x=subprocess.run(['xcrun','xcresulttool',*command,'--path',str(out/(name+'.xcresult'))],capture_output=True,text=True,timeout=45)
  (out/(name+'-'+kind+'.json')).write_text(x.stdout);(out/(name+'-'+kind+'-exit.json')).write_text(json.dumps(dict(exitCode=x.returncode,stderr=x.stderr))+'\n')
 if code:break # Preserve failure; inspect before running a dependent repeat.
