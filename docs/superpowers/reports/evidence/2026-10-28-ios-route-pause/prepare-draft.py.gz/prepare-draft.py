from pathlib import Path
import shutil
base=Path('/private/tmp/yl-preroll');shutil.copytree('tool/playback_network',base/'draft-network')
p=base/'draft-network/test_abr_accesslog.py';s=p.read_text();needle='    def test_candidate_preparation_requires_native_echo_and_rejects_mixed_modes(self):'
s=s.replace(needle,'''    def test_preroll_requires_owned_auto_and_native_echo(self):
        args = SimpleNamespace(recovery_action='auto-reload', duration_seconds=120,
                               direct_hls_control=False, candidate_preparation='item-preroll')
        self.assertEqual(abr_accesslog.candidate_preparation(args), 'item-preroll')
        abr_accesslog.validate_candidate_preparation([dict(candidatePreparation='item-preroll')], 'item-preroll')
        for rows in [[{}], [dict(candidatePreparation='asset-metadata')],
                     [dict(candidatePreparation='item-preroll'), {}]]:
            with self.assertRaises(ValueError):
                abr_accesslog.validate_candidate_preparation(rows, 'item-preroll')
        args.direct_hls_control = True
        with self.assertRaises(ValueError):
            abr_accesslog.candidate_preparation(args)

'''+needle);p.write_text(s)
p=Path('tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift');s=p.read_text()
helper='''// Diagnostic only: the final backend still performs its exact resume seek.
private enum AbrDiagnosticPreroll {
  @MainActor static func prepare(_ asset: AVURLAsset, position: CMTime, deadlineUptime: Double,
    allowed: () -> Bool, cancelPending: () -> Void) async
    -> (outcome: String, item: AVPlayerItem?, detached: Bool, stage: String) {
    return ("ready", AVPlayerItem(asset: asset), true, "ready")
  }
}

'''
s=s.replace('private enum AbrDiagnosticCaptureURL {',helper+'private enum AbrDiagnosticCaptureURL {')
test='''  @MainActor func testPrerollCandidateAbortsExpiredDeniedAndRevokedIntent() async {
    let absent = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".mp4")
    for (deadline, allowed, expected) in [(ProcessInfo.processInfo.systemUptime - 1, true, "timedOut"),
                                         (ProcessInfo.processInfo.systemUptime + 2, false, "cancelled")] {
      var cleanups = 0
      let result = await AbrDiagnosticPreroll.prepare(AVURLAsset(url: absent), position: .zero,
        deadlineUptime: deadline, allowed: { allowed }, cancelPending: { cleanups += 1 })
      XCTAssertEqual(result.outcome, expected); XCTAssertNil(result.item)
      XCTAssertTrue(result.detached); XCTAssertEqual(cleanups, 1)
    }
    let started = expectation(description: "preroll candidate enters resource loader")
    let cancelled = expectation(description: "revoked intent releases loader")
    let held = AbrHeldMetadataLoader(started: started, cancelled: cancelled)
    let asset = AVURLAsset(url: URL(string: "yl-preroll-test://owned/master.m3u8")!)
    asset.resourceLoader.setDelegate(held, queue: DispatchQueue(label: "yl.preroll.cancel-test"))
    var intent = true
    let loading = Task { @MainActor in
      await AbrDiagnosticPreroll.prepare(asset, position: .zero,
        deadlineUptime: ProcessInfo.processInfo.systemUptime + 2,
        allowed: { intent }, cancelPending: { held.cancelAll() })
    }
    await fulfillment(of: [started], timeout: 1)
    intent = false
    let result = await loading.value
    XCTAssertEqual(result.outcome, "cancelled"); XCTAssertNil(result.item)
    XCTAssertTrue(result.detached)
    await fulfillment(of: [cancelled], timeout: 1)
    XCTAssertEqual(held.cancellationState.pending, 0)
    XCTAssertEqual(held.cancellationState.owner, 1)
    XCTAssertGreaterThan(held.cancellationState.terminated, 0)
    withExtendedLifetime(held) {}
  }

'''
s=s.replace('  @MainActor func testCandidateMetadataPreparationRejectsExpiredAndFailedAssets()',test+'  @MainActor func testCandidateMetadataPreparationRejectsExpiredAndFailedAssets()')
(base/'native-red.swift').write_text(s)
