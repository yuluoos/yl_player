import Foundation
import Network
final class YlHlsProxyRequestTrace {
  private let lock = NSLock()
  private var sealed = false
  private var downstreamFinished = false
  private var taskPending = false
  private var values: [String: Any]
  private let observer: ([String: Any]) -> Void
  let correlationID: String
  init(proxyID: String, requestID: Int, resourceToken: String? = nil, observer: @escaping ([String: Any]) -> Void) {
    self.observer = observer
    let correlationID = UUID().uuidString
    self.correlationID = correlationID
    values = ["version": 5, "metrics": NSNull(), "correlationID": correlationID, "proxyID": proxyID, "requestID": Double(requestID),
      "admission": ProcessInfo.processInfo.systemUptime,
      "bodyBytes": 0.0, "sentBodyBytes": 0.0, "bodyCallbacks": 0.0,
      "sendCount": 0.0, "sendCompletions": 0.0, "sendFailures": 0.0,
      "sendWaitSum": 0.0, "sendWaitMax": 0.0]
    if let resourceToken { values["version"] = 7; values["resourceToken"] = resourceToken }
  }
  private func update(allowAfterDownstream: Bool = false, _ action: (inout [String: Any], Double) -> Void) {
    lock.withLock {
      guard !sealed && (allowAfterDownstream || !downstreamFinished) else { return }
      action(&values, ProcessInfo.processInfo.systemUptime)
    }
  }
  // Date pairs stay within the Foundation clock; never subtract them from uptime.
  static func interval(from start: Date?, to end: Date?) -> Double? {
    guard let start, let end else { return nil }
    let seconds = end.timeIntervalSince(start)
    return seconds.isFinite && seconds >= 0 ? seconds : nil
  }
  // 0 valid, 1 missing start, 2 missing end, 3 both missing, 4 invalid pair.
  // Only categorical reasons leave Foundation; no absolute dates or identities.
  static func intervalState(from start: Date?, to end: Date?) -> Int {
    guard let start else { return end == nil ? 3 : 1 }
    guard let end else { return 2 }
    return interval(from: start, to: end) == nil ? 4 : 0
  }
  // Preserve unavailable sentinels instead of presenting them as measured zero.
  static func reportedByteCount(_ value: Int64) -> Any {
    value >= 0 ? value as Any : NSNull()
  }
  func metrics(_ metrics: URLSessionTaskMetrics) {
    func duration(_ start: Date?, _ end: Date?) -> Any {
      Self.interval(from: start, to: end).map { $0 as Any } ?? NSNull()
    }
    let transactions: [[String: Any]] = metrics.transactionMetrics.prefix(32).map { t in
      let protocolCode: Int
      switch t.networkProtocolName {
      case "http/1.0", "http/1.1": protocolCode = 1
      case "h2": protocolCode = 2
      case "h3": protocolCode = 3
      default: protocolCode = 0
      }
      let states = ["fetchSeconds": Self.intervalState(from: t.fetchStartDate, to: t.responseEndDate),
        "fetchToRequestSeconds": Self.intervalState(from: t.fetchStartDate, to: t.requestStartDate),
        "dnsSeconds": Self.intervalState(from: t.domainLookupStartDate, to: t.domainLookupEndDate),
        "connectSeconds": Self.intervalState(from: t.connectStartDate, to: t.connectEndDate),
        "tlsSeconds": Self.intervalState(from: t.secureConnectionStartDate, to: t.secureConnectionEndDate),
        "requestSeconds": Self.intervalState(from: t.requestStartDate, to: t.requestEndDate),
        "responseWaitSeconds": Self.intervalState(from: t.requestEndDate, to: t.responseStartDate),
        "responseSeconds": Self.intervalState(from: t.responseStartDate, to: t.responseEndDate)]
      let transportBytes: [String: Any] = [
        "requestHeaders": Self.reportedByteCount(t.countOfRequestHeaderBytesSent),
        "requestBody": Self.reportedByteCount(t.countOfRequestBodyBytesSent),
        "responseHeaders": Self.reportedByteCount(t.countOfResponseHeaderBytesReceived),
        "responseBody": Self.reportedByteCount(t.countOfResponseBodyBytesReceived)]
      return ["transportBytes": transportBytes, "durationStates": states, "fetchSeconds": duration(t.fetchStartDate, t.responseEndDate),
        "fetchToRequestSeconds": duration(t.fetchStartDate, t.requestStartDate),
        "dnsSeconds": duration(t.domainLookupStartDate, t.domainLookupEndDate),
        "connectSeconds": duration(t.connectStartDate, t.connectEndDate),
        "tlsSeconds": duration(t.secureConnectionStartDate, t.secureConnectionEndDate),
        "requestSeconds": duration(t.requestStartDate, t.requestEndDate),
        "responseWaitSeconds": duration(t.requestEndDate, t.responseStartDate),
        "responseSeconds": duration(t.responseStartDate, t.responseEndDate),
        "reused": t.isReusedConnection ? 1 : 0, "protocolCode": protocolCode,
        "fetchType": t.resourceFetchType.rawValue]
    }
    update(allowAfterDownstream: true) { v, _ in
      v["metrics"] = ["version": 3, "taskSeconds": duration(metrics.taskInterval.start, metrics.taskInterval.end),
        "transactionCount": metrics.transactionMetrics.count, "redirectCount": metrics.redirectCount,
        "truncated": metrics.transactionMetrics.count > 32 ? 1 : 0, "transactions": transactions]
    }
  }
  func point(_ name: String) { update { $0[name] = $1 } }
  func response(status: Int, serverID: Int?) {
    update { v, now in
      v["response"] = now; v["httpStatus"] = Double(status)
      if let serverID, serverID > 0 && serverID <= 10000 { v["serverRequestID"] = Double(serverID) }
    }
  }
  func body(bytes: Int) {
    update { v, now in
      if v["firstBody"] == nil { v["firstBody"] = now }
      v["lastBody"] = now
      v["bodyBytes"] = (v["bodyBytes"] as? Double ?? 0) + Double(bytes)
      v["bodyCallbacks"] = (v["bodyCallbacks"] as? Double ?? 0) + 1
    }
  }
  func enqueue() -> Double {
    let now = ProcessInfo.processInfo.systemUptime
    update { v, _ in
      if v["firstSend"] == nil { v["firstSend"] = now }
      v["lastSend"] = now; v["sendCount"] = (v["sendCount"] as? Double ?? 0) + 1
    }
    return now
  }
  func sent(started: Double?, bytes: Int, failed: Bool) {
    update { v, now in
      v["lastSendComplete"] = now
      v["sendCompletions"] = (v["sendCompletions"] as? Double ?? 0) + 1
      v["sendFailures"] = (v["sendFailures"] as? Double ?? 0) + (failed ? 1 : 0)
      if !failed { v["sentBodyBytes"] = (v["sentBodyBytes"] as? Double ?? 0) + Double(bytes) }
      if let started {
        let wait = max(0, now - started)
        v["sendWaitSum"] = (v["sendWaitSum"] as? Double ?? 0) + wait
        v["sendWaitMax"] = max(v["sendWaitMax"] as? Double ?? 0, wait)
      }
    }
  }
  func attachTask() {
    lock.withLock { if !sealed && !downstreamFinished { taskPending = true } }
  }
  private func completedRow() -> [String: Any]? {
    guard !sealed && downstreamFinished && !taskPending else { return nil }
    sealed = true; values["terminal"] = ProcessInfo.processInfo.systemUptime
    return values
  }
  func taskCompleted(outcome: Int) {
    let row = lock.withLock { () -> [String: Any]? in
      guard !sealed && taskPending else { return nil }
      taskPending = false
      values["taskComplete"] = ProcessInfo.processInfo.systemUptime
      values["taskOutcome"] = outcome
      return completedRow()
    }
    if let row { observer(row) }
  }
  // First transport termination wins: 0 non-cancel, 1 proxy invalidated,
  // 2 incomplete-request EOF, 3 downstream error, 4 other local close.
  // v7 sources: 0 no recorded cancellation error, 1 state.failed, 2 request receive,
  // 3 admitted-request monitor receive. This is the first recorded terminal
  // callback, not proof of the underlying peer's intent or physical ordering.
  func finish(outcome: Int, cancelCause: Int = 4, cancelSource: Int = 0, error: NWError? = nil) {
    let row = lock.withLock { () -> [String: Any]? in
      guard !sealed && !downstreamFinished else { return nil }
      downstreamFinished = true
      values["downstreamTerminal"] = ProcessInfo.processInfo.systemUptime
      values["outcome"] = Double(outcome)
      values["cancelCause"] = outcome == 1 ? cancelCause : 0
      if values["version"] as? Int == 7 {
        let recordsError = outcome == 1 && cancelCause == 3
        var domain = 0, code = 0
        if recordsError {
          switch error {
          case .posix(let value): domain = 1; code = Int(value.rawValue)
          case .dns(let value): domain = 2; code = Int(value)
          case .tls(let value): domain = 3; code = Int(value)
          default: domain = 4
          }
        }
        values["cancelSource"] = recordsError ? cancelSource : 0
        values["cancelErrorDomain"] = domain
        values["cancelErrorCode"] = code
      }
      return completedRow()
    }
    if let row { observer(row) }
  }
}

var rows: [[String: Any]] = []
let trace = YlHlsProxyRequestTrace(proxyID: "owned", requestID: 1) { rows.append($0) }
trace.attachTask()
trace.taskCompleted(outcome: 1)
let ownerLock = NSLock()
ownerLock.lock()
// Current cancelAll captures the trace and revokes ownership under this lock.
let revokedTrace = trace
ownerLock.unlock()
// A competing close can now record its generic cause before cancelAll finishes.
trace.finish(outcome: 1, cancelCause: 4)
revokedTrace.finish(outcome: 1, cancelCause: 1)
if rows.count != 1 || rows[0]["cancelCause"] as? Int != 1 {
  print("FAIL: ownership was revoked by cancelAll, but the recorded cause is", rows.first?["cancelCause"] ?? "missing")
  exit(1)
}
