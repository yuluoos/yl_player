
func sample(_ t: Double, high: Bool = false) -> YlDashAutoRecoveryPolicy.Sample {
 let low = YlDashAutoRecoveryPolicy.Variant(id: "low", width:320,height:180,bandwidth:400000)
 let highVariant = YlDashAutoRecoveryPolicy.Variant(id:"high",width:640,height:360,bandwidth:764000)
 return .init(time:t,generation:0,allowed:true,catalog:[low,highVariant],current:high ? highVariant:low,position:t,remaining:200-t,bufferAhead:10,bytes:Int64(t*200000),transfer:t,requests:Int(t*4),overdue:1)
}
var policy=YlDashAutoRecoveryPolicy()
for t in [0.0,1,9,17] { _ = policy.observe(sample(t,high:t==0)) }
let ticket=policy.observe(sample(17.5))!
policy.finish(ticket)
for t in [18.0,26,34] { _ = policy.observe(sample(t)) }
if policy.attempts != 1 { print("FAIL: second reservation before 30-second cooldown, attempts",policy.attempts); exit(1) }
print("PASS")
