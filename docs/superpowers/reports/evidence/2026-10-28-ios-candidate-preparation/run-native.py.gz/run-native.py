from pathlib import Path
import subprocess,json,sys
out=Path('/private/tmp/yl-prewarm');kind=sys.argv[1]
selected=['-only-testing:RunnerTests/'+c for c in ['YlDashResourceLoaderTests','YlAppleSessionTests','YlApplePublicationTests','YlNetworkByteSourceTests']]
if kind=='device':
 manifest=list(Path('/private/tmp/yl-boundary-device-build/Build/Products').glob('*.xctestrun'));assert len(manifest)==1
 cmd=['xcodebuild','test-without-building','-quiet','-xctestrun',str(manifest[0]),'-destination','platform=iOS,id=00008140-000C49CC3493001C']
else:
 cmd=['caffeinate','-udis','xcodebuild','test','-quiet','-workspace','packages/yl_player/example/macos/Runner.xcworkspace','-scheme','Runner','-configuration','Debug','-destination','platform=macOS,arch=arm64','-derivedDataPath','/private/tmp/yl-continuity-macos','CODE_SIGNING_ALLOWED=NO']
cmd+=['-parallel-testing-enabled','NO','-resultBundlePath',str(out/(kind+'-contracts.xcresult')),*selected]
(out/(kind+'-contracts-command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
with (out/(kind+'-contracts.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
(out/(kind+'-contracts-result.json')).write_text(json.dumps(dict(exitCode=p.returncode))+'\n')
r=subprocess.run(['xcrun','xcresulttool','get','test-results','summary','--path',str(out/(kind+'-contracts.xcresult'))],capture_output=True,text=True);(out/(kind+'-contracts-summary.json')).write_text(r.stdout);print(kind,p.returncode)
