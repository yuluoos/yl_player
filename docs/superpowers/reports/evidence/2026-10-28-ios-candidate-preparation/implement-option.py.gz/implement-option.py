from pathlib import Path
p=Path('/private/tmp/yl-prewarm/draft-network/abr_accesslog.py');s=p.read_text();marker='def run(args):'
helpers='''def candidate_preparation(args):
    mode = getattr(args, 'candidate_preparation', 'manifest-only')
    if mode not in ('manifest-only', 'asset-playable'):
        raise ValueError('invalid candidate preparation')
    if mode == 'asset-playable' and (getattr(args, 'recovery_action', 'none') != 'auto-reload' or
            getattr(args, 'duration_seconds', 40) != 120 or getattr(args, 'direct_hls_control', False)):
        raise ValueError('candidate preparation requires managed 120s automatic diagnostic')
    return mode


def validate_candidate_preparation(rows, expected):
    if expected not in ('manifest-only', 'asset-playable') or not rows or not all(
            isinstance(row, dict) and row.get('candidatePreparation', 'manifest-only') == expected
            for row in rows):
        raise ValueError('native candidate preparation does not match request')


'''
s=s.replace(marker,helpers+marker)
s=s.replace("        receipt['autoScenario'] = auto_scenario", "        receipt['autoScenario'] = auto_scenario\n        preparation_mode = candidate_preparation(args)\n        receipt['candidatePreparation'] = preparation_mode")
s=s.replace('            YL_ABR_PROBE_AUTO_SCENARIO=auto_scenario,','            YL_ABR_PROBE_AUTO_SCENARIO=auto_scenario,\n            YL_ABR_PROBE_CANDIDATE_PREPARATION=preparation_mode,')
s=s.replace("        receipt['observation']=summarize(rows,", "        validate_candidate_preparation(rows, preparation_mode)\n        receipt['observation']=summarize(rows,")
s=s.replace("    p.add_argument('--direct-hls-control',action='store_true',", "    p.add_argument('--candidate-preparation', choices=('manifest-only', 'asset-playable'), default='manifest-only',\n                   help='owned diagnostic only; requires native mode echo and unchanged ticket revalidation')\n    p.add_argument('--direct-hls-control',action='store_true',")
p.write_text(s)
