from pathlib import Path
import json,hashlib,subprocess
base=Path('/private/tmp/yl-prewarm');out={}
for group in ['media','candidates']:
 receipts=[(p.parent.name,json.loads(p.read_text())) for p in sorted((base/group).glob('*/receipt.json'))]
 assert len(receipts)==(3 if group=='media' else 5)
 first=receipts[0][1]['binaryHashes']
 for name,r in receipts:
  assert r['binaryHashes']==first
  assert r['binaryIdentityUnchanged'] and r['passed']
 identity=json.loads((base/group/'source-identity.json').read_text())
 out[group]={'runs':[n for n,r in receipts],'binaryHashEntries':len(first),'sameBinaryWithinGroup':True,'captureSource':identity}
 if group=='candidates':
  for p,h in identity.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
  out[group]['captureSourceMatchesFinal']=True
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
assert all(not p.startswith('packages/') or '/example/' in p for p in changed)
out['noProductionSourceChanges']=True
out['native']={}
for platform in ['device','macos']:
 s=json.loads((base/(platform+'-contracts-summary.json')).read_text())
 assert s['passedTests']==131 and s['failedTests']==s['skippedTests']==0
 out['native'][platform]={k:s[k] for k in ['passedTests','failedTests','skippedTests','result']}
(base/'series-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
