from pathlib import Path
s=Path('/private/tmp/yl-prewarm/native-red.swift').read_text()
s=s.replace('''    "loaded"
  }
}

private enum AbrDiagnosticCaptureURL''','''    guard deadlineUptime.isFinite else { return "failed" }
    guard !Task.isCancelled else { return "cancelled" }
    guard ProcessInfo.processInfo.systemUptime < deadlineUptime else { return "timedOut" }
    asset.loadValuesAsynchronously(forKeys: ["playable"], completionHandler: {})
    while !Task.isCancelled {
      guard ProcessInfo.processInfo.systemUptime < deadlineUptime else {
        asset.cancelLoading(); return "timedOut"
      }
      var error: NSError?
      switch asset.statusOfValue(forKey: "playable", error: &error) {
      case .loaded:
        if asset.isPlayable { return "loaded" }
        asset.cancelLoading(); return "unplayable"
      case .failed:
        asset.cancelLoading(); return "failed"
      case .cancelled:
        asset.cancelLoading(); return "cancelled"
      case .unknown, .loading:
        try? await Task.sleep(nanoseconds: 10_000_000)
      @unknown default:
        asset.cancelLoading(); return "failed"
      }
    }
    asset.cancelLoading(); return "cancelled"
  }
}

private enum AbrDiagnosticCaptureURL''')
s=s.replace('''    // Preserve the historical managed probe's preparation-before-player order.''','''    let candidatePreparation = env["YL_ABR_PROBE_CANDIDATE_PREPARATION"] ?? "manifest-only"
    guard ["manifest-only", "asset-playable"].contains(candidatePreparation),
      candidatePreparation == "manifest-only" || (recoveryAction == "auto-reload" && !direct && programmeSeconds == 120) else {
      XCTFail("Invalid candidate preparation diagnostic"); return
    }
    // Preserve the historical managed probe's preparation-before-player order.''')
s=s.replace('''        "recoveryAction": recoveryAction, "recoveryAttempt":''','''        "candidatePreparation": candidatePreparation,
        "recoveryAction": recoveryAction, "recoveryAttempt":''')
old='''          event["preparationCompletedElapsed"] = ProcessInfo.processInfo.systemUptime - started
          if automaticPolicy.authorizes(ticket, automaticSample()) && player.currentItem === item {
            try XCTUnwrap(backend).replaceActiveDash(source: source, prepared: replacement)
            event["outcome"] = "installed"; event["itemChanged"] = player.currentItem !== item
          } else { replacement.discard(); event["outcome"] = "cancelled" }'''
new='''          event["manifestPreparedElapsed"] = ProcessInfo.processInfo.systemUptime - started
          var preparationSucceeded = true
          if candidatePreparation == "asset-playable" {
            // An already invalidated ticket must not start speculative loading.
            if automaticPolicy.authorizes(ticket, automaticSample()) && player.currentItem === item {
              let warmupStarted = ProcessInfo.processInfo.systemUptime
              event["warmupStartedElapsed"] = warmupStarted - started
              event["warmupFramesBefore"] = frameCount
              event["warmupPositionBefore"] = finite(CMTimeGetSeconds(player.currentTime()))
              let outcome = await AbrDiagnosticCandidatePreparation.loadPlayable(replacement.asset,
                deadlineUptime: min(warmupStarted + 2, started + ticket.due + 5))
              event["warmupOutcome"] = outcome
              event["warmupCompletedElapsed"] = ProcessInfo.processInfo.systemUptime - started
              event["warmupFramesAfter"] = frameCount
              event["warmupPositionAfter"] = finite(CMTimeGetSeconds(player.currentTime()))
              event["warmupOldItemRetained"] = player.currentItem === item
              preparationSucceeded = outcome == "loaded"
            } else { event["warmupOutcome"] = "skippedIneligible" }
          }
          event["preparationCompletedElapsed"] = ProcessInfo.processInfo.systemUptime - started
          if !preparationSucceeded {
            replacement.discard(); event["outcome"] = "preparationFailed"
          } else if automaticPolicy.authorizes(ticket, automaticSample()) && player.currentItem === item {
            try XCTUnwrap(backend).replaceActiveDash(source: source, prepared: replacement)
            event["outcome"] = "installed"; event["itemChanged"] = player.currentItem !== item
          } else { replacement.discard(); event["outcome"] = "cancelled" }'''
assert old in s;s=s.replace(old,new)
Path('/private/tmp/yl-prewarm/native-green.swift').write_text(s)
