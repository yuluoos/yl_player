from pathlib import Path
import subprocess,json,time,hashlib
base=Path('/private/tmp/yl-prewarm');out=base/'candidates';out.mkdir(exist_ok=False)
planned=[('normal-1','manifest-only','normal'),('warm-1','asset-metadata','normal'),('normal-2','manifest-only','normal'),('warm-2','asset-metadata','normal'),('warm-pause','asset-metadata','pause-first')]
(out/'planned.json').write_text(json.dumps(planned,indent=2)+'\n')
files=['tool/playback_network/abr_accesslog.py','tool/playback_network/abr_device.py','tool/playback_network/network_profile.py','tool/playback_network/profiles.json','tool/playback_network/prepare_fixture.py','tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift','packages/yl_player/example/ios/RunnerTests/YlDashResourceLoaderTests.swift']
identity={}
for name in files:
 data=Path(name).read_bytes();identity[name]=hashlib.sha256(data).hexdigest();p=base/'candidate-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
(out/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
results=[]
for name,mode,scenario in planned:
 assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity.items())
 cmd=['python3','-B','tool/playback_network/abr_accesslog.py','--products','/private/tmp/yl-boundary-device-build/Build/Products','--directory',str(out/name),'--physical-device','00008140-000C49CC3493001C','--owned-host','192.168.50.196','--duration-seconds','120','--profiles',str(base/'latency-profiles.json'),'--profile','stall-headroom-zero-latency-diagnostic-v1','--recovery-action','auto-reload','--auto-scenario',scenario,'--candidate-preparation',mode]
 print('START',name,flush=True);started=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  try:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=360);code=p.returncode
  except subprocess.TimeoutExpired:code=124
 results.append(dict(name=name,command=cmd,exitCode=code,seconds=time.monotonic()-started));(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,code,flush=True)
 for kind,command in [('tests',['get','test-results','summary']),('action',['get','log','--type','action'])]:
  x=subprocess.run(['xcrun','xcresulttool',*command,'--path',str(out/(name+'.xcresult'))],capture_output=True,text=True,timeout=45)
  (out/(name+'-'+kind+'.json')).write_text(x.stdout);(out/(name+'-'+kind+'-exit.json')).write_text(json.dumps(dict(exitCode=x.returncode,stderr=x.stderr))+'\n')
 if code:break
