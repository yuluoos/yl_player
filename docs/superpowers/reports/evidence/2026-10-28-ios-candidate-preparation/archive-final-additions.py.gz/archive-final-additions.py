from pathlib import Path
import json,gzip,hashlib
src=Path('/private/tmp/yl-prewarm');dst=Path('docs/superpowers/reports/evidence/2026-10-28-ios-candidate-preparation')
provenance=json.loads((dst/'raw-provenance.json').read_text());known={r['source']:r for r in provenance}
for p in sorted(src.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(src)
 if any(part.endswith('.xcresult') for part in rel.parts):continue
 if 'private' in p.name or p.name=='power-events-tail.log' or p.name=='policy-parity' or p.suffix=='.m4s':continue
 if str(rel) in known:
  assert hashlib.sha256(p.read_bytes()).hexdigest()==known[str(rel)]['sourceSha256'],str(rel)
  continue
 data=p.read_bytes();compressed=p.suffix in ('.log','.jsonl','.py','.swift','.xctestrun') or len(data)>20000
 target=dst/(str(rel)+('.gz' if compressed else ''));target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0) if compressed else data)
 provenance.append(dict(source=str(rel),archive=str(target.relative_to(dst)),sourceSha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
(dst/'raw-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n');print('rawItems',len(provenance))
