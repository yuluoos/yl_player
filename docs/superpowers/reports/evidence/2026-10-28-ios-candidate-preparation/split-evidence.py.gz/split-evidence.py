from pathlib import Path
import hashlib,json,gzip,tarfile,io
base=Path('docs/superpowers/reports/evidence/2026-10-28-ios-candidate-preparation');archive=base/'macos-contracts.xcresult.tar.gz';data=archive.read_bytes();parts=[]
for index,offset in enumerate(range(0,len(data),15*1024*1024)):
 content=data[offset:offset+15*1024*1024];p=base/(archive.name+f'.part{index:02d}');p.write_bytes(content);parts.append(dict(path=p.name,bytes=len(content),sha256=hashlib.sha256(content).hexdigest()))
manifest=base/(archive.name+'.parts.json');manifest.write_text(json.dumps(dict(archiveName=archive.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),parts=parts),indent=2)+'\n')
restored=b''.join((base/p['path']).read_bytes() for p in parts);assert restored==data
with tarfile.open(fileobj=io.BytesIO(restored),mode='r:gz') as t:files=sum(m.isfile() for m in t.getmembers())
provenance=json.loads((base/'raw-provenance.json').read_text());row=next(r for r in provenance if r['archive']==archive.name);assert files==row['bundleFiles'];row['archive']=manifest.name;row['archiveParts']=parts;row['archiveSha256']=hashlib.sha256(data).hexdigest();archive.unlink()
p=Path('/private/tmp/yl-prewarm/split-evidence.py');raw=p.read_bytes();target=base/'split-evidence.py.gz';target.write_bytes(gzip.compress(raw,mtime=0));provenance.append(dict(source=p.name,archive=target.name,sourceSha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)))
(base/'raw-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
(base/'README.md').write_text('''# Raw evidence\n\nThe 16 complete xcresult bundles are retained. The large macOS bundle is split\ninto ordered 15 MiB chunks; no attachment was removed. Reconstruct it outside\nthe repository by concatenating the paths in `macos-contracts.xcresult.tar.gz.parts.json`\nin their listed order, verify each part and the combined SHA-256, then extract\nthe resulting tar.gz. The manifest records the exact original compressed bytes.\n\nOther `.gz` files decompress to the source bytes recorded in `raw-provenance.json`.\n`SHA256SUMS` covers every archive, chunk, manifest, metadata and guide here.\nSetup failures and expected red tests are distinct from the eight completed media\ncaptures. Private device inventory is excluded; selected test environment fields\nare saved in `device-environment.json`. Generated media bytes can be recreated\nfrom the captured fixture tooling and are bound by each receipt's fixture hash.\n''')
files=sorted(p for p in base.rglob('*') if p.is_file() and p.name!='SHA256SUMS');assert max(p.stat().st_size for p in files)<=16*1024*1024
(base/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(base))+'\n' for p in files))
print('verified split archive',len(data),'bytes',len(parts),'parts; manifest entries',len(files))
