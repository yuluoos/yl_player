from pathlib import Path
import json,collections
root=Path('/private/tmp/yl-prewarm/candidates');result={}
def rows(p):return [json.loads(l) for l in p.read_text().splitlines() if l.strip()]
for directory in sorted(root.iterdir()):
 if not directory.is_dir() or not (directory/'receipt.json').exists():continue
 receipt=json.loads((directory/'receipt.json').read_text());entry={'passed':receipt.get('passed'),'continuity':receipt.get('continuityObservation'),'policy':receipt.get('policyObservation'),'identity':receipt.get('binaryIdentityUnchanged'),'cleanup':receipt.get('ownedProcessExited')};result[directory.name]=entry
 if not (directory/'rows.jsonl').exists():continue
 main=rows(directory/'rows.jsonl');frames=rows(directory/'frame-samples.jsonl');policy=rows(directory/'policy-decisions.jsonl');entry['end']=main[-1];entry['windows']=[p for p in policy if p.get('windowBitrate') is not None]
 entry['events']=json.loads((directory/'automatic-events.json').read_text()) if (directory/'automatic-events.json').exists() else []
 transitions=[]
 for generation in sorted(set(r['generation'] for r in frames)-{0}):
  current=[r for r in frames if r['generation']==generation];prior=[r for r in frames if r['generation']<generation and r['frames']]
  def first(predicate):return next((r['elapsed'] for r in current if predicate(r)),None)
  transitions.append(dict(generation=generation,lastOldPublished=prior[-1]['elapsed'] if prior else None,firstGenerationSample=current[0]['elapsed'],firstReady=first(lambda r:r.get('itemStatus')==1),firstSeekGateOpen=first(lambda r:r.get('resumeSeekPending') is False),firstPublished=first(lambda r:r['frames']>0),firstHighPublished=first(lambda r:r['frames']>0 and r['width']==640),samplesBeforePublication=[r for r in current if r['elapsed']<= (first(lambda r:r['frames']>0) or current[-1]['elapsed'])]))
 entry['transitions']=transitions
 entry['proxyLastTen']=main[-10:]
 entry['proxyMaxPendingSends']=max(r.get('proxy',{}).get('pendingSends',0) for r in main)
 entry['reasons']=dict(collections.Counter(p['reason'] for p in policy))
Path('/private/tmp/yl-prewarm/candidate-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
for name,r in result.items():
 print(name, 'passed',r['passed'],'end',r.get('end',{}).get('position'),'reasons',r.get('reasons'),'gaps',r.get('continuity',{}).get('replacementBoundaries') if r.get('continuity') else None)
