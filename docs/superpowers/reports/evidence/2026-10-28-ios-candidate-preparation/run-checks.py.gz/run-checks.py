from pathlib import Path
import subprocess,json
out=Path('/private/tmp/yl-prewarm/checks');out.mkdir(exist_ok=True)
commands={
 'network':['python3','-B','-m','unittest','discover','-s','tool/playback_network','-p','test_*.py','-v'],
 'benchmark':['python3','-B','-m','unittest','discover','-s','tool/playback_benchmark','-p','test_*.py','-v'],
 'mirrors':['python3','-B','tool/consumer_fixtures/apple_flutter/main_example_tests.py'],
 'diff':['git','diff','--check']}
results=[]
for name,cmd in commands.items():
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,exitCode=p.returncode));(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,p.returncode,flush=True)
