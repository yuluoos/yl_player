from pathlib import Path
p=Path('tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift');s=p.read_text()
marker='private enum AbrDiagnosticCaptureURL {'
s=s.replace(marker,'''// Owned diagnostic experiment only; never a production recovery hook.
private enum AbrDiagnosticCandidatePreparation {
  @MainActor static func loadPlayable(_ asset: AVURLAsset, deadlineUptime: Double) async -> String {
    "loaded"
  }
}

'''+marker)
marker='  func testDeviceCaptureRequiresExplicitOwnedPrivateURL() {'
s=s.replace(marker,'''  @MainActor func testCandidateMetadataPreparationRejectsExpiredAndFailedAssets() async {
    let absent = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".mp4")
    let expiredAsset = AVURLAsset(url: absent)
    let expired = await AbrDiagnosticCandidatePreparation.loadPlayable(expiredAsset,
      deadlineUptime: ProcessInfo.processInfo.systemUptime - 1)
    XCTAssertEqual(expired, "timedOut")
    var error: NSError?
    XCTAssertEqual(expiredAsset.statusOfValue(forKey: "playable", error: &error), .unknown,
      "An expired candidate must not start loading")
    let failed = await AbrDiagnosticCandidatePreparation.loadPlayable(AVURLAsset(url: absent),
      deadlineUptime: ProcessInfo.processInfo.systemUptime + 2)
    XCTAssertEqual(failed, "failed")
  }

'''+marker)
Path('/private/tmp/yl-prewarm/native-red.swift').write_text(s)
