import Foundation
import CoreVideo

@main
struct LiveModeNativeTest {
  static func main() throws {
    var checks = 0
    func check(_ value: @autoclosure () -> Bool, _ name: String) {
      precondition(value(), name); checks += 1
    }
    func catchUp(low: Bool = true, playing: Bool = true, active: Bool = true,
                 edge: Bool = true, rate: Float = 1, offset: Int64? = 4_000,
                 window: Bool = true, maySeek: Bool = true) -> YlLiveCatchUpAction {
      YlLiveCatchUpPolicy.action(lowLatency: low, playing: playing, active: active,
        automaticEdgeAllowed: edge, requestedRate: rate, offsetMs: offset,
        targetMs: 2_000, hasSeekableWindow: window, maySeek: maySeek)
    }
    check(YlLiveCatchUpPolicy.catchUpPosition(startMs: 1000, endMs: 10000, targetMs: 2000) == 8000, "automatic edge stays within available media")
    check(YlLiveCatchUpPolicy.catchUpPosition(startMs: 9000, endMs: 10000, targetMs: 2000) == 9000, "short window clamps to its start")
    check(YlLiveCatchUpPolicy.catchUpPosition(startMs: 10000, endMs: 10000, targetMs: 2000) == nil, "empty window has no safe automatic seek")
    check(catchUp() == .rate(1.03), "bounded catch-up rate")
    check(catchUp(offset: 1_000) == .rate(1), "return to normal rate")
    check(catchUp(offset: 9_000) == .edge, "seek excessive backlog in valid window")
    check(catchUp(offset: 9_000, maySeek: false) == .rate(1.03), "seek cooldown")
    check(catchUp(low: false) == .none, "smooth mode does not catch up")
    check(catchUp(playing: false) == .none, "paused intent")
    check(catchUp(active: false) == .none, "inactive owner")
    check(catchUp(edge: false) == .none, "absolute seek intent")
    check(catchUp(rate: 1.5) == .none, "explicit user rate")
    check(catchUp(offset: nil) == .none, "unknown offset")
    check(catchUp(window: false) == .none, "no seekable window")
    var installedRate: Float = 1.03
    let allowCatchUp = YlLiveCatchUpPolicy.endAutomaticCatchUp(requestedRate: 1, playing: true) { installedRate = $0 }
    check(installedRate == 1 && !allowCatchUp, "absolute seek restores installed automatic rate")
    installedRate = 0
    _ = YlLiveCatchUpPolicy.endAutomaticCatchUp(requestedRate: 1.5, playing: false) { installedRate = $0 }
    check(installedRate == 0, "seek cannot resume paused output")
    check(YlLiveResumePolicy.requiresRefresh(lowLatency: true, live: true, pausedAt: 1, now: 4), "low live pause discards transport backlog")
    check(!YlLiveResumePolicy.requiresRefresh(lowLatency: false, live: true, pausedAt: 1, now: 4), "smooth keeps paused media")
    check(!YlLiveResumePolicy.requiresRefresh(lowLatency: true, live: false, pausedAt: 1, now: 4), "VOD cannot refresh live edge")
    check(!YlLiveResumePolicy.requiresRefresh(lowLatency: true, live: true, pausedAt: nil, now: 4), "initial play does not reopen")
    check(!YlLiveResumePolicy.requiresRefresh(lowLatency: true, live: true, pausedAt: 3.9, now: 4), "short pause avoids reconnect churn")
    func expiredResume(low: Bool = true, live: Bool = true, paused: TimeInterval? = 0,
      now: TimeInterval = 5, edge: Bool = true, rate: Float = 1,
      position: Int64? = 37_000, start: Int64? = nil, end: Int64? = nil) -> Bool {
      YlLiveResumePolicy.requiresHlsRefresh(lowLatency: low, live: live,
        pausedAt: paused, now: now, automaticEdgeAllowed: edge, requestedRate: rate,
        positionMs: position, startMs: start, endMs: end)
    }
    check(expiredResume(), "expired AVPlayer window refreshes on low resume")
    check(expiredResume(start: 40_000, end: 43_000), "paused position outside sliding window refreshes")
    check(!expiredResume(start: 36_000, end: 40_000), "available paused media needs no reopen")
    check(!expiredResume(low: false), "smooth resume retains its media")
    check(!expiredResume(live: false), "finite media cannot refresh as live")
    check(!expiredResume(paused: nil), "initial play cannot spend resume budget")
    check(!expiredResume(now: 1), "short pause cannot spend resume budget")
    check(!expiredResume(edge: false), "explicit seek survives long pause")
    check(!expiredResume(rate: 1.5), "explicit rate survives long pause")
    check(expiredResume(start: 40_000, end: 40_000), "empty live window is expired")
    check(expiredResume(position: 43_000, start: 40_000, end: 43_000), "exclusive end is not playable")
    let rtmpBudget = YlRtmpRecoveryBudget()
    let resumeRecovery = YlRecoveryCoordinator(configuration: .init(map: ["maxRetries": 3]), scheduler: YlDispatchRecoveryScheduler(queue: .main), rtmpBudget: rtmpBudget)
    check(resumeRecovery.reserveLiveRefresh(), "low resume consumes shared RTMP retry budget")
    check(rtmpBudget.attempts == 1, "refresh uses existing lifetime ledger")
    check(resumeRecovery.reserveLiveRefresh() && resumeRecovery.reserveLiveRefresh(), "three lifetime refresh attempts")
    check(!resumeRecovery.reserveLiveRefresh(), "low resume cannot replenish RTMP attempts")
    let httpRecovery = YlRecoveryCoordinator(configuration: .init(map: ["maxRetries": 1]), scheduler: YlDispatchRecoveryScheduler(queue: .main))
    check(httpRecovery.reserveLiveRefresh(), "HTTP low resume reserves existing retry budget")
    httpRecovery.markFirstFrame()
    check(!httpRecovery.reserveLiveRefresh(), "successful HTTP refresh cannot replenish reserved attempt")
    let oldBackend = LiveModeFakeBackend(), newBackend = LiveModeFakeBackend()
    var backend: YlPlaybackBackend = oldBackend
    var current = true
    let resolve: () throws -> YlPlaybackBackend = { if !current { throw YlOpenCancellationToken.cancellationError() }; return backend }
    let caps = YlQueuedPlaybackCommand(command: .constraints(.unconstrained), resolve: resolve)
    let audio = YlQueuedPlaybackCommand(command: .track("audio-2"), resolve: resolve)
    backend = newBackend // mode candidate commits while both commands wait
    try caps.run(YlOpenCancellationToken()); try audio.run(YlOpenCancellationToken())
    check(oldBackend.commands.isEmpty && newBackend.commands == ["caps", "audio-2"], "queued controls resolve installed backend")
    current = false
    do { try audio.run(YlOpenCancellationToken()); preconditionFailure("stale queued command acknowledged") }
    catch { checks += 1 }
    check(YlAppleCompatibility(platform: .macos).reconnectsAvPlayer, "macOS live HLS retains bounded recovery")
    check(YlAppleCompatibility(platform: .ios).reconnectsAvPlayer, "iOS live HLS recovery preserved")
    let parentToken = YlOpenCancellationToken()
    let childToken = parentToken.makeChild()
    childToken.cancel()
    check(!parentToken.isCancelled, "discarding a failed candidate cannot cancel its command")
    let secondChild = parentToken.makeChild()
    parentToken.cancel()
    check(secondChild.isCancelled, "stop cancellation reaches candidate")
    check(parentToken.makeChild().isCancelled, "late candidate observes prior cancellation")
    let exclusiveOld = LiveModeFakeBackend(), exclusiveNew = LiveModeFakeBackend()
    let exclusiveSlot = YlBackendSlot(initial: exclusiveOld, compatibility: .init(platform: .ios))
    try exclusiveSlot.replace(requiresExclusiveResources: true) {
      check(!exclusiveOld.isActive, "iOS releases old exclusive resource before candidate construction")
      return exclusiveNew
    }
    check(exclusiveSlot.current === exclusiveNew && exclusiveNew.isActive, "exclusive candidate installed")
    do {
      try exclusiveSlot.replace(requiresExclusiveResources: true) {
        throw NativePlayerError(category: "decoder", code: "decoder.unavailable", message: "Rejected")
      }
      preconditionFailure("failed candidate accepted")
    } catch {
      check(exclusiveSlot.current === exclusiveNew && exclusiveNew.isActive, "failed candidate restores old resource owner")
    }
    let config = PlayerConfiguration(positionEventIntervalMs: 250)
    var source = YlAppleSourceDescriptor(uri: "https://fixture.invalid/live.m3u8", kind: .network,
      formatHint: .hls, intent: .live, loadOptions: .init())
    check(config.forLoad(source).bufferMode == "stable", "confirmed live defaults smooth")
    source.intent = .automatic; source.formatHint = .automatic
    source.uri = "https://fixture.invalid/auto.flv"
    check(config.forLoad(source).bufferMode == "stable", "inferred FLV defaults smooth")
    source.intent = .onDemand
    check(config.forLoad(source).bufferMode == "automatic", "VOD default unchanged")
    source.loadOptions?.bufferStrategy = .lowLatency
    check(config.forLoad(source).preferredForwardBufferDuration == 2, "explicit low mode")
    source.intent = .live; source.loadOptions?.bufferStrategy = .bounded
    check(config.forLoad(source).bufferMode == "automatic", "bounded is not relabeled")
    let intent = YlManagedRequestIntent()
    check(intent.nextRetry(maximum: 3) == 1, "initial retry")
    let candidate = intent.candidate()
    check(candidate.nextRetry(maximum: 3) == 2, "candidate shares retry counter")
    check(candidate.followRedirect(maximum: 1), "candidate redirect charged")
    check(!intent.followRedirect(maximum: 1), "original cannot replenish redirects")
    candidate.fail(NativePlayerError(category: "network", code: "network.http_status", message: "Rejected"))
    check(intent.terminalFailure == nil, "failed candidate does not poison surviving original")
    check(candidate.terminalFailure != nil, "failed candidate stays failed")
    intent.completed(); candidate.completed()
    check(intent.nextRetry(maximum: 3) == 3, "original retains consumed candidate budget")
    check(intent.candidate().nextRetry(maximum: 3) == nil, "another mode request cannot reset budget")
    let recovery = YlLiveReconnectController(configuration: .init(map: ["maxRetries": 3]))
    recovery.retainAttempts(2); recovery.markFirstFrame()
    check(recovery.attempt == 2, "replacement first frame cannot replenish recovery attempts")
    let callbackIdentity = YlAppleSessionIdentity(sessionId: "mode", loadRequestId: "load", startedAtMs: 0)
    let emitter = YlAppleCommitEmitter(identity: callbackIdentity, emit: { _,_ in preconditionFailure("stale candidate snapshot replayed") })
    let reducer = YlAppleStateReducer(playerId: 1, clock: { 100 })
    let identity = reducer.makeIdentity(loadRequestId: "load-1")
    reducer.commit(identity)
    let snapshot = YlNativeState(status: "paused", positionMs: 100, durationMs: nil,
      bufferedPositionMs: 100, isLive: true, isSeekable: false, isAtLiveEdge: false,
      liveOffsetMs: nil, dvrStartMs: nil, dvrEndMs: nil, videoWidth: nil, videoHeight: nil,
      engine: .managedFallback, isHardwareDecoding: false, decoderName: nil,
      audioTracks: [], videoTracks: [], metrics: .init(), error: nil)
    reducer.accept(.init(generation: 1, event: .state(snapshot)), identity: identity)
    emitter.accept(.init(generation: 1, event: .state(snapshot)))
    check(emitter.takeInitialSnapshot()?.status == "paused", "commit takes actual candidate state")
    check(emitter.takeInitialSnapshot() == nil, "candidate snapshot taken once")
    emitter.commit()
    let before = reducer.revision
    let revision = try reducer.commitLivePlayback(.init(mode: .lowLatency,
      switchableModes: [.smoothPlayback, .lowLatency], committedRequestId: 1))
    check(revision == before + 1, "single exact commit revision")
    check(reducer.state.snapshot?.status == "paused", "commit preserves pause")
    check(reducer.state.snapshot?.livePlayback?.committedRequestId == 1, "snapshot carries commit identity")
    reducer.stop()
    check(reducer.state.snapshot == nil, "stop clears live state")
    do { _ = try reducer.commitLivePlayback(.init(mode: .lowLatency, switchableModes: [], committedRequestId: 2)); preconditionFailure("stale commit accepted") }
    catch { checks += 1 }
    print("P04_NATIVE_POLICY_CHECKS=\(checks)")
  }
}

private final class LiveModeFakeBackend: YlPlaybackBackend {
  var isActive = true
  var commands = [String]()
  func activate() throws { isActive = true }
  func stop() {}
  func deactivate() { isActive = false }
  func play() throws {}
  func pause() throws {}
  func seek(toMs: Int64, cancellationToken: YlOpenCancellationToken?) throws {}
  func seekToLiveEdge() throws {}
  func setPlaybackSpeed(_ speed: Float) throws {}
  func setVolume(_ volume: Float) throws {}
  func selectAudioTrack(_ trackId: String, cancellationToken: YlOpenCancellationToken?) throws { commands.append(trackId) }
  func setVideoConstraints(_ constraints: YlAppleVideoConstraints) throws { commands.append("caps") }
  func emitState() {}
  func copyPixelBuffer() -> Unmanaged<CVPixelBuffer>? { nil }
  func dispose() {}
}
