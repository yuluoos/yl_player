import AVFoundation
import Foundation

/// Observes frame delivery independently of AVPlayer's timeControlStatus.
/// A gap is diagnostic evidence only; sparse video and buffering can also cause it.
final class YlAvPlayerVideoProgressProbe {
  struct Observation {
    enum Kind: String { case videoOutputGap, videoOutputResumed }
    let kind: Kind
    let frameGapMs: Int64
    let timelineGapMs: Int64
    let positionMs: Int64
  }

  private var lastFrameMs: Int64?
  private var lastProgressMs: Int64?
  private var lastPositionMs: Int64?
  private var lastReportMs: Int64?

  func reset() {
    lastFrameMs = nil
    lastProgressMs = nil
    lastPositionMs = nil
    lastReportMs = nil
  }

  func observe(enabled: Bool, framePublished: Bool, positionMs: Int64?,
               nowMs: Int64, timeoutMs: Int64) -> Observation? {
    guard enabled, let positionMs, positionMs >= 0 else { reset(); return nil }
    if let lastPositionMs, positionMs < lastPositionMs { reset() }
    if lastFrameMs == nil { lastFrameMs = nowMs }
    if lastPositionMs == nil || positionMs > lastPositionMs! { lastProgressMs = nowMs }
    lastPositionMs = positionMs
    let frameGapMs = max(0, nowMs - (lastFrameMs ?? nowMs))
    let timelineGapMs = max(0, nowMs - (lastProgressMs ?? nowMs))
    if framePublished {
      lastFrameMs = nowMs
      guard lastReportMs != nil else { return nil }
      lastReportMs = nil
      return Observation(kind: .videoOutputResumed, frameGapMs: frameGapMs,
        timelineGapMs: timelineGapMs, positionMs: positionMs)
    }
    let interval = max(5_000, timeoutMs)
    guard frameGapMs >= interval,
          lastReportMs == nil || nowMs - lastReportMs! >= interval else { return nil }
    lastReportMs = nowMs
    return Observation(kind: .videoOutputGap, frameGapMs: frameGapMs,
      timelineGapMs: timelineGapMs, positionMs: positionMs)
  }
}

struct YlAvPlayerErrorLogSnapshot {
  let domain: String?
  let statusCode: Int?
  let uri: String?
}

enum YlAvPlayerRecoveryPolicy {
  static func diagnostic(_ error: NSError?) -> String {
    diagnostic(error: error, errorDomain: nil, statusCode: nil, uri: nil)
  }

  static func shouldReconnect(
    source: YlAppleSourceDescriptor,
    usesResourceLoader: Bool,
    hasBeenReady: Bool,
    playRequested: Bool,
    error: NSError?,
    errorLogDomain: String?,
    errorLogStatusCode: Int?
  ) -> Bool {
    guard isDirectLiveHls(source, usesResourceLoader: usesResourceLoader),
          playRequested || !hasBeenReady else {
      return false
    }
    return isTransient(
      error: error,
      errorLogDomain: errorLogDomain,
      errorLogStatusCode: errorLogStatusCode
    )
  }

  static func diagnostic(
    error: NSError?,
    errorDomain: String?,
    statusCode: Int?,
    uri: String?
  ) -> String {
    YlAppleSafeDiagnostics.diagnostic(error ?? NSError(domain: "AVFoundationErrorDomain", code: 0))
  }

  static func isDirectLiveHls(
    _ source: YlAppleSourceDescriptor,
    usesResourceLoader: Bool
  ) -> Bool {
    guard source.kind == .network, source.isLive, !usesResourceLoader,
      let url = source.url else { return false }
    return source.formatHint == .hls
      || (source.formatHint == .automatic && url.pathExtension.lowercased() == "m3u8")
  }

  private static func isTransient(
    error: NSError?,
    errorLogDomain: String?,
    errorLogStatusCode: Int?
  ) -> Bool {
    var current = error
    for _ in 0..<8 {
      guard let candidate = current else { break }
      if candidate.domain == NSURLErrorDomain,
         transientURLErrorCodes.contains(candidate.code) {
        return true
      }
      #if os(iOS)
      if candidate.domain == AVFoundationErrorDomain,
         candidate.code == AVError.mediaServicesWereReset.rawValue {
        return true
      }
      #endif
      if candidate.domain == "CoreMediaErrorDomain", candidate.code == -12312 {
        return true
      }
      current = candidate.userInfo[NSUnderlyingErrorKey] as? NSError
    }

    guard let errorLogStatusCode else { return false }
    if errorLogDomain == "CoreMediaErrorDomain" && errorLogStatusCode == -12312 {
      return true
    }
    guard errorLogDomain == "CoreMediaErrorDomain" else { return false }
    return errorLogStatusCode == 408
      || errorLogStatusCode == 429
      || (500...599).contains(errorLogStatusCode)
  }

  private static let transientURLErrorCodes: Set<Int> = [
    NSURLErrorTimedOut,
    NSURLErrorCannotFindHost,
    NSURLErrorCannotConnectToHost,
    NSURLErrorNetworkConnectionLost,
    NSURLErrorDNSLookupFailed,
    NSURLErrorResourceUnavailable,
    NSURLErrorNotConnectedToInternet,
    NSURLErrorInternationalRoamingOff,
    NSURLErrorCallIsActive,
    NSURLErrorDataNotAllowed,
  ]
}

/// Reads potentially blocking AVPlayer logs without serializing unrelated item
/// generations, and bounds how long playback waits for diagnostic metadata.
final class YlAvPlayerErrorLogCollector {
  private let queue = DispatchQueue(
    label: "dev.ylplayer.avplayer-error-log",
    qos: .utility,
    attributes: .concurrent
  )
  private let callbackQueue: DispatchQueue

  init(callbackQueue: DispatchQueue = .main) {
    self.callbackQueue = callbackQueue
  }

  func collect(
    timeoutMs: Int64,
    read: @escaping () -> YlAvPlayerErrorLogSnapshot,
    completion: @escaping (YlAvPlayerErrorLogSnapshot?) -> Void
  ) {
    let delivery = YlAvPlayerOneShotDelivery()
    queue.async { [callbackQueue] in
      let snapshot = read()
      guard delivery.claim() else { return }
      callbackQueue.async { completion(snapshot) }
    }
    queue.asyncAfter(
      deadline: .now() + .milliseconds(Int(max(0, min(timeoutMs, 60_000))))
    ) { [callbackQueue] in
      guard delivery.claim() else { return }
      callbackQueue.async { completion(nil) }
    }
  }
}

private final class YlAvPlayerOneShotDelivery {
  private let lock = NSLock()
  private var delivered = false

  func claim() -> Bool {
    lock.withLock {
      guard !delivered else { return false }
      delivered = true
      return true
    }
  }
}

/// Coalesces AVPlayer's KVO and notification failure callbacks per item.
final class YlAvPlayerFailureGate {
  private var processingGeneration: UInt64?
  private var terminalGeneration: UInt64?

  func begin(generation: UInt64) -> Bool {
    guard processingGeneration != generation,
          terminalGeneration != generation else {
      return false
    }
    processingGeneration = generation
    return true
  }

  func finish(generation: UInt64, currentGeneration: UInt64) -> Bool {
    guard processingGeneration == generation else { return false }
    processingGeneration = nil
    return generation == currentGeneration
  }

  func markTerminal(generation: UInt64) {
    terminalGeneration = generation
  }

  func reset() {
    processingGeneration = nil
    terminalGeneration = nil
  }
}
