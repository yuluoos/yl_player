package dev.ylplayer.yl_player_android

import android.content.Context
import android.media.MediaFormat
import android.os.Handler
import android.os.SystemClock
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.AudioTrackAudioOutputProvider
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.ForwardingAudioSink
import java.nio.ByteBuffer
import androidx.media3.common.Format
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.mediacodec.DefaultMediaCodecAdapterFactory
import androidx.media3.exoplayer.mediacodec.MediaCodecAdapter
import androidx.media3.exoplayer.mediacodec.MediaCodecInfo
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.source.MediaSource.MediaPeriodId
import androidx.media3.exoplayer.video.MediaCodecVideoRenderer
import androidx.media3.exoplayer.video.VideoRendererEventListener
import dev.ylplayer.yl_player_android.pigeon.AndroidVideoGeometryMessage
import java.util.concurrent.atomic.AtomicLong

internal open class QueueTestRenderersFactory(context: Context, private val observer: YlVideoOutputObserver) : DefaultRenderersFactory(context) {
    var allowDashPrewarming = true
    var dashPlayWhenReady: () -> Boolean = { false }
    private var dashStartupAudioPosition: (() -> Long?)? = null
    var dashDecoderSizing: YlDashDecoderSizing? = null
    private var dashAudioWaiting: (() -> Boolean)? = null
    var allowEac3SoftwareAudio = false
    var useConstrainedTvAudioBuffer = false
    var useMiTvPlatformRate = false
    var isMiTv3xRequested: (() -> Boolean)? = null
    // Keep the Google AAC input queue fed while video output and the audio
    // sink compete for playback-thread time at high rates.
    private val miTvAdapters by lazy {
        val ordinary = super.getCodecAdapterFactory()
        val asyncAac = DefaultMediaCodecAdapterFactory(context).forceEnableAsynchronous()
        MediaCodecAdapter.Factory { config ->
            if (config.codecInfo.name.equals("OMX.google.aac.decoder", ignoreCase = true)) {
                asyncAac.createAdapter(config)
            } else ordinary.createAdapter(config)
        }
    }

    override fun getCodecAdapterFactory(): MediaCodecAdapter.Factory =
        if (useMiTvPlatformRate) miTvAdapters else super.getCodecAdapterFactory()

    @Suppress("DEPRECATION")
    override fun buildAudioSink(context: Context, enableFloatOutput: Boolean, enableAudioOutputPlaybackParams: Boolean): androidx.media3.exoplayer.audio.AudioSink? {
        val platformRate = enableAudioOutputPlaybackParams || useMiTvPlatformRate
        val sink = if (useConstrainedTvAudioBuffer) {
            val builder = DefaultAudioSink.Builder(context)
                .setEnableFloatOutput(enableFloatOutput)
                .setEnableAudioOutputPlaybackParameters(platformRate)
            val sizes = YlTvAudioBufferSizeProvider(useMiTvPlatformRate, isMiTv3xRequested)
            if (useMiTvPlatformRate) {
                val provider = AudioTrackAudioOutputProvider.Builder(context).setAudioTrackBufferSizeProvider(sizes).build()
                val playbackSink = builder.setAudioOutputProvider(YlMiTvAudioOutputProvider(provider)).build()
                // DefaultAudioSink can only query capabilities from an unwrapped AudioTrack provider.
                object : ForwardingAudioSink(playbackSink) {
                    override fun getAudioCapabilities() = provider.audioCapabilities
                }
            } else builder.setAudioTrackBufferSizeProvider(sizes).build()
        } else super.buildAudioSink(context, enableFloatOutput, platformRate) ?: return null
        return if (observer.dashVideoFamily != null) YlDashPcmAudioSink(sink) else sink
    }

    override fun buildAudioRenderers(context: Context, extensionRendererMode: Int, mediaCodecSelector: MediaCodecSelector,
        enableDecoderFallback: Boolean, audioSink: androidx.media3.exoplayer.audio.AudioSink, eventHandler: Handler,
        eventListener: androidx.media3.exoplayer.audio.AudioRendererEventListener, out: ArrayList<Renderer>) {
        if (audioSink !is YlDashPcmAudioSink) {
            // Media3 renders in array order. Give the TV's AAC decoder and PCM
            // sink a turn before the synchronous video codec starts or drains.
            val audio = if (useMiTvPlatformRate) ArrayList<Renderer>() else out
            super.buildAudioRenderers(context, extensionRendererMode, mediaCodecSelector, enableDecoderFallback, audioSink, eventHandler, eventListener, audio)
            if (allowEac3SoftwareAudio) audio.add(YlEac3AudioRenderer(eventHandler, eventListener, audioSink))
            if (useMiTvPlatformRate) out.addAll(0, audio)
            return
        }
        check(extensionRendererMode == EXTENSION_RENDERER_MODE_OFF)
        val renderer = object : androidx.media3.exoplayer.audio.MediaCodecAudioRenderer(context, codecAdapterFactory,
            mediaCodecSelector, enableDecoderFallback, eventHandler, eventListener, audioSink) {
            override fun onPositionReset(positionUs: Long, joining: Boolean, sampleStreamIsResetToKeyFrame: Boolean) {
                super.onPositionReset(positionUs, joining, sampleStreamIsResetToKeyFrame)
                audioSink.resetPosition(positionUs)
            }
            override fun processOutputBuffer(positionUs: Long, elapsedRealtimeUs: Long, codec: MediaCodecAdapter?,
                buffer: ByteBuffer?, bufferIndex: Int, bufferFlags: Int, sampleCount: Int,
                bufferPresentationTimeUs: Long, isDecodeOnlyBuffer: Boolean, isLastBuffer: Boolean, format: Format): Boolean {
                val keepTail = isDecodeOnlyBuffer && buffer != null &&
                    bufferFlags and android.media.MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0 &&
                    audioSink.keepsPrerollTail(bufferPresentationTimeUs, buffer.remaining())
                return super.processOutputBuffer(positionUs, elapsedRealtimeUs, codec, buffer, bufferIndex,
                    bufferFlags, sampleCount, bufferPresentationTimeUs, isDecodeOnlyBuffer && !keepTail, isLastBuffer, format)
            }
        }
        out.add(renderer)
        if (dashDecoderSizing != null) dashStartupAudioPosition = {
            if (renderer.state == Renderer.STATE_DISABLED || renderer.isEnded) null
            else audioSink.getCurrentPositionUs(false)
        }
        dashAudioWaiting = {
            renderer.state != Renderer.STATE_DISABLED && !renderer.isEnded &&
                audioSink.getCurrentPositionUs(false) == AudioSink.CURRENT_POSITION_NOT_SET
        }
    }

    override fun buildVideoRenderers(context: Context, extensionRendererMode: Int, mediaCodecSelector: MediaCodecSelector,
        enableDecoderFallback: Boolean, eventHandler: Handler, eventListener: VideoRendererEventListener,
        allowedVideoJoiningTimeMs: Long, out: ArrayList<Renderer>) {
        check(extensionRendererMode == EXTENSION_RENDERER_MODE_OFF)
        out.add(videoRenderer(context, mediaCodecSelector, enableDecoderFallback, eventHandler, eventListener, allowedVideoJoiningTimeMs, observer))
    }

    override fun buildSecondaryVideoRenderer(renderer: Renderer, context: Context, extensionRendererMode: Int,
        mediaCodecSelector: MediaCodecSelector, enableDecoderFallback: Boolean, eventHandler: Handler,
        eventListener: VideoRendererEventListener, allowedVideoJoiningTimeMs: Long): Renderer? {
        if (!allowDashPrewarming || renderer !is YlOutputVideoRenderer || dashAudioWaiting == null) return null
        return videoRenderer(context, mediaCodecSelector, enableDecoderFallback, eventHandler, eventListener, allowedVideoJoiningTimeMs, observer.forPrewarming())
    }

    private fun videoRenderer(context: Context, mediaCodecSelector: MediaCodecSelector, enableDecoderFallback: Boolean,
        eventHandler: Handler, eventListener: VideoRendererEventListener, allowedVideoJoiningTimeMs: Long, rendererObserver: YlVideoOutputObserver): YlOutputVideoRenderer {
        val builder = MediaCodecVideoRenderer.Builder(context)
            .setEarlySchedulingThresholdUs(androidx.test.platform.app.InstrumentationRegistry.getArguments().getString("leadUs", "300000").toLong()).setCodecAdapterFactory(codecAdapterFactory)
            .setMediaCodecSelector(mediaCodecSelector)
            .setAllowedJoiningTimeMs(allowedVideoJoiningTimeMs)
            .setEnableDecoderFallback(enableDecoderFallback)
            .setEventHandler(eventHandler).setEventListener(eventListener)
            .setMaxDroppedFramesToNotify(MAX_DROPPED_VIDEO_FRAME_COUNT_TO_NOTIFY)
        return YlOutputVideoRenderer(builder, rendererObserver, isMiTv3xRequested, dashDecoderSizing,
            { if (dashPlayWhenReady()) dashStartupAudioPosition?.invoke() else null }) { dashAudioWaiting?.invoke() == true }
    }
}

