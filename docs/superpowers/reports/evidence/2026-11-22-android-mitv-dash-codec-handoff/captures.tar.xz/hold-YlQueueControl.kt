package dev.ylplayer.yl_player_android

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLExt
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import androidx.media3.common.C
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit

/** Single-decoder experiment. Copies complete frames, then posts the copies to a second texture on time. */
internal class YlQueueControl(target: Surface, val failed: (Throwable) -> Unit) {
    private val thread = HandlerThread("dash-frame-queue").apply { start() }
    private val handler = Handler(thread.looper)
    private fun <T> call(action: () -> T): T {
        val task = FutureTask(action)
        check(handler.post(task))
        return task.get(5, TimeUnit.SECONDS)
    }
    private val receipts = java.util.concurrent.LinkedBlockingQueue<Long>()
    private var previous: Long? = null
    fun beforeRelease(timestamp: Long) {
        previous?.let { expected ->
            val got = receipts.poll(150, TimeUnit.MILLISECONDS)
            check(got == expected) { "input handoff mismatch $expected / $got" }
        }
        previous = timestamp
    }
    private inner class Output(target: Surface) {
        val display = GlUtil.getDefaultEglDisplay()
        val context = GlUtil.createEglContext(display)
        val scratch = GlUtil.createFocusedPlaceholderEglSurface(context, display)
        val destination = GlUtil.createEglSurface(display, target, C.COLOR_TRANSFER_SDR, false)
        val oes = GlUtil.createExternalTexture()
        val input = SurfaceTexture(oes)
        val surface = Surface(input)
        val textures = IntArray(14) { GlUtil.createTexture(640, 360, false) }
        val buffers = textures.map(GlUtil::createFboForTexture)
        val occupied = BooleanArray(textures.size)
        val quad = floatArrayOf(-1f,-1f, 1f,-1f, -1f,1f, 1f,1f)
        val vertex = "attribute vec2 a; varying vec2 uv; void main(){uv=(a+1.0)*0.5; gl_Position=vec4(a,0.0,1.0);}"
        val copy = GlProgram(vertex, """
            #extension GL_OES_EGL_image_external : require
            precision mediump float; uniform mat4 transform; uniform samplerExternalOES frame;
            varying vec2 uv; void main(){gl_FragColor=texture2D(frame,(transform*vec4(uv,0.,1.)).xy);}
        """.trimIndent())
        val show = GlProgram(vertex, "precision mediump float; uniform sampler2D frame; varying vec2 uv; void main(){gl_FragColor=texture2D(frame,uv);}")
        val transform = FloatArray(16)
        val stamps = LongArray(textures.size)
        val deadlines = LongArray(textures.size)
        val timers = arrayOfNulls<Runnable>(textures.size)
        var pausedAt = 0L
        fun pause() {
            if (pausedAt != 0L) return
            pausedAt = System.nanoTime()
            timers.filterNotNull().forEach(handler::removeCallbacks)
        }
        fun resume() {
            if (pausedAt == 0L) return
            val offset = System.nanoTime() - pausedAt
            pausedAt = 0L
            for (i in occupied.indices) if (occupied[i]) {
                deadlines[i] += offset
                schedule(i)
            }
        }
        fun schedule(slot: Int) {
            val timer = Runnable { safe {
                GlUtil.focusEglSurface(display,context,destination,640,360)
                show.setSamplerTexIdUniform("frame",textures[slot],0)
                draw(show)
                val deadline = deadlines[slot]
                if (deadline != stamps[slot]) retimed[deadline] = stamps[slot]
                check(EGLExt.eglPresentationTimeANDROID(display,destination,deadline))
                check(EGL14.eglSwapBuffers(display,destination))
                occupied[slot] = false
                timers[slot] = null
            } }
            timers[slot] = timer
            handler.postDelayed(timer, ((deadlines[slot]-System.nanoTime()) / 1_000_000L).coerceAtLeast(0))
        }
        var lastStamp = Long.MIN_VALUE
        init {
            copy.setBufferAttribute("a",quad,2)
            copy.setSamplerTexIdUniform("frame",oes,0)
            show.setBufferAttribute("a",quad,2)
            input.setOnFrameAvailableListener({ safe { capture() } }, handler)
        }
        fun safe(action: () -> Unit) {
            try { action() } catch (e: Exception) { failed(e) }
        }
        fun draw(program: GlProgram) {
            program.use()
            program.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4)
            GlUtil.checkGlError()
        }
        fun capture() {
            input.updateTexImage()
            val stamp = input.timestamp
            if (stamp == lastStamp) return
            lastStamp = stamp
            val slot = occupied.indexOfFirst { !it }
            check(slot >= 0) { "frame queue exhausted" }
            occupied[slot] = true
            input.getTransformMatrix(transform)
            GlUtil.focusFramebuffer(display,context,scratch,buffers[slot],640,360)
            copy.setFloatsUniform("transform",transform)
            draw(copy)
            GLES20.glFlush()
            receipts.add(stamp)
            stamps[slot] = stamp
            deadlines[slot] = stamp
            if (pausedAt == 0L) schedule(slot)
        }
        fun close() {
            input.setOnFrameAvailableListener(null)
            handler.removeCallbacksAndMessages(null)
            surface.release()
            input.release()
            copy.delete()
            show.delete()
            buffers.forEach(GlUtil::deleteFbo)
            textures.forEach(GlUtil::deleteTexture)
            GlUtil.deleteTexture(oes)
            GlUtil.destroyEglSurface(display,destination)
            GlUtil.destroyEglSurface(display,scratch)
            GlUtil.destroyEglContext(display,context)
            GlUtil.terminate(display)
        }
    }
    private val retimed = java.util.concurrent.ConcurrentHashMap<Long,Long>()
    fun original(stamp: Long) = retimed.remove(stamp) ?: stamp
    fun pause() = call { output.pause() }
    fun resume() = call { output.resume() }
    private val output = call { Output(target) }
    val surface get() = output.surface
    fun close() {
        try { call { output.close() } } finally { thread.quitSafely(); thread.join(5_000) }
    }
}
