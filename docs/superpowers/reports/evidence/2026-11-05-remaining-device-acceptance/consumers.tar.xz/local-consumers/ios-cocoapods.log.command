sh /Users/yy2021_8689/.codex/worktrees/remaining-device-acceptance/yl_player/tool/check_apple_consumer.sh --platform ios --manager cocoapods --link
