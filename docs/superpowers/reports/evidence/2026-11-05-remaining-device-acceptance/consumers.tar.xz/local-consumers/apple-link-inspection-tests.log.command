python3 -B /Users/yy2021_8689/.codex/worktrees/remaining-device-acceptance/yl_player/tool/consumer_fixtures/apple_flutter/test_link_inspection.py
