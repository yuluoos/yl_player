sh /Users/yy2021_8689/.codex/worktrees/remaining-device-acceptance/yl_player/tool/check_apple_consumer.sh --platform macos --manager cocoapods --link --lipo-compat
