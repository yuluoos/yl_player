/private/tmp/yl-remaining-device-20261105/consumers/android/android/gradlew -p /private/tmp/yl-remaining-device-20261105/consumers/android/android :app:assembleDebug --stacktrace
