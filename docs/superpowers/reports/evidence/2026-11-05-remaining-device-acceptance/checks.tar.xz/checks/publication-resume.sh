set -eu
package_names="yl_player_apple yl_player_source_resolver yl_player yl_player_cast yl_player_cast_player_adapter"
log_root=".superpowers/sdd/2026-11-05-remaining-device-acceptance/publication-remaining"
for package_name in $package_names; do
  package="packages/$package_name"
  log="$log_root/$package_name-dry-run.log"
  echo "==> dart pub publish --dry-run ($package_name)"
  if (cd "$package" && dart pub publish --dry-run) >"$log" 2>&1; then
    status=0
  else
    status=$?
  fi
  cat "$log"
  echo "DRY_RUN_EXIT package=$package_name exit=$status"
  if [ "$status" -ne 0 ]; then
    exit "$status"
  fi
  if ! grep -Eq '^Package has 0 warnings( and [0-9]+ hints?)?\.$' "$log"; then
    echo "$package_name dry-run did not report zero warnings" >&2
    exit 1
  fi
  if grep -Eq '(^|[[:space:]│├└─])(\.dart_tool|build|\.gradle|\.swiftpm|DerivedData|Pods|\.symlinks|coverage)([[:space:]/(]|$)|\.xcresult([[:space:]/(]|$)|test_media([[:space:]/(]|$)|\.log([[:space:](]|$)|\.env([[:space:](]|$)' "$log"; then
    echo "$package_name archive contains a build/cache/test-media/secret-log path" >&2
    exit 1
  fi
done

apple_log="$log_root/yl_player_media_core-dry-run.log"
for required in \
  'FFmpeg-LGPL-2.1-or-later.txt' \
  'THIRD_PARTY_NOTICES.md' \
  'YlFFmpegBridge.xcframework'; do
  if ! grep -Fq "$required" "$apple_log"; then
    echo "yl_player_media_core archive is missing $required" >&2
    exit 1
  fi
done

echo "Publication gate passed for all publishable packages."
