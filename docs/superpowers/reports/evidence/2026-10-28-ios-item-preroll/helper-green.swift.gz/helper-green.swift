// Completion callbacks may arrive on AVFoundation queues after cancellation.
private final class AbrPrerollCompletion: @unchecked Sendable {
  private let lock = NSLock()
  private var value: Bool?
  func finish(_ result: Bool) { lock.lock(); value = result; lock.unlock() }
  var result: Bool? { lock.lock(); defer { lock.unlock() }; return value }
}

// Diagnostic only: the final backend still performs its exact resume seek.
private enum AbrDiagnosticPreroll {
  @MainActor static func prepare(_ asset: AVURLAsset, position: CMTime, deadlineUptime: Double,
    allowed: () -> Bool, onReady: () -> Void = {}, cancelPending: () -> Void) async
    -> (outcome: String, item: AVPlayerItem?, detached: Bool, stage: String) {
    var candidate: AVPlayer?
    var stage = "beforeLoading"
    func finish(_ outcome: String, item: AVPlayerItem? = nil)
      -> (outcome: String, item: AVPlayerItem?, detached: Bool, stage: String) {
      candidate?.pause(); candidate?.cancelPendingPrerolls()
      candidate?.currentItem?.cancelPendingSeeks()
      candidate?.replaceCurrentItem(with: nil)
      if item == nil { asset.cancelLoading(); cancelPending() }
      return (outcome, item, candidate?.currentItem == nil, stage)
    }
    func rejection() -> String? {
      if Task.isCancelled || !allowed() { return "cancelled" }
      if ProcessInfo.processInfo.systemUptime >= deadlineUptime { return "timedOut" }
      return nil
    }
    guard deadlineUptime.isFinite, CMTimeGetSeconds(position).isFinite,
      CMTimeGetSeconds(position) >= 0 else { return finish("failed") }
    if let reason = rejection() { return finish(reason) }
    let player = AVPlayer()
    player.isMuted = true; player.allowsExternalPlayback = false
    let item = AVPlayerItem(asset: asset)
    item.preferredForwardBufferDuration = 10
    item.preferredPeakBitRate = 0
    candidate = player
    player.replaceCurrentItem(with: item)
    stage = "waitingReady"
    while player.status != .readyToPlay || item.status != .readyToPlay {
      if let reason = rejection() { return finish(reason) }
      if player.status == .failed || item.status == .failed { return finish("failed") }
      try? await Task.sleep(nanoseconds: 10_000_000)
    }
    onReady() // Explicit diagnostic injection after real readiness, before seek.
    if let reason = rejection() { return finish(reason) }
    stage = "seeking"
    let seek = AbrPrerollCompletion()
    player.seek(to: position, toleranceBefore: .zero, toleranceAfter: .zero) { seek.finish($0) }
    while seek.result == nil {
      if let reason = rejection() { return finish(reason) }
      if player.status == .failed || item.status == .failed { return finish("failed") }
      try? await Task.sleep(nanoseconds: 10_000_000)
    }
    guard seek.result == true else { return finish("seekFailed") }
    if let reason = rejection() { return finish(reason) }
    // SDK contract: preroll throws unless the player is ready and rate is zero.
    guard player.status == .readyToPlay, item.status == .readyToPlay, player.rate == 0 else {
      return finish("failed")
    }
    stage = "preroll"
    let preroll = AbrPrerollCompletion()
    player.preroll(atRate: 1) { preroll.finish($0) }
    while preroll.result == nil {
      if let reason = rejection() { return finish(reason) }
      if player.status == .failed || item.status == .failed { return finish("failed") }
      try? await Task.sleep(nanoseconds: 10_000_000)
    }
    if let reason = rejection() { return finish(reason) }
    guard preroll.result == true else { return finish("prerollFailed") }
    stage = "ready"
    return finish("ready", item: item)
  }
}

