from pathlib import Path
import subprocess,json,time,hashlib,shutil
root=Path.cwd();base=Path('/private/tmp/yl-item-preroll');out=base/'media';out.mkdir(exist_ok=False)
planned=[('normal-1','manifest-only','normal'),('warm-1','asset-preroll','normal'),('normal-2','manifest-only','normal'),('warm-2','asset-preroll','normal'),('warm-pause','asset-preroll','pause-during-preparation'),('original-control','manifest-only','normal')]
(out/'planned.json').write_text(json.dumps(planned,indent=2)+'\n');shutil.copyfile('/private/tmp/yl-preroll/latency-profiles.json',base/'latency-profiles.json')
files=list(json.loads(Path('/private/tmp/yl-preroll/fixed-media/source-identity.json').read_text()))+['tool/playback_network/test_abr_accesslog.py']
identity={}
for name in files:
 data=Path(name).read_bytes();identity[name]=hashlib.sha256(data).hexdigest();dest=base/'capture-source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
(out/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n');results=[]
for name,mode,scenario in planned:
 for p,h in identity.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
 profile='down-and-recover-v1' if name=='original-control' else 'stall-headroom-zero-latency-diagnostic-v1'
 cmd=['python3','-B','tool/playback_network/abr_accesslog.py','--products','/private/tmp/yl-boundary-device-build/Build/Products','--directory',str(out/name),'--physical-device','00008140-000C49CC3493001C','--owned-host','192.168.50.196','--duration-seconds','120','--profile',profile,'--recovery-action','auto-reload','--candidate-preparation',mode,'--auto-scenario',scenario]
 if name!='original-control':cmd+=['--profiles',str(base/'latency-profiles.json')]
 print('START',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('x') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,exitCode=p.returncode,seconds=time.monotonic()-start));(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,p.returncode,flush=True)
 for kind,c in [('tests',['get','test-results','summary']),('action',['get','log','--type','action'])]:
  x=subprocess.run(['xcrun','xcresulttool',*c,'--path',str(out/(name+'.xcresult'))],capture_output=True,text=True);(out/(name+'-'+kind+'.json')).write_text(x.stdout)
 if p.returncode:break
