from pathlib import Path
import json
b=Path('/private/tmp/yl-item-preroll');d=json.loads((b/'analysis.json').read_text());out={}
for name,r in d.items():
 es=r.get('events',[]);pauses=[]
 for e in es:
  if 'warmupStartedElapsed' in e:pauses.append(dict(attempt=e['attempt'],warmupSeconds=e['warmupCompletedElapsed']-e['warmupStartedElapsed'],warmupOutcome=e['warmupOutcome'],paused=e.get('preparationPauseApplied'),oldFrameAdvance=e['warmupFramesAfter']-e['warmupFramesBefore'],requests=e['warmupProxyAfter']['admittedRequests'],receivedBytes=e['warmupProxyAfter']['receivedBodyBytes']))
 out[name]=dict(passed=r['passed'],end=r.get('end',{}).get('position'),events=pauses,windows=[{'bitrate':w['windowBitrate'],'reason':w['reason']} for w in r.get('windows',[])],continuity=r['continuity'],policy=r['policy'],finalProxy=r.get('end',{}).get('proxy'))
(b/'media-summary.json').write_text(json.dumps(out,indent=2)+'\n')
for n,r in out.items():print(n,json.dumps({k:v for k,v in r.items() if k not in ['continuity','policy']}))
