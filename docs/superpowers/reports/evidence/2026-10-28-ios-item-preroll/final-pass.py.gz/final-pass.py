from pathlib import Path
import subprocess,json,time,sys,hashlib
b=Path('/private/tmp/yl-item-preroll');deadline=time.monotonic()+900
while True:
 p=b/'media/results.json';r=json.loads(p.read_text()) if p.exists() else []
 if any(x['exitCode'] for x in r):raise SystemExit('media failure requires inspection')
 if len(r)==6:break
 assert time.monotonic()<deadline
 time.sleep(5)
p=Path('tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift');s=p.read_text();old='    onReady() // Explicit diagnostic injection after real readiness, before seek.';assert s.count(old)==1;s=s.replace(old,'    if let reason = rejection() { return finish(reason) }\n'+old);p.write_text(s)
sys.path.insert(0,'tool/consumer_fixtures/apple_flutter')
from media_delivery_fixture_adapter import native_test_source
for platform in ['ios','macos']:Path(f'packages/yl_player/example/{platform}/RunnerTests/{p.name}').write_bytes(native_test_source(p))
print('GUARD FIXED',flush=True)
cmd=json.loads((b/'build-command.json').read_text());(b/'final-build-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (b/'final-build.log').open('x') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(b/'final-build-result.json').write_text(json.dumps(dict(exitCode=r.returncode))+'\n');assert r.returncode==0
print('FINAL BUILD PASS',flush=True)
identity=json.loads((b/'media/source-identity.json').read_text())
identity={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in identity};(b/'media/final-source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
cmd=['python3','-B','tool/playback_network/abr_accesslog.py','--products','/private/tmp/yl-boundary-device-build/Build/Products','--directory',str(b/'media/final-warm-pause'),'--physical-device','00008140-000C49CC3493001C','--owned-host','192.168.50.196','--duration-seconds','120','--profile','stall-headroom-zero-latency-diagnostic-v1','--profiles',str(b/'latency-profiles.json'),'--recovery-action','auto-reload','--candidate-preparation','asset-preroll','--auto-scenario','pause-during-preparation']
(b/'media/final-warm-pause-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (b/'media/final-warm-pause.log').open('x') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(b/'media/final-warm-pause-result.json').write_text(json.dumps(dict(exitCode=r.returncode))+'\n')
for kind,c in [('tests',['get','test-results','summary']),('action',['get','log','--type','action'])]:
 x=subprocess.run(['xcrun','xcresulttool',*c,'--path',str(b/'media/final-warm-pause.xcresult')],capture_output=True,text=True);(b/('media/final-warm-pause-'+kind+'.json')).write_text(x.stdout)
for p,h in identity.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
print('FINAL MEDIA',r.returncode,flush=True);assert r.returncode==0
