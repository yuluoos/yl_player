from pathlib import Path
import sys
p=Path('tool/playback_network/abr_accesslog.py');s=p.read_text().replace("('manifest-only', 'asset-metadata')", "('manifest-only', 'asset-metadata', 'item-preroll')").replace("if mode == 'asset-metadata' and", "if mode != 'manifest-only' and").replace("    return mode\n", "    if getattr(args, 'auto_scenario', 'normal') == 'pause-during-preparation' and mode != 'item-preroll':\n        raise ValueError('mid-preparation pause requires preroll')\n    return mode\n",1).replace("('normal', 'pause-first')", "('normal', 'pause-first', 'pause-during-preparation')");p.write_text(s)
p=Path('tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift');s=p.read_text();a=s.index('// Diagnostic only: the final backend');b=s.index('private enum AbrDiagnosticCaptureURL {',a);s=s[:a]+Path('/private/tmp/yl-item-preroll/helper-green.swift').read_text()+s[b:]
s=s.replace('  @MainActor func testPrerollCandidateAborts',Path('/private/tmp/yl-item-preroll/additional-tests.swift').read_text()+'  @MainActor func testPrerollCandidateAborts',1)
s=s.replace('["normal", "pause-first"]', '["normal", "pause-first", "pause-during-preparation"]')
s=s.replace('["manifest-only", "asset-metadata"]', '["manifest-only", "asset-metadata", "item-preroll"]')
needle='    if startupDelayMs > 0 { try await Task.sleep'
s=s.replace(needle,'''    guard autoScenario != "pause-during-preparation" || candidatePreparation == "item-preroll" else {
      XCTFail("Mid-preparation pause requires preroll"); return
    }
'''+needle,1)
s=s.replace('    let player = AVPlayer()\n    let output = AppleTestTexture()', '    let player = AVPlayer()\n    var warmedItem: AVPlayerItem?\n    let output = AppleTestTexture()',1)
s=s.replace('configuration: .init(map: ["audioPolicy": "appManaged"]), player: player,\n        emit:', '''configuration: .init(map: ["audioPolicy": "appManaged"]), player: player,
        makePlayerItem: { asset in
          if let item = warmedItem, item.asset === asset {
            warmedItem = nil
            return item
          }
          return AVPlayerItem(asset: asset)
        },
        emit:''',1)
s=s.replace('          var preparationSucceeded = true\n', '          var preparationSucceeded = true\n          var prerolledItem: AVPlayerItem?\n          defer { warmedItem = nil }\n',1)
needle='          event["preparationCompletedElapsed"] = ProcessInfo.processInfo.systemUptime - started'
branch='''          if candidatePreparation == "item-preroll" {
            let warmupStarted = ProcessInfo.processInfo.systemUptime
            event["warmupStartedElapsed"] = warmupStarted - started
            event["warmupProxyBefore"] = replacement.loader.diagnosticProxySnapshot
            event["warmupFramesBefore"] = frameCount
            event["warmupPositionBefore"] = finite(CMTimeGetSeconds(player.currentTime()))
            event["preparationPauseApplied"] = false
            let prepared = await AbrDiagnosticPreroll.prepare(replacement.asset, position: player.currentTime(),
              deadlineUptime: min(warmupStarted + 2, started + ticket.due + 5),
              allowed: { automaticPolicy.authorizes(ticket, automaticSample()) && player.currentItem === item },
              onReady: {
                if autoScenario == "pause-during-preparation", ticket.attempt == 1 {
                  try? backend?.pause(); automaticPolicy.invalidateIntent()
                  event["preparationPauseApplied"] = true
                  event["preparationPauseElapsed"] = ProcessInfo.processInfo.systemUptime - started
                  resumeTask = Task { @MainActor in
                    do { try await Task.sleep(nanoseconds: 2_000_000_000); try backend?.play() }
                    catch { /* Cancellation cannot resume disposed output. */ }
                  }
                }
              }, cancelPending: { replacement.discard() })
            event["warmupOutcome"] = prepared.outcome
            event["warmupStage"] = prepared.stage
            event["warmupDetached"] = prepared.detached
            event["warmupCompletedElapsed"] = ProcessInfo.processInfo.systemUptime - started
            event["warmupProxyAfter"] = replacement.loader.diagnosticProxySnapshot
            event["warmupFramesAfter"] = frameCount
            event["warmupPositionAfter"] = finite(CMTimeGetSeconds(player.currentTime()))
            event["warmupOldItemRetained"] = player.currentItem === item
            preparationSucceeded = prepared.outcome == "ready" && prepared.detached && prepared.item != nil
            prerolledItem = prepared.item
          }
'''
s=s.replace(needle,branch+needle,1)
s=s.replace('            try XCTUnwrap(backend).replaceActiveDash(source: source, prepared: replacement)\n            event["outcome"]', '''            warmedItem = prerolledItem
            try XCTUnwrap(backend).replaceActiveDash(source: source, prepared: replacement)
            if let prerolledItem { event["prerolledItemInstalled"] = player.currentItem === prerolledItem }
            event["outcome"]''',1)
p.write_text(s);Path('/private/tmp/yl-item-preroll/native-green.swift').write_text(s)
sys.path.insert(0,'tool/consumer_fixtures/apple_flutter');from media_delivery_fixture_adapter import native_test_source
for platform in ['ios','macos']:Path('packages/yl_player/example/'+platform+'/RunnerTests/'+p.name).write_bytes(native_test_source(p))
p=Path('tool/consumer_fixtures/apple_flutter/main_example_tests.py');p.write_text(p.read_text().replace("'ios': 829", "'ios': 832").replace("'macos': 873", "'macos': 876"))
p=Path('/private/tmp/yl-item-preroll/run-focused.py');s=p.read_text();s=s.replace("'-resultBundlePath',", "'-only-testing:RunnerTests/YlDashResourceLoaderTests/testPrerollCandidateHandsOffAndCancelsAfterRealReadiness','-only-testing:RunnerTests/YlDashResourceLoaderTests/testFailedPreparationAndRevokedTicketNeverRefundSourceBudget','-resultBundlePath',");p.write_text(s)
