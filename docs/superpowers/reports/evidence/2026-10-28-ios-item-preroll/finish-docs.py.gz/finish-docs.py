from pathlib import Path
import json,subprocess,hashlib
b=Path('/private/tmp/yl-item-preroll')
subprocess.run(['python3','-B',str(b/'analyze.py')],check=True)
subprocess.run(['python3','-B',str(b/'write-report.py')],check=True)
counts={}
for k in ['device','macos']:
 d=json.loads((b/(k+'-contracts-summary.json')).read_text());print(k,d)
 counts[k]={x:d[x] for x in ['passedTests','failedTests','skippedTests','totalTestCount']};assert d['failedTests']==0 and d['skippedTests']==0
 r=subprocess.run(['xcrun','xcresulttool','get','test-results','tests','--path',str(b/(k+'-contracts.xcresult'))],capture_output=True,text=True);assert r.returncode==0;(b/(k+'-contracts-tests.json')).write_text(r.stdout)
assert counts['device']['passedTests']==167 and counts['macos']['passedTests']==142
for r in json.loads((b/'checks/results.json').read_text()):assert r['exitCode']==0
p=Path('docs/superpowers/reports/2026-10-28-ios-item-preroll.md');s=p.read_text().replace('FINAL_TESTS_PENDING','最终 iPhone 七类167项、macOS六类142项通过，均0失败/0跳过；完整测试树保存。包含DASH loader、Apple session/publication、network byte source、platform services、nonblocking metadata，以及仅iOS现有live reconnect类。网络工具114项、完整benchmark发现入口294项（含15项台账测试）通过；镜像声明iOS832/macOS876及固定历史来源检查通过。声明数不等于执行数，无媒体环境的探针不代表媒体验收。结构检查通过，两个require-ready仍按未就绪退出1。未将这些受影响范围回归当作完整Dart/Android/全部Apple/独立消费者验收。')
p.write_text(s)
plan=Path('docs/superpowers/plans/2026-10-28-ios-item-preroll.md');plan.write_text(plan.read_text().replace('- [ ]','- [x]'))
p=Path('tool/release_readiness/inventory.json');d=json.loads(p.read_text());key='ios-item-preroll-20261028';report=Path('docs/superpowers/reports/2026-10-28-ios-item-preroll.md');d['evidence'][key]=dict(path=str(report),sha256=hashlib.sha256(report.read_bytes()).hexdigest(),kind='report')
for r in d['rows']:
 if (r['requirement']=='CAP-ABR' and r['platform'] in ['ios','macos']) or (r['requirement']=='CAP-DASH' and r['platform']=='ios'):
  if key not in r['evidence']:r['evidence'].append(key)
  if r['requirement']=='CAP-ABR' and r['platform']=='ios':r['nextAction']='reproduce-original-stall-and-trigger-qualify-shorter-frame-gap-and-physical-continuity-with-full-intent-race-matrix'
p.write_text(json.dumps(d,indent=2)+'\n')
