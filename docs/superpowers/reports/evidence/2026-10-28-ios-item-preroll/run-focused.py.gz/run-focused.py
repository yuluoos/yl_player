from pathlib import Path
import subprocess,json,sys
b=Path('/private/tmp/yl-item-preroll');name=sys.argv[1]
cmd=['xcodebuild','test','-quiet','-workspace','packages/yl_player/example/ios/Runner.xcworkspace','-scheme','Runner','-configuration','Debug','-destination','platform=iOS,id=00008140-000C49CC3493001C','-derivedDataPath','/private/tmp/yl-boundary-device-build','-allowProvisioningUpdates','DEVELOPMENT_TEAM=JAKM34U2X8','CODE_SIGNING_ALLOWED=YES','-parallel-testing-enabled','NO','-only-testing:RunnerTests/YlDashResourceLoaderTests/testPrerollCandidateAbortsExpiredDeniedAndRevokedIntent','-only-testing:RunnerTests/YlDashResourceLoaderTests/testPrerollCandidateCreatesFreshItemAndCancelsAfterRealReadiness','-only-testing:RunnerTests/YlDashResourceLoaderTests/testFailedPreparationAndRevokedTicketNeverRefundSourceBudget','-resultBundlePath',str(b/(name+'.xcresult'))]
assert not (b/(name+'.xcresult')).exists();(b/(name+'-command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
with (b/(name+'.log')).open('x') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(b/(name+'-result.json')).write_text(json.dumps(dict(exitCode=p.returncode))+'\n')
for kind,c in [('summary',['get','test-results','summary']),('action',['get','log','--type','action'])]:
 r=subprocess.run(['xcrun','xcresulttool',*c,'--path',str(b/(name+'.xcresult'))],capture_output=True,text=True);(b/(name+'-'+kind+'.json')).write_text(r.stdout)
print(name,p.returncode)
