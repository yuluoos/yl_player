from pathlib import Path
import subprocess,json,time,concurrent.futures
b=Path('/private/tmp/yl-item-preroll');deadline=time.monotonic()+1200
p=b/'media/final-warm-pause-result.json'
while not p.exists():
 assert time.monotonic()<deadline
 time.sleep(5)
assert json.loads(p.read_text())['exitCode']==0
print('BEGIN UNIFIED',flush=True)
commands=[['python3','-B',str(b/'run-native.py'),'device'],['python3','-B',str(b/'run-native.py'),'macos'],['python3','-B',str(b/'run-checks.py')]]
def run(cmd):
 r=subprocess.run(cmd,capture_output=True,text=True);print(r.stdout,r.stderr,flush=True);return dict(command=cmd,exitCode=r.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as e:results=list(e.map(run,commands))
(b/'unified-results.json').write_text(json.dumps(results,indent=2)+'\n');print('END UNIFIED',flush=True)
