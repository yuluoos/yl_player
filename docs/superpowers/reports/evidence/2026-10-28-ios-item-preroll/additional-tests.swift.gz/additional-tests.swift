  @MainActor func testPrerollCandidateHandsOffAndCancelsAfterRealReadiness() async throws {
    let frameworks = try XCTUnwrap(Bundle.main.privateFrameworksURL)
    let app = try XCTUnwrap(Bundle(url: frameworks.appendingPathComponent("App.framework")))
    let media = try XCTUnwrap(app.resourceURL).appendingPathComponent(
      "flutter_assets/assets/test_media/format_matrix/mp4-avc-aac.mp4")
    var cleanups = 0
    let result = await AbrDiagnosticPreroll.prepare(AVURLAsset(url: media),
      position: CMTime(value: 1, timescale: 1), deadlineUptime: ProcessInfo.processInfo.systemUptime + 2,
      allowed: { true }, cancelPending: { cleanups += 1 })
    XCTAssertEqual(result.outcome, "ready"); XCTAssertEqual(result.stage, "ready")
    XCTAssertTrue(result.detached); XCTAssertEqual(cleanups, 0)
    let item = try XCTUnwrap(result.item)
    let receiving = AVPlayer()
    defer { receiving.pause(); receiving.replaceCurrentItem(with: nil) }
    receiving.isMuted = true; receiving.replaceCurrentItem(with: item); receiving.play()
    try await AppleHostCharacterizations.waitFor({ CMTimeGetSeconds(receiving.currentTime()) >= 1.1 }, timeout: 5)
    var allowed = true, readyCalls = 0
    let cancelled = await AbrDiagnosticPreroll.prepare(AVURLAsset(url: media), position: .zero,
      deadlineUptime: ProcessInfo.processInfo.systemUptime + 2, allowed: { allowed },
      onReady: { readyCalls += 1; allowed = false }, cancelPending: { cleanups += 1 })
    XCTAssertEqual(readyCalls, 1); XCTAssertEqual(cancelled.outcome, "cancelled")
    XCTAssertTrue(cancelled.detached); XCTAssertNil(cancelled.item); XCTAssertEqual(cleanups, 1)
  }

  func testFailedPreparationAndRevokedTicketNeverRefundSourceBudget() throws {
    var policy = AbrDiagnosticRecoveryPolicy()
    func sample(_ time: Double, width: Int = 320) -> AbrDiagnosticRecoveryPolicy.Sample {
      .init(time: time, generation: 0, allowed: true, width: width, position: time,
        remaining: 120 - time, bufferAhead: 10, bytes: Int64(time * 200_000),
        transfer: time, requests: Int(time * 4), overdue: 1)
    }
    _ = policy.observe(sample(0, width: 640))
    for time in [1.0, 9, 17] { XCTAssertNil(policy.observe(sample(time))) }
    let first = try XCTUnwrap(policy.observe(sample(17.5)))
    XCTAssertEqual(first.attempt, 1); XCTAssertEqual(first.due, 17.5)
    policy.invalidateIntent(); policy.finish(first)
    XCTAssertFalse(policy.authorizes(first, sample(18)))
    XCTAssertEqual(policy.attempts, 1)
    for time in [20.0, 28, 36] { XCTAssertNil(policy.observe(sample(time))) }
    XCTAssertNil(policy.observe(sample(36.99)))
    let second = try XCTUnwrap(policy.observe(sample(37)))
    XCTAssertEqual(second.attempt, 2); XCTAssertEqual(second.due, 37)
    policy.finish(second) // The second preparation failed; its budget stays spent.
    for time in 38...99 { XCTAssertNil(policy.observe(sample(Double(time)))) }
    XCTAssertEqual(policy.attempts, 2)
    XCTAssertEqual(policy.decision["reason"] as? String, "budgetExhausted")
  }

