from pathlib import Path
import sys
base=Path('/private/tmp/yl-item-preroll');p=Path('tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift');s=p.read_text();(base/'native-transfer-crash.swift').write_text(s)
s=s.replace('item-preroll', 'asset-preroll').replace('testPrerollCandidateHandsOffAndCancelsAfterRealReadiness','testPrerollCandidateCreatesFreshItemAndCancelsAfterRealReadiness')
s=s.replace('-> (outcome: String, item: AVPlayerItem?, detached: Bool, stage: String)', '-> (outcome: String, item: AVPlayerItem?, detached: Bool, stage: String, reusesPrerolledItem: Bool)')
s=s.replace('      candidate?.pause(); candidate?.cancelPendingPrerolls()', '      let reusesPrerolledItem = item != nil && item === candidate?.currentItem\n      candidate?.pause(); candidate?.cancelPendingPrerolls()',1)
s=s.replace('return (outcome, item, candidate?.currentItem == nil, stage)', 'return (outcome, item, candidate?.currentItem == nil, stage, reusesPrerolledItem)',1)
s=s.replace('    return finish("ready", item: item)', '''    // A detached, prerolled AVPlayerItem still raised a cross-player association
    // exception on the physical device. Never transfer it. Only share the asset;
    // a fresh item must perform the backend's normal exact resume seek again.
    return finish("ready", item: AVPlayerItem(asset: asset))''',1)
s=s.replace('XCTAssertTrue(result.detached); XCTAssertEqual(cleanups, 0)', 'XCTAssertTrue(result.detached); XCTAssertFalse(result.reusesPrerolledItem); XCTAssertEqual(cleanups, 0)',1)
s=s.replace('receiving.isMuted = true; receiving.replaceCurrentItem(with: item); receiving.play()', '''receiving.isMuted = true; receiving.replaceCurrentItem(with: item)
    receiving.seek(to: CMTime(value: 1, timescale: 1), toleranceBefore: .zero, toleranceAfter: .zero)
    receiving.play()''',1)
s=s.replace('var prerolledItem:', 'var freshPreparedItem:').replace('prerolledItem = prepared.item', 'freshPreparedItem = prepared.item').replace('warmedItem = prerolledItem','warmedItem = freshPreparedItem').replace('if let prerolledItem { event["prerolledItemInstalled"] = player.currentItem === prerolledItem }','if let freshPreparedItem { event["freshPreparedItemInstalled"] = player.currentItem === freshPreparedItem }')
s=s.replace('event["warmupDetached"] = prepared.detached','event["warmupDetached"] = prepared.detached\n            event["warmupReusesPrerolledItem"] = prepared.reusesPrerolledItem')
s=s.replace('prepared.detached && prepared.item != nil','prepared.detached && !prepared.reusesPrerolledItem && prepared.item != nil')
guard='''    guard autoScenario != "pause-during-preparation" || candidatePreparation == "asset-preroll" else {
      XCTFail("Mid-preparation pause requires preroll"); return
    }
'''
s=s.replace(guard,'');s=s.replace('    // Preserve the historical managed probe',guard+'    // Preserve the historical managed probe',1)
p.write_text(s);(base/'native-fresh.swift').write_text(s)
sys.path.insert(0,'tool/consumer_fixtures/apple_flutter');from media_delivery_fixture_adapter import native_test_source
for platform in ['ios','macos']:Path('packages/yl_player/example/'+platform+'/RunnerTests/'+p.name).write_bytes(native_test_source(p))
for name in ['abr_accesslog.py','test_abr_accesslog.py']:
 p=Path('tool/playback_network')/name;p.write_text(p.read_text().replace('item-preroll','asset-preroll'))
p=base/'run-focused.py';p.write_text(p.read_text().replace('testPrerollCandidateHandsOffAndCancelsAfterRealReadiness','testPrerollCandidateCreatesFreshItemAndCancelsAfterRealReadiness'))
