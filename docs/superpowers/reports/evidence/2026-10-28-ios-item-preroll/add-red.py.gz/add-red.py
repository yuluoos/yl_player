from pathlib import Path
import sys
base=Path('/private/tmp/yl-item-preroll');old=Path('/private/tmp/yl-preroll/native-red.swift').read_text()
helper=old[old.index('// Diagnostic only: the final backend'):old.index('private enum AbrDiagnosticCaptureURL {')]
helper=helper.replace('allowed: () -> Bool, cancelPending:', 'allowed: () -> Bool, onReady: () -> Void = {}, cancelPending:')
test=old[old.index('  @MainActor func testPrerollCandidateAborts'):old.index('  @MainActor func testCandidateMetadataPreparationRejects')]
p=Path('tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift');s=p.read_text().replace('private enum AbrDiagnosticCaptureURL {',helper+'private enum AbrDiagnosticCaptureURL {').replace('  @MainActor func testCandidateMetadataPreparationRejectsExpiredAndFailedAssets()',test+'  @MainActor func testCandidateMetadataPreparationRejectsExpiredAndFailedAssets()');p.write_text(s)
sys.path.insert(0,'tool/consumer_fixtures/apple_flutter');from media_delivery_fixture_adapter import native_test_source
for platform in ['ios','macos']:Path('packages/yl_player/example/'+platform+'/RunnerTests/'+p.name).write_bytes(native_test_source(p))
(base/'native-red.swift').write_text(s)
p=Path('tool/playback_network/test_abr_accesslog.py');s=p.read_text();old=Path('/private/tmp/yl-preroll/draft-network/test_abr_accesslog.py').read_text();test=old[old.index('    def test_preroll_requires'):old.index('    def test_candidate_preparation_requires_native_echo')];s=s.replace('    def test_candidate_preparation_requires_native_echo',test+'    def test_candidate_preparation_requires_native_echo');p.write_text(s)
s=Path('/private/tmp/yl-preroll/run-focused.py').read_text().replace('/private/tmp/yl-preroll','/private/tmp/yl-item-preroll').replace('testAudioRouteLossPausesIntentWithoutNetworkTimeoutAndRequiresExplicitResume','testPrerollCandidateAbortsExpiredDeniedAndRevokedIntent');(base/'run-focused.py').write_text(s)
