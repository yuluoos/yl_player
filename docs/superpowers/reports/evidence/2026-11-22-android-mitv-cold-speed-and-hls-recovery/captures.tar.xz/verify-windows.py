"""Run with the path to captures.tar.xz to check the final rolling-window samples."""
import json
import re
import sys
import tarfile

with tarfile.open(sys.argv[1]) as archive:
    rounds = [m.name.split('/')[0] for m in archive if re.fullmatch(r'hls-\d+/observations.log', m.name)]
    last = max(rounds, key=lambda name: int(name.split('-')[1]))
    logs = archive.extractfile(f'{last}/observations.log').read().decode().splitlines()
    requests = json.load(archive.extractfile(f'{last}-source/receipt.json'))['requests']
    samples = [json.loads(line.split('=', 1)[1]) for line in logs if line.startswith('YL_HLS_RESUME=')]
    assert {s['mode'] for s in samples} == {'smoothPlayback', 'lowLatency'}
    for sample in samples:
        before, after = (requests[sample[key]] for key in ('requestAtResume', 'requestAtEnd'))
        assert before['path'] == after['path'] == '/live.m3u8'
        segments = [int(match[1]) for req in requests
                    if req['startUs'] > before['endUs'] and req.get('endUs', after['endUs']) < after['startUs']
                    and req['bytes'] and (match := re.fullmatch(r'/segment(\d+)\.ts', req['path']))]
        assert max(segments) > sample['newWindow'][1]
        assert sample['newWindow'][0] > sample['oldWindow'][1]
        assert sample['advanceUs'] >= 500_000 and min(sample['frames'], sample['followFrames']) > 0
        print(sample['mode'], 'newest segment', max(segments), 'final frame delta', sample['followFrames'])
