from pathlib import Path
import json
b=Path('/private/tmp/yl-preparation-intent');d=json.loads((b/'analysis.json').read_text());out={}
for name,r in d.items():
 out[name]=dict(end=r.get('end',{}).get('position'),capturePassed=r['passed'],windows=[dict(bitrate=w['windowBitrate'],reason=w['reason'],elapsed=w['elapsed']) for w in r.get('windows',[])],events=r['events'],continuity=r['continuity'],finalProxy=r.get('end',{}).get('proxy'),reasons=r.get('reasons'))
 if name=='preroll-seek' and r['events']:
  first=r['events'][0];target=first.get('preparationSeekTargetMs');start=first.get('preparationSeekElapsed')
  frames=[json.loads(x) for x in (b/'media'/name/'frame-samples.jsonl').read_text().splitlines()]
  matching=[f for f in frames if target is not None and start is not None and start<=f['elapsed']<=start+1 and f['generation']==0 and f['frames']>0 and target/1000<=f['position']<=target/1000+.25]
  out[name]['seekLandingObservation']=dict(injectionApplied=first.get('preparationSeekApplied') is True,targetMs=target,firstPublishedNearTarget=matching[0] if matching else None,withinOneSecond=bool(matching),oldGeneration=0,capabilityAccepted=False)
(b/'intent-proof.json').write_text(json.dumps(out,indent=2)+'\n')
for n,r in out.items():print(n, r['capturePassed'],r['end'],r.get('seekLandingObservation'),r['windows'])
