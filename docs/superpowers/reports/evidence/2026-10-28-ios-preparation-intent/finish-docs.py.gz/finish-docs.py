from pathlib import Path
import json,subprocess,hashlib,collections
b=Path('/private/tmp/yl-preparation-intent')
for name in ['analyze.py','intent-proof.py','write-report.py']:subprocess.run(['python3','-B',str(b/name)],check=True)
scope={}
for kind,total in [('device',170),('macos',145)]:
 d=json.loads((b/(kind+'-contracts-summary.json')).read_text());assert d['passedTests']==total and d['failedTests']==d['skippedTests']==0
 r=subprocess.run(['xcrun','xcresulttool','get','test-results','tests','--path',str(b/(kind+'-contracts.xcresult'))],capture_output=True,text=True);assert r.returncode==0;(b/(kind+'-contracts-tests.json')).write_text(r.stdout);cases=[]
 def walk(n):
  if n.get('nodeType')=='Test Case':cases.append(n)
  for c in n.get('children',[]):walk(c)
 for n in json.loads(r.stdout)['testNodes']:walk(n)
 assert len(cases)==total and all(c['result']=='Passed' for c in cases)
 scope[kind]=dict(total=total,classes=dict(collections.Counter(c['nodeIdentifier'].split('/')[0] for c in cases)),results=dict(collections.Counter(c['result'] for c in cases)))
(b/'native-scope.json').write_text(json.dumps(scope,indent=2)+'\n')
for r in json.loads((b/'checks/results.json').read_text()):assert r['exitCode']==0
p=Path('docs/superpowers/reports/2026-10-28-ios-preparation-intent.md');s=p.read_text().replace('FINAL_TESTS_PENDING','最终iPhone七类170项、macOS六类145项通过，均0失败/0跳过。范围为DASH loader、Apple session/publication、network byte source、platform services、nonblocking metadata，以及仅iOS存在的live reconnect；完整测试树与类计数保存。网络工具115项、benchmark全发现294项（含15项台账测试）、镜像/固定历史来源及diff检查通过。无媒体环境的探针不会进行媒体测试，四轮媒体另列。未将受影响范围回归当作完整Dart/Android/全部Apple/独立消费者验收。')
d=json.loads((b/'intent-proof.json').read_text());details=[]
for name in ['original-1','original-2']:
 r=d[name];windows=r['windows'];details.append(f"{name}：片尾{r['end']:.6f}秒，窗口bitrate="+','.join(f"{w['bitrate']:.0f}" for w in windows)+f"，票据{len(r['events'])}张。完整策略原因与代理边界见intent-proof.json；本轮未复现历史63.900秒终末停顿，不能据此宣布修复。")
for name in ['metadata-pause','preroll-seek']:
 r=d[name];events=r['events']
 if not events:
  details.append(name+'没有发出恢复票据，注入仍未验证。');continue
 e=events[0];proxy=e.get('warmupProxyAfter',{});label='metadataPauseApplied' if name=='metadata-pause' else 'preparationSeekApplied'
 details.append(f"{name}首票：{label}={e.get(label)}，warmup={e.get('warmupOutcome')}，外层结果={e['outcome']}，旧item保留={e.get('warmupOldItemRetained')}；候选代理接收{proxy.get('admittedRequests')}次、活动任务{proxy.get('activeTasks')}、待发送{proxy.get('pendingSends')}。本轮共{len(events)}张票据，源级预算未退回。全程最大新帧间隔{r['continuity']['maximumPublishedFrameGapMs']:.3f}ms，不能只报告替换边界。")
 if name=='metadata-pause' and proxy.get('admittedRequests')==0:details.append('此媒体注入发生在代理接收请求之前；真实在途请求取消由intent-green原生挂起请求测试单独覆盖。')
 if name=='preroll-seek':
  proof=r.get('seekLandingObservation',{});frame=proof.get('firstPublishedNearTarget')
  if frame:details.append(f"用户seek目标{proof['targetMs']}ms；旧generation=0在elapsed={frame['elapsed']:.6f}秒出现新帧提交，同条采样的播放时钟为{frame['position']:.6f}秒，在调用后1秒内且目标后250ms范围内。旧恢复票据取消，未用它替换item；这是采样落点证据，不是物理音画或所有seek竞态验收。")
  else:details.append('未观察到调用后1秒内旧generation在目标附近发布新帧，落点验证仍未通过。')

details.append('原配置1在首窗合格后、第二8秒窗完成前已自然升高档；原配置2九个完整窗658792–881858bit/s全部低于955000，故零票据符合冻结规则。没有满足原双窗口条件却漏触发的证据。')
s=s.replace('MEDIA_DETAILS_PENDING','\n\n'.join(details)+'\n\n连续性、物理输出与音画同步验收标志仍为false。主动暂停、用户seek与替换间隔分别记录，不能将其中一次较短间隔泛化为连续性或性能改善。')
p.write_text(s)
p=Path('tool/release_readiness/inventory.json');d=json.loads(p.read_text());key='ios-preparation-intent-20261028';report=Path('docs/superpowers/reports/2026-10-28-ios-preparation-intent.md');d['evidence'][key]=dict(path=str(report),sha256=hashlib.sha256(report.read_bytes()).hexdigest(),kind='report')
for r in d['rows']:
 if (r['requirement']=='CAP-ABR' and r['platform'] in ['ios','macos']) or (r['requirement']=='CAP-DASH' and r['platform']=='ios'):
  if key not in r['evidence']:r['evidence'].append(key)
  if r['requirement']=='CAP-ABR' and r['platform']=='ios':r['nextAction']='reproduce-original-stall-and-qualify-credential-constraint-races-shorter-frame-gap-and-physical-output-matrix'
p.write_text(json.dumps(d,indent=2)+'\n')
