from pathlib import Path
import sys
p=Path('tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift');s=p.read_text()
s=s.replace('    guard !Task.isCancelled else { return abort("cancelled") }','    guard !Task.isCancelled, allowed() else { return abort("cancelled") }',1)
s=s.replace('    asset.loadValuesAsynchronously(forKeys: keys, completionHandler: {})\n    while !Task.isCancelled {','    asset.loadValuesAsynchronously(forKeys: keys, completionHandler: {})\n    onStarted() // Diagnostic injection only after the loading operation is issued.\n    while !Task.isCancelled {\n      guard allowed() else { return abort("cancelled") }',1)
s=s.replace('      if allLoaded {\n        if asset.isPlayable','      if allLoaded {\n        guard !Task.isCancelled, allowed() else { return abort("cancelled") }\n        guard ProcessInfo.processInfo.systemUptime < deadlineUptime else { return abort("timedOut") }\n        if asset.isPlayable',1)
s=s.replace('allowed: () -> Bool, onReady: () -> Void = {}, cancelPending: () -> Void) async','allowed: () -> Bool, onReady: () -> Void = {},\n    onOperationStarted: (String) -> Void = { _ in }, cancelPending: () -> Void) async',1)
s=s.replace('player.seek(to: position, toleranceBefore: .zero, toleranceAfter: .zero) { seek.finish($0) }\n    while','player.seek(to: position, toleranceBefore: .zero, toleranceAfter: .zero) { seek.finish($0) }\n    onOperationStarted(stage)\n    while',1)
s=s.replace('player.preroll(atRate: 1) { preroll.finish($0) }\n    while','player.preroll(atRate: 1) { preroll.finish($0) }\n    onOperationStarted(stage)\n    while',1)
s=s.replace('    allowed = false\n    let result = await operation.value','    allowed = false\n    await fulfillment(of: [cancelled], timeout: 1)\n    let result = await operation.value',1)
s=s.replace('    XCTAssertEqual(result, "cancelled", "Revoked intent must cancel, not wait for the deadline")\n    await fulfillment(of: [cancelled], timeout: 1)','    XCTAssertEqual(result, "cancelled", "Revoked intent must cancel, not wait for the deadline")',1)
mark='  @MainActor func testCandidateMetadataPreparationRejectsExpiredAndFailedAssets() async {'
new='''  @MainActor func testMetadataPreparationRejectsDeniedIntentAndTaskCancellation() async {
    var cleanups = 0, starts = 0
    let absent = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".mp4")
    let denied = await AbrDiagnosticCandidatePreparation.loadMetadata(AVURLAsset(url: absent),
      deadlineUptime: ProcessInfo.processInfo.systemUptime + 2, allowed: { false },
      onStarted: { starts += 1 }, cancelPending: { cleanups += 1 })
    XCTAssertEqual(denied, "cancelled"); XCTAssertEqual(starts, 0); XCTAssertEqual(cleanups, 1)
    let started = expectation(description: "task-cancel metadata request entered")
    let cancelled = expectation(description: "task cancellation terminates requests")
    let held = AbrHeldMetadataLoader(started: started, cancelled: cancelled)
    let asset = AVURLAsset(url: URL(string: "yl-task-test://owned/\\(UUID().uuidString)/master.m3u8")!)
    asset.resourceLoader.setDelegate(held, queue: DispatchQueue(label: "yl.metadata.task"))
    let operation = Task { @MainActor in
      await AbrDiagnosticCandidatePreparation.loadMetadata(asset,
        deadlineUptime: ProcessInfo.processInfo.systemUptime + 2, cancelPending: { held.cancelAll() })
    }
    await fulfillment(of: [started], timeout: 1)
    operation.cancel()
    await fulfillment(of: [cancelled], timeout: 1)
    let result = await operation.value
    XCTAssertEqual(result, "cancelled"); XCTAssertEqual(held.cancellationState.pending, 0)
    XCTAssertEqual(held.cancellationState.owner, 1); XCTAssertGreaterThan(held.cancellationState.terminated, 0)
    withExtendedLifetime(held) {}
  }

  @MainActor func testPrerollPreparationCancelsAfterSeekAndPrerollAreIssued() async throws {
    let frameworks = try XCTUnwrap(Bundle.main.privateFrameworksURL)
    let app = try XCTUnwrap(Bundle(url: frameworks.appendingPathComponent("App.framework")))
    let media = try XCTUnwrap(app.resourceURL).appendingPathComponent(
      "flutter_assets/assets/test_media/format_matrix/mp4-avc-aac.mp4")
    for target in ["seeking", "preroll"] {
      var allowed = true, injected = 0, cleanups = 0
      let result = await AbrDiagnosticPreroll.prepare(AVURLAsset(url: media),
        position: CMTime(value: 1, timescale: 1), deadlineUptime: ProcessInfo.processInfo.systemUptime + 2,
        allowed: { allowed }, onOperationStarted: { stage in
          if stage == target { injected += 1; allowed = false }
        }, cancelPending: { cleanups += 1 })
      XCTAssertEqual(injected, 1, target); XCTAssertEqual(result.stage, target)
      XCTAssertEqual(result.outcome, "cancelled"); XCTAssertTrue(result.detached)
      XCTAssertNil(result.item); XCTAssertFalse(result.reusesPrerolledItem); XCTAssertEqual(cleanups, 1)
    }
  }

'''
assert mark in s;s=s.replace(mark,new+mark,1)
s=s.replace('["normal", "pause-first", "pause-during-preparation"]','["normal", "pause-first", "pause-during-preparation", "pause-during-metadata", "seek-during-preparation"]',1)
s=s.replace('guard autoScenario != "pause-during-preparation" || candidatePreparation == "asset-preroll" else {','guard !["pause-during-preparation", "seek-during-preparation"].contains(autoScenario) || candidatePreparation == "asset-preroll" else {',1)
needle='    let programmeSeconds = try XCTUnwrap(Int(env["YL_ABR_PROBE_SECONDS"] ?? "40"))'
# Match required metadata mode beside existing preparation guards, not before mode is declared.
needle='    guard autoScenario != "pause-during-preparation"'
idx=s.index('    guard !["pause-during-preparation"')
s=s[:idx]+'''    guard autoScenario != "pause-during-metadata" || candidatePreparation == "asset-metadata" else {
      XCTFail("Metadata intent injection requires metadata preparation"); return
    }
'''+s[idx:]
old='''                deadlineUptime: min(warmupStarted + 2, started + ticket.due + 5),
                cancelPending: { replacement.discard() })'''
new='''                deadlineUptime: min(warmupStarted + 2, started + ticket.due + 5),
                allowed: { automaticPolicy.authorizes(ticket, automaticSample()) && player.currentItem === item },
                onStarted: {
                  if autoScenario == "pause-during-metadata", ticket.attempt == 1 {
                    automaticPolicy.invalidateIntent()
                    do {
                      try XCTUnwrap(backend).pause()
                      event["metadataPauseApplied"] = true
                      event["metadataPauseElapsed"] = ProcessInfo.processInfo.systemUptime - started
                      resumeTask = Task { @MainActor in
                        do { try await Task.sleep(nanoseconds: 2_000_000_000); try backend?.play() }
                        catch { /* Cancellation cannot resume disposed output. */ }
                      }
                    } catch { event["metadataPauseApplied"] = false }
                  }
                }, cancelPending: { replacement.discard() })'''
assert old in s;s=s.replace(old,new,1)
needle='''              onReady: {
                if autoScenario == "pause-during-preparation", ticket.attempt == 1 {'''
new='''              onReady: {
                if autoScenario == "seek-during-preparation", ticket.attempt == 1 {
                  automaticPolicy.invalidateIntent()
                  let target = Int64(CMTimeGetSeconds(player.currentTime()) * 1_000) + 1_000
                  event["preparationSeekTargetMs"] = target
                  do {
                    try XCTUnwrap(backend).seek(toMs: target)
                    event["preparationSeekApplied"] = true
                    event["preparationSeekElapsed"] = ProcessInfo.processInfo.systemUptime - started
                  } catch { event["preparationSeekApplied"] = false }
                }
                if autoScenario == "pause-during-preparation", ticket.attempt == 1 {'''
assert needle in s;s=s.replace(needle,new,1)
p.write_text(s);Path('/private/tmp/yl-preparation-intent/native-green.swift').write_text(s)
sys.path.insert(0,'tool/consumer_fixtures/apple_flutter');from media_delivery_fixture_adapter import native_test_source
for platform in ['ios','macos']:Path(f'packages/yl_player/example/{platform}/RunnerTests/{p.name}').write_bytes(native_test_source(p))
p=Path('tool/consumer_fixtures/apple_flutter/main_example_tests.py');s=p.read_text().replace("{'ios': 832, 'macos': 876}","{'ios': 835, 'macos': 879}");p.write_text(s)
