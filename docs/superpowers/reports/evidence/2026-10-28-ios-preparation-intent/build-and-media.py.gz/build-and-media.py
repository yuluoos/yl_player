from pathlib import Path
import json,subprocess
b=Path('/private/tmp/yl-preparation-intent');cmd=json.loads(Path('/private/tmp/yl-item-preroll/build-command.json').read_text());(b/'build-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (b/'build.log').open('x') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(b/'build-result.json').write_text(json.dumps(dict(exitCode=r.returncode))+'\n');assert r.returncode==0
print('BUILD PASS',flush=True)
r=subprocess.run(['python3','-B',str(b/'run-media.py')]);assert r.returncode==0
