from pathlib import Path
import subprocess,json,time,concurrent.futures,hashlib
b=Path('/private/tmp/yl-preparation-intent');deadline=time.monotonic()+1200
while True:
 p=b/'media/results.json';results=json.loads(p.read_text()) if p.exists() else []
 if any(r['exitCode'] for r in results):raise SystemExit('media failure requires inspection')
 if len(results)==4:break
 assert time.monotonic()<deadline
 time.sleep(5)
for p,h in json.loads((b/'media/source-identity.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
print('BEGIN UNIFIED',flush=True)
commands=[['python3','-B',str(b/'run-native.py'),'device'],['python3','-B',str(b/'run-native.py'),'macos'],['python3','-B',str(b/'run-checks.py')]]
def run(cmd):
 r=subprocess.run(cmd,capture_output=True,text=True);print(r.stdout,r.stderr,flush=True);return dict(command=cmd,exitCode=r.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as e:results=list(e.map(run,commands))
(b/'unified-results.json').write_text(json.dumps(results,indent=2)+'\n');print('END UNIFIED',flush=True)
