from pathlib import Path
import json
b=Path('/private/tmp/yl-preparation-intent');p=b/'intent-proof.json';d=json.loads(p.read_text()) if p.exists() else {};rows=[]
for n in ['original-1','metadata-pause','preroll-seek','original-2']:
 if n not in d:continue
 r=d[n];es=r['events'];desc='；'.join(f"{e['attempt']}:{e['outcome']} / {e.get('warmupOutcome','无')}" for e in es) or '零票据'
 gaps=' / '.join(f"{g['publicationGapMs']:.3f}ms，清空{g['textureClears']}" for g in r['continuity']['replacementBoundaries']) or '无替换'
 rows.append(f"| {n} | {r['capturePassed']} | {r['end']:.6f} | {desc} | {gaps} |")
text='''# iOS 准备期间意图撤销修复与 seek 验证

基线 `af3d138c`，当前本地分支 `codex/abr-recovery`。本轮仅诊断夹具、镜像及工具修改，承接[候选预滚报告](2026-10-28-ios-item-preroll.md)。[完整证据](evidence/2026-10-28-ios-preparation-intent/)保留全部红灯、原始采样、源码身份、完整xcresult及复核记录。不发布。

## 已确认问题与改动

元数据候选仅在准备前检查票据，进入loadMetadata后只看Task取消和期限。票据在真实resource-loader请求挂起后失效，旧实现仍等待2秒期限，返回timedOut。真机 `intent-red` 1失败/0通过，明确断言timedOut不是cancelled。这是诊断准备的取消缺口，不是历史终末停顿的根因证明。

修复在开始、每轮轮询及返回loaded之前重验授权，失效即取消asset加载并释放owned loader请求。保留原2秒期限、原票据5秒有效期和最终旧item/票据复核。新回归在真实请求进入后撤销意图，要求取消通知1秒内到达，且pending=0、owner取消一次、已终止请求数大于0。另测开始前拒绝不发起加载、任务取消与既有超时路径。

预滚helper新增仅供诊断的阶段回调，真实本地mp4等待ready并发出精确seek或preroll请求之后撤销。两阶段均返回cancelled、detach、没有可安装item、资源清理一次。这是请求已发出边界的覆盖，不能代表所有异步竞态或物理输出连续性。

新增两个严格匹配模式的场景：pause-during-metadata仅asset-metadata，在元数据加载调用已发出后暂停/作废首票，2秒后恢复；seek-during-preparation仅asset-preroll，在候选实际ready后先作废首票，再让旧backend向前seek1秒。记录调用是否成功、时刻和目标。元数据注入不保证网络请求已经抵达，实际挂起请求取消由独立原生测试证明。seek调用成功也不等于落点验证，必须结合帧采样。

Python模式不匹配红灯1方法4子失败保留，修复后完整accesslog定向26通过。原生green四方法通过/0失败/0跳过，其中三项新增，一项为既有超时/失败覆盖。镜像声明iOS835/macOS879，声明数不等于执行数。

## 真机采集

沿用授权开发签名，iPhone16（iPhone17,3）/iOS27.2。同一构建预登记四轮顺序；原配置与独立诊断配置分别保存，不以诊断配置代替原配置验收。素材120秒、原生140秒、采集240秒。采集passed只表示该探针完成，注入未实际发生时仍未验证。

| 运行 | 采集passed | 位置（秒） | 票据与准备 | 替换边界新帧间隔 |
| --- | --- | --- | --- | --- |
'''+ '\n'.join(rows)+'''

MEDIA_DETAILS_PENDING

原冻结配置哈希 `4e4f256c59465f4a573d6ab1c48f7a7571294638025088d0cddba9325f5032ea`；零延迟诊断配置 `9f63acdf1ab0ce92c5565bc3a750478f0c6c5ba76cef88c7e1092cfcd89b01f1`。先高后低、有逾期、至少5秒连续缓冲、至少20秒剩余、两个8秒窗/每窗3请求/955000bit/s、源级两次预算与500/1000ms退避不变。取消不退预算，未将旧纹理算作新帧，也未放宽精确seek。

## 集中验收与台账

FINAL_TESTS_PENDING

12组历史证据3010个清单文件逐一校验未变。本轮生产源码身份仍为 `9fd66d341470a59bbc1eca827c85f52e63b81766ce7a0f361477e1abe7db8064`，诊断源码/制品身份单独记录。运行与构建警告保留，未声称已消除。

REVIEW_PENDING

仍保留：旧63.900秒缓冲耗尽停顿的复现和根因、原配置稳定安全自动恢复、缩短替换新帧空档、真实物理路由断开、完整凭据/约束及其他准备阶段竞争、物理音画/字幕连续性、auto/caps/fixed完整矩阵、多设备/最低系统、DRM/Dolby授权及外接输出、历史iOS33失败/1skip。当前预滚方案没有已确认性能收益，生产自动策略未接入。

台账只增加报告/待办，102行全部implementation/verification/acceptance状态保持：67 implemented / 34 partial / 1 unreviewed，69 not_run / 30 external_missing / 3 failed / 0 passed。releaseReady=false。仅本地提交，不合并、不推送、不打标签、不发布。
'''
Path('docs/superpowers/reports/2026-10-28-ios-preparation-intent.md').write_text(text)
