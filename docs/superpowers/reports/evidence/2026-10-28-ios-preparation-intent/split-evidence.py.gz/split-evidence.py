from pathlib import Path
import hashlib,json,tarfile,io
base=Path('docs/superpowers/reports/evidence/2026-10-28-ios-preparation-intent');sha=lambda b:hashlib.sha256(b).hexdigest();raw=json.loads((base/'raw-provenance.json').read_text());split=[]
for row in raw:
 archive=base/row['archive']
 if 'bundleFiles' not in row or archive.stat().st_size<=16*1024*1024:continue
 data=archive.read_bytes();parts=[]
 for index,offset in enumerate(range(0,len(data),15*1024*1024)):
  content=data[offset:offset+15*1024*1024];p=Path(str(archive)+f'.part{index:02d}');p.write_bytes(content);parts.append(dict(path=str(p.relative_to(base)),bytes=len(content),sha256=sha(content)))
 manifest=Path(str(archive)+'.parts.json');manifest.write_text(json.dumps(dict(archiveName=archive.name,bytes=len(data),sha256=sha(data),parts=parts),indent=2)+'\n')
 restored=b''.join((base/p['path']).read_bytes() for p in parts);assert restored==data
 with tarfile.open(fileobj=io.BytesIO(restored),mode='r:gz') as t:assert sum(m.isfile() for m in t.getmembers())==row['bundleFiles']
 row['archive']=str(manifest.relative_to(base));row['archiveParts']=parts;row['archiveSha256']=sha(data);archive.unlink();split.append(dict(archive=archive.name,parts=len(parts),bytes=len(data)))
(base/'raw-provenance.json').write_text(json.dumps(raw,indent=2)+'\n')
(base/'README.md').write_text('''# Raw evidence

All 8 complete xcresult bundles are retained, including the metadata cancellation red assertion. Large bundles are split into ordered 15 MiB chunks with `.parts.json` manifests. Concatenate the manifest paths in their listed order outside the repository, verify each part and the combined SHA-256, then extract the resulting tar.gz. No attachment was removed.

Other `.gz` files decompress to the bytes recorded in `raw-provenance.json`. `SHA256SUMS` covers every archived file, part and manifest. Generated media is bound by the fixture hash and reproducible fixture tooling; media segments and private device inventory are excluded. Four media captures have source/binary identity records. Capture success does not certify physical continuity or complete ABR acceptance. Prior failures are preserved in their original evidence groups; this experiment does not transfer items between players.
''')
files=sorted(p for p in base.rglob('*') if p.is_file() and p.name!='SHA256SUMS');assert max(p.stat().st_size for p in files)<=16*1024*1024
(base/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+str(p.relative_to(base))+'\n' for p in files));print(json.dumps(dict(split=split,entries=len(files))))
