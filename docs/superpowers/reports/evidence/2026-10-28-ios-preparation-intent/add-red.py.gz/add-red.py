from pathlib import Path
import sys
p=Path('tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift');s=p.read_text();s=s.replace('deadlineUptime: Double,\n    cancelPending: () -> Void) async -> String','deadlineUptime: Double,\n    allowed: () -> Bool = { true }, onStarted: () -> Void = {},\n    cancelPending: () -> Void) async -> String',1)
mark='  @MainActor func testCandidateMetadataPreparationRejectsExpiredAndFailedAssets() async {'
test='''  @MainActor func testMetadataPreparationReleasesRequestsWhenIntentIsRevoked() async {
    let started = expectation(description: "real metadata request entered")
    let cancelled = expectation(description: "revocation terminates metadata requests")
    let held = AbrHeldMetadataLoader(started: started, cancelled: cancelled)
    let asset = AVURLAsset(url: URL(string: "yl-intent-test://owned/\\(UUID().uuidString)/master.m3u8")!)
    asset.resourceLoader.setDelegate(held, queue: DispatchQueue(label: "yl.metadata.intent"))
    var allowed = true
    let operation = Task { @MainActor in
      await AbrDiagnosticCandidatePreparation.loadMetadata(asset,
        deadlineUptime: ProcessInfo.processInfo.systemUptime + 2,
        allowed: { allowed }, cancelPending: { held.cancelAll() })
    }
    await fulfillment(of: [started], timeout: 1)
    allowed = false
    let result = await operation.value
    XCTAssertEqual(result, "cancelled", "Revoked intent must cancel, not wait for the deadline")
    await fulfillment(of: [cancelled], timeout: 1)
    XCTAssertEqual(held.cancellationState.pending, 0)
    XCTAssertEqual(held.cancellationState.owner, 1)
    XCTAssertGreaterThan(held.cancellationState.terminated, 0)
    withExtendedLifetime(held) {}
  }

'''
assert mark in s;s=s.replace(mark,test+mark,1);p.write_text(s);(Path('/private/tmp/yl-preparation-intent')/'native-red.swift').write_text(s)
sys.path.insert(0,'tool/consumer_fixtures/apple_flutter');from media_delivery_fixture_adapter import native_test_source
for platform in ['ios','macos']:Path(f'packages/yl_player/example/{platform}/RunnerTests/{p.name}').write_bytes(native_test_source(p))
p=Path('tool/playback_network/test_abr_accesslog.py');s=p.read_text();mark='    def test_mid_preparation_pause_requires_preroll(self):';test='''    def test_intent_scenarios_require_their_actual_preparation_path(self):
        for scenario, expected in [('pause-during-metadata', 'asset-metadata'),
                                   ('seek-during-preparation', 'asset-preroll')]:
            for mode in ['manifest-only', 'asset-metadata', 'asset-preroll']:
                args = SimpleNamespace(recovery_action='auto-reload', duration_seconds=120,
                    direct_hls_control=False, candidate_preparation=mode, auto_scenario=scenario)
                if mode == expected:
                    self.assertEqual(abr_accesslog.candidate_preparation(args), expected)
                else:
                    with self.subTest(scenario=scenario, mode=mode), self.assertRaises(ValueError):
                        abr_accesslog.candidate_preparation(args)

''';assert mark in s;p.write_text(s.replace(mark,test+mark,1))
