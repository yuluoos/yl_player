from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path.cwd();out=Path('/private/tmp/yl-p07-publication-merge');env=os.environ.copy()
env.update(json.loads(Path('/private/tmp/yl-p07-wire-merge/main-checks.json').read_text())['environment'])
py='/private/tmp/yl-p07-dm-state/venv/bin/python'
commands=[('dolby-tests',[py,'-B','-m','unittest','discover','-s','tool/dolby_reference','-p','test_*.py','-v'],0),('readiness-tests',[py,'-B','-m','unittest','discover','-s','tool/playback_benchmark','-p','test_release_readiness.py','-v'],0),('readiness',[py,'-B','tool/release_readiness/check.py'],0),('readiness-required',[py,'-B','tool/release_readiness/check.py','--require-ready'],1),('thresholds',[py,'-B','tool/playback_benchmark/threshold_registry.py'],0),('thresholds-required',[py,'-B','tool/playback_benchmark/threshold_registry.py','--require-ready'],1),('diff',['git','diff','--check'],0),('product-diff',['git','diff','HEAD','--','packages','pubspec.yaml','pubspec.lock','.github'],0)]
results=[]
for name,cmd,expected in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 results.append(dict(name=name,command=cmd,exit=p.returncode,expected=expected,seconds=round(time.monotonic()-start,3)))
 print(name,p.returncode,flush=True)
(out/'checks.json').write_text(json.dumps(dict(base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),environment={k:v for k,v in env.items() if k.startswith('YL_')},checks=results),indent=2)+'\n')
assert all(c['exit']==c['expected'] for c in results)
