from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,'tool/release_readiness');import check
root=Path.cwd();p=root/'tool/release_readiness/inventory.json';v=json.loads(p.read_text())
original=[(r['requirement'],r['platform'],r['implementation'],r['verification'],r['acceptance']) for r in v['rows']]
v['source']=check.source_snapshot(root)
name='ios-request-boundary-20261027';report='docs/superpowers/reports/2026-10-27-ios-request-boundary.md'
v['evidence'][name]={'path':report,'sha256':hashlib.sha256((root/report).read_bytes()).hexdigest(),'kind':'report'}
for r in v['rows']:
 if (r['platform']=='ios' and r['requirement'] in ['CAP-ABR','CAP-DASH']) or (r['platform']=='macos' and r['requirement']=='CAP-ABR'):
  if name not in r['evidence']:r['evidence'].append(name)
 if r['platform']=='ios' and r['requirement']=='CAP-ABR':r['nextAction']='reproduce-terminal-stall-with-proxy-boundaries-and-qualify-original-profile-trigger-seek-gap-optimization-and-full-safety-matrix'
assert original==[(r['requirement'],r['platform'],r['implementation'],r['verification'],r['acceptance']) for r in v['rows']]
p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(v['source']['sha256'])
