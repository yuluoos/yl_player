from pathlib import Path
import sys
base=Path('packages/yl_player_apple/darwin/yl_player_apple/Sources/yl_player_apple')
p=base/'Shared/HLS/YlHlsMediaProxy.swift';s=p.read_text().replace('  var diagnosticSnapshot: [String: Double] { [:] }','''  // Numeric, per-proxy debug observations only. No resource/credential identity,
  // no retained event history and no change to transport or admission decisions.
  private var diagnosticCounters: [String: Double] = [
    "acceptedConnections": 0, "admittedRequests": 0,
    "upstreamCompletions": 0, "receivedBodyBytes": 0,
    "lastAdmissionUptime": 0, "lastCompletionUptime": 0]
  var diagnosticSnapshot: [String: Double] {
    lock.withLock {
      var result = diagnosticCounters
      result["activeConnections"] = Double(connections.count)
      result["activeTasks"] = Double(taskRecords.count)
      result["pendingSends"] = Double(taskRecords.values.reduce(0) { $0 + $1.pendingSends })
      result["suspendedTasks"] = Double(connectionTasks.values.filter { $0.state == .suspended }.count)
      result["cancelled"] = cancelled ? 1 : 0
      return result
    }
  }''')
s=s.replace('      connections[identifier] = connection\n','''      connections[identifier] = connection
      #if DEBUG
      diagnosticCounters["acceptedConnections", default: 0] += 1
      #endif
''')
s=s.replace('      task.resume()\n      return true','''      #if DEBUG
      diagnosticCounters["admittedRequests", default: 0] += 1
      diagnosticCounters["lastAdmissionUptime"] = ProcessInfo.processInfo.systemUptime
      #endif
      task.resume()
      return true''')
s=s.replace('    trafficScope?.recordNetworkBytes(data.count)','''    #if DEBUG
    lock.withLock { diagnosticCounters["receivedBodyBytes", default: 0] += Double(data.count) }
    #endif
    trafficScope?.recordNetworkBytes(data.count)''')
s=s.replace('      record.upstreamFinished = true','''      #if DEBUG
      diagnosticCounters["upstreamCompletions", default: 0] += 1
      diagnosticCounters["lastCompletionUptime"] = ProcessInfo.processInfo.systemUptime
      #endif
      record.upstreamFinished = true''');p.write_text(s)
p=base/'Shared/HLS/YlHlsResourceLoader.swift';s=p.read_text().replace('  var upstreamFailure: NativePlayerError?', '''  #if DEBUG
  var diagnosticProxySnapshot: [String: Double] { mediaProxy.diagnosticSnapshot }
  #endif
  var upstreamFailure: NativePlayerError?''');p.write_text(s)
p=base/'Engines/AvPlayer/YlAvPlayerBackend.swift';s=p.read_text().replace('  private var pendingRuntimeResume: (id: UUID, positionUs: Int64)?','''  #if DEBUG
  var diagnosticProxySnapshot: [String: Double] { hlsResourceLoader?.diagnosticProxySnapshot ?? [:] }
  var diagnosticResumeSeekPending: Bool { pendingRuntimeResume != nil }
  #endif
  private var pendingRuntimeResume: (id: UUID, positionUs: Int64)?''');p.write_text(s)
p=Path('tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift');s=p.read_text().replace('"timeControlStatus": player.timeControlStatus.rawValue]\n        do { try frameFile', '''"timeControlStatus": player.timeControlStatus.rawValue,
          "itemStatus": player.currentItem?.status.rawValue ?? -1,
          "resumeSeekPending": backend?.diagnosticResumeSeekPending ?? false]
        do { try frameFile''')
s=s.replace('"policySamplingVersion": 1, "backendStatus":', '''"proxySamplingVersion": 1, "proxy": backend?.diagnosticProxySnapshot ?? [:],
        "sampleUptime": ProcessInfo.processInfo.systemUptime,
        "policySamplingVersion": 1, "backendStatus":''');p.write_text(s)
sys.path.insert(0,'tool/consumer_fixtures/apple_flutter');from media_delivery_fixture_adapter import native_test_source
for platform in ['ios','macos']:Path(f'packages/yl_player/example/{platform}/RunnerTests/{p.name}').write_bytes(native_test_source(p))
