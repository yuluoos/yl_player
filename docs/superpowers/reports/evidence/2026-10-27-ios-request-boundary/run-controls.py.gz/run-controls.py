from pathlib import Path
import subprocess,json,time,hashlib,shutil
root=Path.cwd();base=Path('/private/tmp/yl-boundary');out=base/'controls';out.mkdir(exist_ok=False)
planned=[('old-frozen-control','down-and-recover-v1'),('old-latency-control','stall-headroom-zero-latency-diagnostic-v1')]
(out/'planned.json').write_text(json.dumps(planned,indent=2)+'\n')
shutil.copyfile('/private/tmp/yl-device-followup/latency-profiles.json',base/'latency-profiles.json')
# Old native source and binary identity are bound by the prior raw receipt.
prior=json.loads(Path('/private/tmp/yl-device-followup/runs/latency-auto/receipt.json').read_text())
(base/'control-prior-receipt.json').write_text(json.dumps(prior,indent=2)+'\n')
new=[json.loads(p.read_text()) for p in (base/'media').glob('latency-auto-*/automatic-events.json')]
assert any(e.get('outcome')=='installed' for events in new for e in events)
results=[]
for name,profile in planned:
 cmd=['python3','-B','tool/playback_network/abr_accesslog.py','--products','/private/tmp/yl-continuity-device-build/Build/Products','--directory',str(out/name),'--physical-device','00008140-000C49CC3493001C','--owned-host','192.168.50.196','--duration-seconds','120','--profile',profile,'--recovery-action','auto-reload']
 if 'latency' in name:cmd+=['--profiles',str(base/'latency-profiles.json')]
 print('START',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  try:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=360);code=p.returncode
  except subprocess.TimeoutExpired:code=124
 results.append(dict(name=name,command=cmd,exitCode=code,seconds=time.monotonic()-start));(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,code,flush=True)
 for kind,command in [('tests',['get','test-results','summary']),('action',['get','log','--type','action'])]:
  x=subprocess.run(['xcrun','xcresulttool',*command,'--path',str(out/(name+'.xcresult'))],capture_output=True,text=True,timeout=45)
  (out/(name+'-'+kind+'.json')).write_text(x.stdout);(out/(name+'-'+kind+'-exit.json')).write_text(json.dumps(dict(exitCode=x.returncode,stderr=x.stderr))+'\n')
 if code:break # Preserve failure; inspect before running a dependent repeat.
