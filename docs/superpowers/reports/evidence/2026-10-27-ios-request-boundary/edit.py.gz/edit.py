from pathlib import Path
root=Path.cwd();base=root/'packages/yl_player_apple/darwin/yl_player_apple/Sources/yl_player_apple'
p=base/'Shared/HLS/YlHlsMediaProxy.swift';s=p.read_text();s=s.replace('  let upstreamDiagnostics: YlHlsUpstreamDiagnostics','  #if DEBUG\n  var diagnosticSnapshot: [String: Double] { [:] }\n  #endif\n\n  let upstreamDiagnostics: YlHlsUpstreamDiagnostics');p.write_text(s)
p=root/'tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift';s=p.read_text();marker='  func testProxyCancellationCannotInvalidateSessionDuringTaskAdmission() throws {'
test='''  func testProxyBoundarySnapshotTracksRealRequestAndCancellationWithoutResourceIdentity() throws {
    let server = try DashHTTPServer()
    defer { server.close() }
    server.handler = { _ in (200, [:], Data([1, 2, 3, 4])) }
    let proxy = try YlHlsMediaProxy(originURL: server.url("/private?token=secret"),
      headers: ["Authorization": "secret"], configuration: .init(map: [:]))
    defer { proxy.cancelAll() }
    XCTAssertEqual(proxy.diagnosticSnapshot["admittedRequests"], 0)
    let done = expectation(description: "real proxied bytes")
    URLSession.shared.dataTask(with: try proxy.proxyURL(for: server.url("/private?token=secret"))) { body, _, error in
      XCTAssertNil(error); XCTAssertEqual(body, Data([1, 2, 3, 4])); done.fulfill()
    }.resume()
    wait(for: [done], timeout: 4)
    let deadline = Date().addingTimeInterval(2)
    while proxy.diagnosticSnapshot["activeTasks"] != 0 && Date() < deadline {
      RunLoop.current.run(until: Date().addingTimeInterval(0.01))
    }
    let snapshot = proxy.diagnosticSnapshot
    XCTAssertEqual(snapshot["acceptedConnections"], 1)
    XCTAssertEqual(snapshot["admittedRequests"], 1)
    XCTAssertEqual(snapshot["upstreamCompletions"], 1)
    XCTAssertEqual(snapshot["receivedBodyBytes"], 4)
    XCTAssertEqual(snapshot["activeTasks"], 0)
    XCTAssertEqual(snapshot["pendingSends"], 0)
    XCTAssertGreaterThan(snapshot["lastAdmissionUptime"] ?? 0, 0)
    XCTAssertTrue(snapshot.keys.allSatisfy { !$0.contains("secret") && !$0.contains("private") })
    proxy.cancelAll()
    XCTAssertEqual(proxy.diagnosticSnapshot["activeConnections"], 0)
    XCTAssertEqual(proxy.diagnosticSnapshot["cancelled"], 1)
    XCTAssertEqual(proxy.diagnosticSnapshot["admittedRequests"], 1)
  }

'''
s=s.replace(marker,test+marker);p.write_text(s)
for platform in ['ios','macos']:(root/f'packages/yl_player/example/{platform}/RunnerTests'/p.name).write_text(s)
p=root/'tool/consumer_fixtures/apple_flutter/main_example_tests.py';s=p.read_text().replace("{'ios': 826, 'macos': 870}","{'ios': 827, 'macos': 871}");p.write_text(s)
