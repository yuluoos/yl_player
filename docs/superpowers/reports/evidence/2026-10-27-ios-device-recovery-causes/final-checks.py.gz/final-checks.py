from pathlib import Path
import subprocess,json
out=Path('/private/tmp/yl-device-cause/final-checks');out.mkdir(exist_ok=True)
commands={'network':['python3','-B','-m','unittest','discover','-s','tool/playback_network','-p','test_*.py','-v'], 'ledger-tests':['python3','-B','-m','unittest','discover','-s','tool/playback_benchmark','-p','test_release_readiness.py','-v'], 'mirrors':['python3','-B','tool/consumer_fixtures/apple_flutter/main_example_tests.py'], 'reanalysis':['python3','-B','/private/tmp/yl-device-cause/analyze.py'],'diff':['git','diff','--check']}
results=[]
for name,cmd in commands.items():
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,exitCode=p.returncode));print(name,p.returncode,flush=True)
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
