from pathlib import Path
import json,sys
sys.path.insert(0,str(Path.cwd()/'tool/playback_network'))
from abr_accesslog import summarize_policy,summarize_frames,policy_trace_version
root=Path('/private/tmp/yl-device-cause/runs');result=[]
for name,action,direct in json.loads((root/'planned.json').read_text()):
 p=root/name;receipt=json.loads((p/'receipt.json').read_text());rows=[json.loads(x) for x in (p/'rows.jsonl').read_text().splitlines()];frames=[json.loads(x) for x in (p/'frame-samples.jsonl').read_text().splitlines()];transitions=[];last=None
 for f in frames:
  if f['frames'] and f['width']!=last:transitions.append({k:f[k] for k in ['elapsed','width','generation']});last=f['width']
 assert policy_trace_version(rows)==1
 policy=None
 if action=='auto-reload':
  policy=summarize_policy([json.loads(x) for x in (p/'policy-decisions.jsonl').read_text().splitlines()],expected_attempts=rows[-1]['automaticAttempts']);assert policy==receipt['policyObservation']
 assert summarize_frames(frames,expected_frames=rows[-1]['framesPublished'])==receipt['continuityObservation']
 x=json.loads((root/(name+'-action.json')).read_text());lines=[]
 def walk(v):
  if isinstance(v,str):
   for line in v.splitlines():
    if '[YL-ABR]' in line or '[YLPlayer][AVPlayer]' in line:lines.append(line)
  elif isinstance(v,dict):
   for y in v.values():walk(y)
  elif isinstance(v,list):
   for y in v:walk(y)
 walk(x);lines=list(dict.fromkeys(lines));(root/(name+'-signals.log')).write_text('\n'.join(lines)+'\n')
 result.append(dict(name=name,collectionPassed=receipt['passed'],position=rows[-1]['position'],completed=rows[-1]['completed'],width=rows[-1]['width'],backendStatus=rows[-1]['backendStatus'],backendFailureCode=rows[-1]['backendFailureCode'],transitions=transitions,policy=policy,continuity=receipt['continuityObservation'],signalLines=lines,ownedProcessExited=receipt['ownedProcessExited'],binaryIdentityUnchanged=receipt['binaryIdentityUnchanged'],capabilityAccepted=False))
(root/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
for r in result:print(r['name'],r['collectionPassed'],r['position'],r['transitions'],r['continuity']['maximumPublishedFrameGapMs'],'signals',len(r['signalLines']))
