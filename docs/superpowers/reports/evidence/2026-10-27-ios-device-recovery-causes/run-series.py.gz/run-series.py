from pathlib import Path
import subprocess,json,time,hashlib
root=Path.cwd();out=Path('/private/tmp/yl-device-cause/runs');out.mkdir(exist_ok=False)
planned=[('auto-1','auto-reload',False),('auto-2','auto-reload',False),('direct-control','none',True)]
(out/'planned.json').write_text(json.dumps(planned,indent=2)+'\n')
files=['packages/yl_player_apple/darwin/yl_player_apple/Sources/yl_player_apple/Engines/AvPlayer/YlAvPlayerBackend.swift','tool/playback_network/abr_accesslog.py','tool/playback_network/abr_device.py','tool/playback_network/network_profile.py','tool/playback_network/prepare_fixture.py','tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift','packages/yl_player/example/ios/RunnerTests/YlDashResourceLoaderTests.swift']
(out/'source-identity.json').write_text(json.dumps({p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files},indent=2)+'\n')
results=[]
for name,action,direct in planned:
 cmd=['python3','-B','tool/playback_network/abr_accesslog.py','--products','/private/tmp/yl-continuity-device-build/Build/Products','--directory',str(out/name),'--physical-device','00008140-000C49CC3493001C','--owned-host','192.168.50.196','--duration-seconds','120','--recovery-action',action]
 if direct:cmd.append('--direct-hls-control')
 print('START',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=360)
 results.append(dict(name=name,command=cmd,exitCode=p.returncode,seconds=time.monotonic()-start));(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,p.returncode,flush=True)
 for kind,command in [('tests',['get','test-results','tests']),('action',['get','log','--type','action'])]:
  x=subprocess.run(['xcrun','xcresulttool',*command,'--path',str(out/(name+'.xcresult'))],capture_output=True,text=True,timeout=45)
  (out/(name+'-'+kind+'.json')).write_text(x.stdout);(out/(name+'-'+kind+'-exit.json')).write_text(json.dumps(dict(exitCode=x.returncode,stderr=x.stderr))+'\n')
