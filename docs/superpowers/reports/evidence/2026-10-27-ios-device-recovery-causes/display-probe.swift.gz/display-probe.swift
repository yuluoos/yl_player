import AppKit
import QuartzCore
final class Tick: NSObject {
 var ticks=0
 @objc func fire(_ link: CADisplayLink) { ticks += 1 }
}
let app=NSApplication.shared
let tick=Tick()
print("screenCount", NSScreen.screens.count)
if #available(macOS 14.0, *), let screen=NSScreen.main {
 let link=screen.displayLink(target:tick,selector:#selector(Tick.fire(_:)))
 link.add(to:.main,forMode:.common)
 RunLoop.main.run(until:Date().addingTimeInterval(3))
 print("displayTicks",tick.ticks,"paused",link.isPaused)
 link.invalidate()
}
print("displayAsleep",CGDisplayIsAsleep(CGMainDisplayID()),"displayActive",CGDisplayIsActive(CGMainDisplayID()))
