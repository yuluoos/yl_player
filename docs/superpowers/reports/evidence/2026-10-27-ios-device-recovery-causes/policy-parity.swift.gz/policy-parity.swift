import Foundation
private struct BaselinePolicy {
  struct Sample {
    let time: Double, generation: Int, allowed: Bool, width: Int
    let position: Double, remaining: Double, bufferAhead: Double
    let bytes: Int64, transfer: Double, requests: Int, overdue: Int
  }
  struct Ticket { let id: UUID, generation: Int, attempt: Int, due: Double }
  private(set) var attempts = 0
  private var generation: Int?
  private var sawHigh = false
  private var anchor: Sample?
  private var windows = 0
  private var last: Sample?
  private var pending: Ticket?
  private var inFlight: Ticket?
  static func contiguousAhead(position: Double, ranges: [(Double, Double)]) -> Double {
    guard position.isFinite, position >= 0 else { return 0 }
    var end = position
    for range in ranges.filter({ $0.0.isFinite && $0.1.isFinite && $0.1 >= $0.0 }).sorted(by: { $0.0 < $1.0 }) {
      if range.1 < position { continue }
      if range.0 > end { break }
      end = max(end, range.1)
    }
    return max(0, end - position)
  }
  mutating func invalidateIntent() {
    pending = nil; inFlight = nil; anchor = nil; windows = 0; last = nil
  }
  private func eligible(_ s: Sample) -> Bool {
    s.allowed && s.time.isFinite && s.position.isFinite && s.remaining.isFinite &&
      s.bufferAhead.isFinite && s.transfer.isFinite && s.time >= 0 && s.position >= 0 &&
      s.transfer >= 0 && s.bytes >= 0 && s.requests >= 0 && s.remaining >= 20 && s.bufferAhead >= 5
  }
  mutating func observe(_ s: Sample) -> Ticket? {
    if generation != s.generation {
      generation = s.generation; sawHigh = false; anchor = nil; windows = 0
      pending = nil; inFlight = nil; last = nil
    }
    guard eligible(s), last.map({ s.time > $0.time && s.position >= $0.position }) ?? true else {
      anchor = nil; windows = 0; pending = nil; inFlight = nil; last = nil; return nil
    }
    last = s
    if s.width == 640 { sawHigh = true; anchor = nil; windows = 0; pending = nil; return nil }
    guard sawHigh, s.width == 320, s.overdue > 0 else { anchor = nil; windows = 0; pending = nil; return nil }
    if let pending {
      guard s.time >= pending.due else { return nil }
      self.pending = nil; inFlight = pending; return pending
    }
    guard inFlight == nil, attempts < 2 else { return nil }
    guard let start = anchor else { anchor = s; return nil }
    guard s.bytes >= start.bytes, s.transfer >= start.transfer, s.requests >= start.requests else {
      anchor = s; windows = 0; return nil
    }
    guard s.time - start.time >= 8 else { return nil }
    anchor = s
    let duration = s.transfer - start.transfer
    let bitrate = duration > 0 ? Double(s.bytes - start.bytes) * 8 / duration : 0
    guard s.position > start.position, s.requests - start.requests >= 3,
          bitrate.isFinite, bitrate >= 764_000 * 1.25 else { windows = 0; return nil }
    windows += 1
    guard windows >= 2 else { return nil }
    attempts += 1; windows = 0; anchor = nil
    pending = Ticket(id: UUID(), generation: s.generation, attempt: attempts,
      due: s.time + (attempts == 1 ? 0.5 : 1.0))
    return nil
  }
  func authorizes(_ ticket: Ticket, _ s: Sample) -> Bool {
    eligible(s) && s.width == 320 && s.generation == ticket.generation &&
      inFlight?.id == ticket.id && s.time >= ticket.due && s.time <= ticket.due + 5
  }
  mutating func finish(_ ticket: Ticket) {
    guard inFlight?.id == ticket.id else { return }
    inFlight = nil; anchor = nil; windows = 0
  }
}

private struct ObservedPolicy {
  struct Sample {
    let time: Double, generation: Int, allowed: Bool, width: Int
    let position: Double, remaining: Double, bufferAhead: Double
    let bytes: Int64, transfer: Double, requests: Int, overdue: Int
  }
  struct Ticket { let id: UUID, generation: Int, attempt: Int, due: Double }
  private(set) var attempts = 0
  private(set) var decision: [String: Any] = [:]
  private var generation: Int?
  private var sawHigh = false
  private var anchor: Sample?
  private var windows = 0
  private var last: Sample?
  private var pending: Ticket?
  private var inFlight: Ticket?
  static func contiguousAhead(position: Double, ranges: [(Double, Double)]) -> Double {
    guard position.isFinite, position >= 0 else { return 0 }
    var end = position
    for range in ranges.filter({ $0.0.isFinite && $0.1.isFinite && $0.1 >= $0.0 }).sorted(by: { $0.0 < $1.0 }) {
      if range.1 < position { continue }
      if range.0 > end { break }
      end = max(end, range.1)
    }
    return max(0, end - position)
  }
  mutating func invalidateIntent() {
    pending = nil; inFlight = nil; anchor = nil; windows = 0; last = nil
  }
  private func eligible(_ s: Sample) -> Bool {
    s.allowed && s.time.isFinite && s.position.isFinite && s.remaining.isFinite &&
      s.bufferAhead.isFinite && s.transfer.isFinite && s.time >= 0 && s.position >= 0 &&
      s.transfer >= 0 && s.bytes >= 0 && s.requests >= 0 && s.remaining >= 20 && s.bufferAhead >= 5
  }
  mutating func observe(_ s: Sample) -> Ticket? {
    var reason = "invalidSample"
    var windowBitrate: Double?
    var windowRequests: Int?
    func finite(_ value: Double) -> Any { value.isFinite ? value as Any : NSNull() }
    defer {
      decision = ["elapsed": finite(s.time), "generation": s.generation, "allowed": s.allowed,
        "width": s.width, "position": finite(s.position), "remaining": finite(s.remaining),
        "bufferAhead": finite(s.bufferAhead), "bytes": s.bytes, "transfer": finite(s.transfer),
        "requests": s.requests, "overdue": s.overdue, "reason": reason, "attempts": attempts,
        "qualifiedWindows": windows, "sawHigh": sawHigh,
        "windowBitrate": windowBitrate.map(finite) ?? NSNull(),
        "windowRequests": windowRequests as Any? ?? NSNull(),
        "pendingDue": pending.map { finite($0.due) } ?? NSNull()]
    }
    if generation != s.generation {
      generation = s.generation; sawHigh = false; anchor = nil; windows = 0
      pending = nil; inFlight = nil; last = nil
    }
    guard eligible(s), last.map({ s.time > $0.time && s.position >= $0.position }) ?? true else {
      if !s.allowed { reason = "playbackIneligible" }
      else if s.bufferAhead.isFinite && s.bufferAhead < 5 { reason = "insufficientBuffer" }
      else if s.remaining.isFinite && s.remaining < 20 { reason = "nearEnd" }
      else if eligible(s) { reason = "nonMonotonic" }
      anchor = nil; windows = 0; pending = nil; inFlight = nil; last = nil; return nil
    }
    last = s
    if s.width == 640 { reason = "highOutput"; sawHigh = true; anchor = nil; windows = 0; pending = nil; return nil }
    guard sawHigh, s.width == 320, s.overdue > 0 else { reason = !sawHigh ? "highNotObserved" : (s.width != 320 ? "notLowOutput" : "noOverdue"); anchor = nil; windows = 0; pending = nil; return nil }
    if let pending {
      guard s.time >= pending.due else { reason = "backoff"; return nil }
      reason = "ticketReady"
      self.pending = nil; inFlight = pending; return pending
    }
    guard inFlight == nil, attempts < 2 else { reason = inFlight != nil ? "inFlight" : "budgetExhausted"; return nil }
    guard let start = anchor else { reason = "windowStarted"; anchor = s; return nil }
    guard s.bytes >= start.bytes, s.transfer >= start.transfer, s.requests >= start.requests else {
      reason = "countersReset"; anchor = s; windows = 0; return nil
    }
    guard s.time - start.time >= 8 else { reason = "windowPending"; return nil }
    anchor = s
    let duration = s.transfer - start.transfer
    let bitrate = duration > 0 ? Double(s.bytes - start.bytes) * 8 / duration : 0
    windowBitrate = bitrate; windowRequests = s.requests - start.requests
    guard s.position > start.position, s.requests - start.requests >= 3,
          bitrate.isFinite, bitrate >= 764_000 * 1.25 else {
      reason = s.position <= start.position ? "noProgress" : (s.requests - start.requests < 3 ? "insufficientRequests" : "insufficientBandwidth")
      windows = 0; return nil
    }
    windows += 1
    guard windows >= 2 else { reason = "firstQualifiedWindow"; return nil }
    reason = "reserved"
    attempts += 1; windows = 0; anchor = nil
    pending = Ticket(id: UUID(), generation: s.generation, attempt: attempts,
      due: s.time + (attempts == 1 ? 0.5 : 1.0))
    return nil
  }
  func authorizes(_ ticket: Ticket, _ s: Sample) -> Bool {
    eligible(s) && s.width == 320 && s.generation == ticket.generation &&
      inFlight?.id == ticket.id && s.time >= ticket.due && s.time <= ticket.due + 5
  }
  mutating func finish(_ ticket: Ticket) {
    guard inFlight?.id == ticket.id else { return }
    inFlight = nil; anchor = nil; windows = 0
  }
}


var seed: UInt64 = 1357911
func random(_ n: UInt64) -> UInt64 { seed = seed &* 6364136223846793005 &+ 1; return (seed >> 32) % n }
var checked = 0
var issued = 0
for _ in 0..<1000 {
  var a = BaselinePolicy(); var b = ObservedPolicy()
  var bytes: Int64 = 0; var transfer = 0.0; var requests = 0
  for index in 0..<240 {
    let time = Double(index) * 0.5
    let allowed = index < 80 || random(20) != 0
    let width = index < 8 || (index >= 80 && random(30) == 0) ? 640 : 320
    let buffer = index >= 80 && random(15) == 0 ? 4.0 : 10.0
    bytes += index < 80 ? 100000 : Int64(random(180000)); transfer += 0.25; requests += 2
    let generation = index < 150 ? 0 : 1
    let x = BaselinePolicy.Sample(time: time, generation: generation, allowed: allowed, width: width,
      position: time, remaining: 120-time, bufferAhead: buffer, bytes: bytes,
      transfer: transfer, requests: requests, overdue: 1)
    let y = ObservedPolicy.Sample(time: time, generation: generation, allowed: allowed, width: width,
      position: time, remaining: 120-time, bufferAhead: buffer, bytes: bytes,
      transfer: transfer, requests: requests, overdue: 1)
    let at = a.observe(x); let bt = b.observe(y)
    precondition((at == nil) == (bt == nil) && a.attempts == b.attempts)
    if let at, let bt {
      issued += 1
      precondition(at.generation == bt.generation && at.attempt == bt.attempt && at.due == bt.due)
      precondition(a.authorizes(at,x) == b.authorizes(bt,y))
      a.finish(at); b.finish(bt)
    }
    if index >= 80 && random(50) == 0 { a.invalidateIntent(); b.invalidateIntent() }
    checked += 1
  }
}
print("Frozen-policy parity: \(checked) matched samples across 1000 deterministic traces; issued tickets: \(issued)")
