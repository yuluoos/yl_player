from pathlib import Path
import subprocess,json,hashlib
out=Path('/private/tmp/yl-device-cause')
products=Path('/private/tmp/yl-continuity-macos/Build/Products/Debug')
def hashes():
 return {str(p.relative_to(products)):hashlib.sha256(p.read_bytes()).hexdigest() for p in products.rglob('*') if p.is_file() and not p.is_symlink()}
before=hashes();(out/'macos-awake-binary-before.json').write_text(json.dumps(before,indent=2)+'\n')
cmd=['xcodebuild','test-without-building','-quiet','-workspace','packages/yl_player/example/macos/Runner.xcworkspace','-scheme','Runner','-configuration','Debug','-destination','platform=macOS,arch=arm64','-derivedDataPath','/private/tmp/yl-continuity-macos','-parallel-testing-enabled','NO','-resultBundlePath',str(out/'macos-contracts-awake.xcresult'),'-only-testing:RunnerTests/YlDashResourceLoaderTests','-only-testing:RunnerTests/YlAppleSessionTests','-only-testing:RunnerTests/YlApplePublicationTests']
(out/'macos-awake-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'macos-contracts-awake.log').open('w') as log:
 p=subprocess.run(['caffeinate','-u','-d','-i',*cmd],stdout=log,stderr=subprocess.STDOUT)
(out/'macos-awake-result.json').write_text(json.dumps(dict(exitCode=p.returncode,binaryUnchanged=before==hashes()))+'\n')
for kind,command in [('summary',['get','test-results','summary']),('action',['get','log','--type','action'])]:
 p=subprocess.run(['xcrun','xcresulttool',*command,'--path',str(out/'macos-contracts-awake.xcresult')],capture_output=True,text=True)
 (out/('macos-contracts-awake-'+kind+'.json')).write_text(p.stdout)
print((out/'macos-awake-result.json').read_text())
