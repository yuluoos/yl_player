from pathlib import Path
import hashlib,gzip,json,tarfile,io
src=Path('/private/tmp/yl-device-cause'); dst=Path('docs/superpowers/reports/evidence/2026-10-27-ios-device-recovery-causes');dst.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
provenance=[]
# Archive complete xcresult bundles separately; no build products or generated media.
bundles=sorted(src.rglob('*.xcresult'))
for b in bundles:
 rel=b.relative_to(src); target=dst/(str(rel)+'.tar.gz');target.parent.mkdir(parents=True,exist_ok=True)
 with tarfile.open(target,'w:gz') as tar:tar.add(b,arcname=b.name)
 provenance.append(dict(source=str(rel),archive=str(target.relative_to(dst)),bundleFiles=sum(f.is_file() for f in b.rglob('*'))))
for p in sorted(src.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(src)
 if any(part.endswith('.xcresult') for part in rel.parts):continue
 if p.name.startswith('device-details-private') or p.name=='policy-parity' or p.suffix=='.m4s':continue
 data=p.read_bytes();compressed=p.suffix in ('.log','.jsonl','.py','.swift','.xctestrun') or len(data)>20000
 target=dst/(str(rel)+('.gz' if compressed else ''));target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(data,mtime=0) if compressed else data)
 provenance.append(dict(source=str(rel),archive=str(target.relative_to(dst)),sourceSha256=sha(data),bytes=len(data)))
files=['tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift','packages/yl_player/example/ios/RunnerTests/YlDashResourceLoaderTests.swift','packages/yl_player/example/macos/RunnerTests/YlDashResourceLoaderTests.swift','tool/consumer_fixtures/apple_flutter/main_example_tests.py','tool/playback_network/abr_accesslog.py','tool/playback_network/abr_device.py','tool/playback_network/test_abr_policy.py','tool/playback_network/README.md']
identity={}
for name in files:
 data=Path(name).read_bytes();identity[name]=sha(data);target=dst/('final-source/'+name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0))
(dst/'final-source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
(dst/'raw-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print('xcresults',len(bundles),'rawItems',len(provenance))
