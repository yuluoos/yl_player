from pathlib import Path
import hashlib,json,subprocess
src=Path('/private/tmp/yl-device-cause');evidence=Path('docs/superpowers/reports/evidence');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((src/'prior-evidence-hashes.json').read_text());result=[]
for group in previous:
 folder=evidence/group['evidence'];count=0
 for line in (folder/'SHA256SUMS').read_text().splitlines():
  digest,name=line.split('  ',1);assert sha(folder/name)==digest,(folder,name);count+=1
 assert count==group['files'];result.append(dict(evidence=folder.name,files=count,unchanged=True))
identity=json.loads((src/'runs/source-identity.json').read_text())
for name,digest in identity.items():assert sha(src/'capture-source'/name)==digest,name
changed=[]
for name in ['packages','pubspec.yaml','pubspec.lock','tool/playback_benchmark','tool/playback_network/profiles.json']:
 p=subprocess.run(['git','diff','--name-only','HEAD','--',name],capture_output=True,text=True,check=True)
 changed+=p.stdout.splitlines()
(src/'final-history-verification.json').write_text(json.dumps(dict(priorGroups=result,priorFiles=sum(x['files'] for x in result),captureSourceFilesVerified=len(identity),changedInProductionAndBenchmarkScopes=changed),indent=2)+'\n')
print('old hashes',sum(x['files'] for x in result),'capture sources',len(identity),'scope diff',changed)
