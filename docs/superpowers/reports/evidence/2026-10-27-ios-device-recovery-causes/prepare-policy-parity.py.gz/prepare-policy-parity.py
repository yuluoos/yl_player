from pathlib import Path
import subprocess,hashlib,json
path='tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift'
old=subprocess.check_output(['git','show','5a7320e9:'+path],text=True);new=Path(path).read_text()
def policy(text,name):
 text=text[text.index('private struct AbrDiagnosticRecoveryPolicy'):text.index('private enum AbrDiagnosticCaptureURL')]
 return text.replace('AbrDiagnosticRecoveryPolicy',name)
text='import Foundation\n'+policy(old,'BaselinePolicy')+policy(new,'ObservedPolicy')+'''
var seed: UInt64 = 1357911
func random(_ n: UInt64) -> UInt64 { seed = seed &* 6364136223846793005 &+ 1; return (seed >> 32) % n }
var checked = 0
var issued = 0
for _ in 0..<1000 {
  var a = BaselinePolicy(); var b = ObservedPolicy()
  var bytes: Int64 = 0; var transfer = 0.0; var requests = 0
  for index in 0..<240 {
    let time = Double(index) * 0.5
    let allowed = index < 80 || random(20) != 0
    let width = index < 8 || (index >= 80 && random(30) == 0) ? 640 : 320
    let buffer = index >= 80 && random(15) == 0 ? 4.0 : 10.0
    bytes += index < 80 ? 100000 : Int64(random(180000)); transfer += 0.25; requests += 2
    let generation = index < 150 ? 0 : 1
    let x = BaselinePolicy.Sample(time: time, generation: generation, allowed: allowed, width: width,
      position: time, remaining: 120-time, bufferAhead: buffer, bytes: bytes,
      transfer: transfer, requests: requests, overdue: 1)
    let y = ObservedPolicy.Sample(time: time, generation: generation, allowed: allowed, width: width,
      position: time, remaining: 120-time, bufferAhead: buffer, bytes: bytes,
      transfer: transfer, requests: requests, overdue: 1)
    let at = a.observe(x); let bt = b.observe(y)
    precondition((at == nil) == (bt == nil) && a.attempts == b.attempts)
    if let at, let bt {
      issued += 1
      precondition(at.generation == bt.generation && at.attempt == bt.attempt && at.due == bt.due)
      precondition(a.authorizes(at,x) == b.authorizes(bt,y))
      a.finish(at); b.finish(bt)
    }
    if index >= 80 && random(50) == 0 { a.invalidateIntent(); b.invalidateIntent() }
    checked += 1
  }
}
print("Frozen-policy parity: \\(checked) matched samples across 1000 deterministic traces; issued tickets: \\(issued)")
'''
root=Path('/private/tmp/yl-device-cause');(root/'policy-parity.swift').write_text(text)
(root/'policy-parity-identity.json').write_text(json.dumps(dict(baselineCommit='5a7320e9',baselineFixtureSha256=hashlib.sha256(old.encode()).hexdigest(),candidateFixtureSha256=hashlib.sha256(new.encode()).hexdigest(),generatedSwiftSha256=hashlib.sha256(text.encode()).hexdigest()),indent=2)+'\n')
