import yl_player_media_core
import AVFoundation
import Foundation
import UniformTypeIdentifiers
#if os(iOS)
import MobileCoreServices
#endif

protocol YlHlsLoadingRequest: AnyObject {
  var url: URL { get }
  var requestedOffset: Int64 { get }
  var currentOffset: Int64 { get }
  var requestedLength: Int { get }
  var requestsAllDataToEnd: Bool { get }

  func setContentInformation(
    contentType: String?,
    contentLength: Int64,
    byteRangeAccessSupported: Bool
  )
  func redirect(to request: URLRequest)
  func respond(with data: Data)
  func finishLoading()
  func finishLoading(with error: NativePlayerError)
}

private final class YlAVAssetLoadingRequestAdapter: YlHlsLoadingRequest {
  let loadingRequest: AVAssetResourceLoadingRequest
  let url: URL

  init?(_ loadingRequest: AVAssetResourceLoadingRequest) {
    guard let url = loadingRequest.request.url else { return nil }
    self.loadingRequest = loadingRequest
    self.url = url
  }

  var requestedOffset: Int64 {
    loadingRequest.dataRequest?.requestedOffset ?? 0
  }

  var currentOffset: Int64 {
    loadingRequest.dataRequest?.currentOffset ?? requestedOffset
  }

  var requestedLength: Int {
    loadingRequest.dataRequest?.requestedLength ?? 0
  }

  var requestsAllDataToEnd: Bool {
    loadingRequest.dataRequest?.requestsAllDataToEndOfResource ?? true
  }

  func setContentInformation(
    contentType: String?,
    contentLength: Int64,
    byteRangeAccessSupported: Bool
  ) {
    loadingRequest.contentInformationRequest?.contentType = contentType
    loadingRequest.contentInformationRequest?.contentLength = contentLength
    loadingRequest.contentInformationRequest?.isByteRangeAccessSupported =
      byteRangeAccessSupported
  }

  func respond(with data: Data) {
    loadingRequest.dataRequest?.respond(with: data)
  }

  func redirect(to request: URLRequest) {
    loadingRequest.redirect = request
    loadingRequest.response = HTTPURLResponse(
      url: request.url ?? url,
      statusCode: 302,
      httpVersion: "HTTP/1.1",
      headerFields: ["Location": request.url?.absoluteString ?? ""]
    )
  }

  func finishLoading() {
    loadingRequest.finishLoading()
  }

  func finishLoading(with error: NativePlayerError) {
    loadingRequest.finishLoading(with: error)
  }
}

final class YlHlsResourceLoader: NSObject, AVAssetResourceLoaderDelegate {
  static let manifestByteLimit = 2 * 1024 * 1024

  private struct CachedResponse {
    var opaqueRetention: YlManagedBufferLedger.OpaqueHlsRetention? = nil
    let data: Data
    let contentType: String?
    let contentLength: Int64
    let byteRangeAccessSupported: Bool
  }

  private final class TaskRecord {
    var opaqueRetention: YlManagedBufferLedger.OpaqueHlsRetention?
    let request: YlHlsLoadingRequest
    let cacheKey: String
    let rangeHeader: String?
    let requestedStart: Int64
    let requestedLength: Int?
    var destinationURL: URL
    var isManifest: Bool
    var response: HTTPURLResponse?
    var indexRequest: PreflightRequest? {
      guard let preflight = request as? PreflightRequest, preflight.index != nil else { return nil }
      return preflight
    }
    var manifestData = Data()
    var requestContext: YlManagedRequestContext?
    var redirectCount: Int { requestContext?.redirectsFollowed ?? 0 }
    var credentialsStripped: Bool { requestContext?.credentialsAllowed != true }
    var bytesToSkip: Int64 = 0
    var bytesDelivered = 0
    var task: URLSessionDataTask?

    init(
      request: YlHlsLoadingRequest,
      destinationURL: URL,
      rangeHeader: String?,
      isManifest: Bool
    ) {
      self.request = request
      self.destinationURL = destinationURL
      cacheKey = destinationURL.absoluteString
      self.rangeHeader = rangeHeader
      requestedStart = max(0, request.currentOffset == 0
        ? request.requestedOffset : request.currentOffset)
      requestedLength = request.requestsAllDataToEnd || request.requestedLength <= 0
        ? nil : request.requestedLength
      self.isManifest = isManifest
    }
  }

  private final class PreflightRequest: YlHlsLoadingRequest {
    let url: URL
    let index: YlDashIndexRequest?
    var requestedOffset: Int64 { index?.start ?? 0 }
    let currentOffset: Int64 = 0
    var requestedLength: Int { index?.length ?? 0 }
    var requestsAllDataToEnd: Bool { index == nil }
    var effectiveURL: URL
    var credentialsStripped = false
    var resourceLength: Int64 = 0
    let semaphore = DispatchSemaphore(value: 0)
    private let lock = NSLock()
    private(set) var data = Data()
    private(set) var error: NativePlayerError?
    private var finished = false

    init(url: URL, index: YlDashIndexRequest? = nil) {
      self.url = url; self.effectiveURL = url; self.index = index
    }

    func setContentInformation(
      contentType: String?,
      contentLength: Int64,
      byteRangeAccessSupported: Bool
    ) {}

    func respond(with data: Data) {
      lock.withLock { self.data.append(data) }
    }

    func redirect(to request: URLRequest) {
      finish(error: NativePlayerError(
        category: "internal",
        code: "\(YlApplePlatform.current.rawValue).hls_loader_failed",
        message: "A manifest preflight unexpectedly requested a redirect."
      ))
    }

    func finishLoading() { finish(error: nil) }
    func finishLoading(with error: NativePlayerError) { finish(error: error) }

    private func finish(error: NativePlayerError?) {
      let shouldSignal = lock.withLock { () -> Bool in
        guard !finished else { return false }
        finished = true
        self.error = error
        return true
      }
      if shouldSignal { semaphore.signal() }
    }
  }

  let resourceLoaderQueue = DispatchQueue(
    label: "dev.ylplayer.hls.resource-loader",
    qos: .userInitiated
  )

  private let opaqueRetention: YlManagedBufferLedger.OpaqueHlsRetention?
  private let isDash: Bool
  let videoConstraints: YlAppleVideoConstraints
  let fixedTrackId: String?
  private let virtualNamespace = UUID().uuidString.lowercased()
  // Immutable after one successful preflight; removed on cancellation. Synthetic
  // identities are never credential origins or upstream fetch destinations.
  private var dashPresentation: YlDashHlsPresentation?
  private var acceptedDashSnapshot: YlDashManifestSnapshot?
  private var preflightStarted = false
  private let originURL: URL
  let credentialContext: YlHlsCredentialContext
  private let hasExplicitCredentials: Bool
  private let headerPolicy: YlHlsHeaderPolicy
  private let configuration: YlNetworkConfiguration
  private let mediaProxy: YlHlsMediaProxy
  private let upstreamDiagnostics = YlHlsUpstreamDiagnostics()
  #if DEBUG
  var diagnosticProxySnapshot: [String: Double] { mediaProxy.diagnosticSnapshot }
  #endif
  var upstreamFailure: NativePlayerError? { upstreamDiagnostics.latestFailure }
  let trafficScope: YlManagedBufferScope?
  private let stateLock = NSLock()
  private var records: [Int: TaskRecord] = [:]
  private var cachedResponses: [String: CachedResponse] = [:]
  private var cancelled = false
  private var session: URLSession!

  init(
    originURL: URL,
    isDash: Bool = false,
    videoConstraints: YlAppleVideoConstraints = .unconstrained,
    fixedTrackId: String? = nil,
    headers: [String: String],
    credentials: [String: String] = [:],
    configuration: YlNetworkConfiguration,
    credentialContext: YlHlsCredentialContext = YlHlsCredentialContext(),
    sessionConfiguration: URLSessionConfiguration = .ephemeral,
    opaqueRetention: YlManagedBufferLedger.OpaqueHlsRetention? = nil,
    trafficScope: YlManagedBufferScope? = nil,
    sessionFactory: (URLSessionConfiguration, URLSessionDelegate, OperationQueue) -> URLSession = {
      URLSession(configuration: $0, delegate: $1, delegateQueue: $2)
    }
  ) throws {
    self.trafficScope = trafficScope
    trafficScope?.recordNetworkBytes(0)
    self.isDash = isDash
    self.videoConstraints = videoConstraints
    self.fixedTrackId = fixedTrackId
    self.opaqueRetention = opaqueRetention
    self.credentialContext = credentialContext
    self.originURL = originURL
    self.hasExplicitCredentials = !credentials.isEmpty || headers.keys.contains {
      ["authorization", "cookie", "proxy-authorization"].contains($0.lowercased())
    }
    self.headerPolicy = YlHlsHeaderPolicy(originURL: originURL, headers: headers, credentials: credentials)
    self.configuration = configuration
    self.mediaProxy = try YlHlsMediaProxy(
      originURL: originURL,
      upstreamDiagnostics: upstreamDiagnostics,
      headers: headers,
      credentials: credentials,
      configuration: configuration,
      credentialContext: credentialContext, opaqueRetention: opaqueRetention, trafficScope: trafficScope
    )
    super.init()

    let sessionConfiguration = sessionConfiguration.copy()
      as? URLSessionConfiguration ?? sessionConfiguration
    sessionConfiguration.httpShouldSetCookies = false
    sessionConfiguration.httpCookieStorage = nil
    sessionConfiguration.urlCredentialStorage = nil
    sessionConfiguration.timeoutIntervalForRequest = TimeInterval(
      max(1, configuration.readTimeoutMs)
    ) / 1_000
    sessionConfiguration.timeoutIntervalForResource = TimeInterval(
      max(1, configuration.connectTimeoutMs + configuration.readTimeoutMs)
    ) / 1_000
    let delegateQueue = OperationQueue()
    delegateQueue.name = "dev.ylplayer.hls.url-session"
    delegateQueue.maxConcurrentOperationCount = 1
    delegateQueue.qualityOfService = .userInitiated
    session = sessionFactory(sessionConfiguration, self, delegateQueue)
  }

  var dashSnapshot: YlDashManifestSnapshot? {
    stateLock.withLock { acceptedDashSnapshot }
  }

  var audioCatalog: [YlNativeTrack]? {
    stateLock.withLock { dashPresentation?.audioCatalog }
  }
  var videoCatalog: YlDashVideoCatalog? {
    stateLock.withLock { dashPresentation?.videoCatalog }
  }

  func encodedAssetURL() throws -> URL {
    let root = try stateLock.withLock { () throws -> URL in
      guard !cancelled else { throw Self.cancelledError() }
      guard isDash else { return originURL }
      guard let root = dashPresentation?.rootURL else { throw Self.virtualResourceError() }
      return root
    }
    return try YlHlsURLCodec.encode(root, kind: .manifest)
  }

  @discardableResult
  func startLoading(_ loadingRequest: YlHlsLoadingRequest) -> Bool {
    let destination: URL
    let resourceKind: YlHlsResourceKind
    do {
      destination = try YlHlsURLCodec.decode(loadingRequest.url)
      resourceKind = try YlHlsURLCodec.resourceKind(loadingRequest.url)
    } catch let error as NativePlayerError {
      loadingRequest.finishLoading(with: error)
      return true
    } catch {
      loadingRequest.finishLoading(with: Self.internalError(error))
      return true
    }

    if isDash {
      let state = stateLock.withLock {
        (cancelled, resourceKind == .manifest ? dashPresentation?.manifests[destination] : nil)
      }
      if state.0 { loadingRequest.finishLoading(with: Self.cancelledError()) }
      else if let data = state.1 { respond(Self.virtualResponse(data), to: loadingRequest) }
      else { loadingRequest.finishLoading(with: Self.virtualResourceError()) }
      return true
    }
    let cacheKey = destination.absoluteString
    let credentialsStripped = YlHlsURLCodec.credentialsStripped(loadingRequest.url) || !headerPolicy.isSourceOrigin(destination) || credentialContext.isStripped(cacheKey)
    let loaderState = stateLock.withLock {
      (cancelled: cancelled, cached: cachedResponses["\(credentialsStripped):\(cacheKey)"])
    }
    if loaderState.cancelled {
      loadingRequest.finishLoading(with: Self.cancelledError())
      return true
    }
    if credentialsStripped { credentialContext.strip(cacheKey) }
    if let cached = loaderState.cached {
      respond(cached, to: loadingRequest)
      return true
    }

    return startUpstreamLoading(loadingRequest, destination: destination,
      resourceKind: resourceKind, credentialsStripped: credentialsStripped)
  }

  // DASH calls this only for its original MPD preflight. Public loading requests
  // in virtual mode cannot enter this network path, even before publication.
  private func startUpstreamLoading(_ loadingRequest: YlHlsLoadingRequest,
    destination: URL, resourceKind: YlHlsResourceKind, credentialsStripped: Bool) -> Bool {
    let isManifest = resourceKind == .manifest
    let rangeHeader = isManifest ? nil : Self.rangeHeader(for: loadingRequest)
    if resourceKind == .media {
      do {
        if hasExplicitCredentials {
          var proxyRequest = URLRequest(url: try mediaProxy.proxyURL(for: destination, credentialsStripped: credentialsStripped))
          if let rangeHeader { proxyRequest.setValue(rangeHeader, forHTTPHeaderField: "Range") }
          loadingRequest.redirect(to: proxyRequest)
        } else {
          // Preserve the absent-metadata v1 route. V2 credential sources always
          // use the controlled proxy so AVFoundation cannot restore credentials.
          loadingRequest.redirect(to: makeRequest(url: destination, rangeHeader: rangeHeader, credentialsStripped: credentialsStripped))
        }
      } catch {
        loadingRequest.finishLoading(with: Self.internalError(error))
        return true
      }
      loadingRequest.finishLoading()
      return true
    }
    var request = makeRequest(url: destination, rangeHeader: rangeHeader, credentialsStripped: credentialsStripped)
    if (loadingRequest as? PreflightRequest)?.index != nil {
      request.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
    }
    let record = TaskRecord(
      request: loadingRequest,
      destinationURL: destination,
      rangeHeader: rangeHeader,
      isManifest: isManifest
    )
    record.requestContext = headerPolicy.requestContext(for: destination, credentialsStripped: credentialsStripped)
    record.opaqueRetention = opaqueRetention
    let accepted = stateLock.withLock { () -> Bool in
      // Session invalidation follows cancellation under this lock. Never call
      // its task factory, publish a record, or resume after that ownership ends.
      guard !cancelled else { return false }
      let task = session.dataTask(with: request)
      record.task = task
      records[task.taskIdentifier] = record
      task.resume()
      return true
    }
    guard accepted else {
      loadingRequest.finishLoading(with: Self.cancelledError())
      return true
    }
    return true
  }

  private func compile(_ snapshot: YlDashManifestSnapshot) throws -> YlDashHlsPresentation {
    try YlDashHlsCompiler.compile(data: snapshot.data,
      finalManifestURL: snapshot.effectiveURL, sourceURL: originURL,
      credentialsStripped: snapshot.credentialsStripped, indexes: snapshot.indexes,
      videoConstraints: videoConstraints, fixedTrackId: fixedTrackId,
      manifestURL: { [virtualNamespace] name in
        URL(string: "http://yl-dash.invalid/\(virtualNamespace)/\(name).m3u8")!
      },
      mediaURL: { [mediaProxy, credentialContext] url, stripped in
        try mediaProxy.proxyURL(for: url,
          credentialsStripped: stripped || credentialContext.isStripped(url.absoluteString))
      })
  }

  func preflight(cancellationToken: YlOpenCancellationToken, snapshot: YlDashManifestSnapshot? = nil) throws {
    try cancellationToken.throwIfCancelled()
    cancellationToken.onCancel { [weak self] in self?.cancelAll() }
    let maximumWaitMs = max(1_000, configuration.connectTimeoutMs + configuration.readTimeoutMs + 1_000)
    let deadline = DispatchTime.now() + .milliseconds(Int(maximumWaitMs))
    func wait(_ request: PreflightRequest) throws {
      if request.semaphore.wait(timeout: deadline) == .timedOut {
        cancelAll()
        throw NativePlayerError(category: "network", code: "network.read_timeout",
          message: "The manifest and segment index preparation timed out.")
      }
      try cancellationToken.throwIfCancelled()
      if let error = request.error { throw error }
    }
    do {
      if isDash {
        try stateLock.withLock {
          guard !cancelled else { throw Self.cancelledError() }
          guard !preflightStarted else { throw Self.virtualResourceError() }
          preflightStarted = true
        }
        let accepted: YlDashManifestSnapshot
        if let snapshot { accepted = snapshot }
        else {
          let request = PreflightRequest(url: originURL)
          _ = startUpstreamLoading(request, destination: originURL, resourceKind: .manifest,
            credentialsStripped: credentialContext.isStripped(originURL.absoluteString))
          try wait(request)
          let requests = try YlDashDocument(source: originURL).indexRequests(request.data,
            final: request.effectiveURL, credentialsStripped: request.credentialsStripped)
          var indexes: [YlDashIndexRequest: YlDashResolvedIndex] = [:]
          var remaining = YlDashBounds.maxSegments
          for index in requests {
            try cancellationToken.throwIfCancelled()
            guard DispatchTime.now() < deadline else {
              throw NativePlayerError(category: "network", code: "network.read_timeout",
                message: "The segment index preparation timed out.")
            }
            let fetch = PreflightRequest(url: index.url, index: index)
            _ = startUpstreamLoading(fetch, destination: index.url, resourceKind: .key,
              credentialsStripped: index.credentialsStripped || credentialContext.isStripped(index.url.absoluteString))
            try wait(fetch)
            let parsed = try YlDashSidx.parse(fetch.data,
              boxEndOffset: UInt64(index.start) + UInt64(index.length), maxReferences: remaining)
            remaining -= parsed.references.count
            indexes[index] = YlDashResolvedIndex(index: parsed, effectiveURL: fetch.effectiveURL,
              credentialsStripped: fetch.credentialsStripped, resourceLength: fetch.resourceLength)
          }
          accepted = YlDashManifestSnapshot(data: request.data, effectiveURL: request.effectiveURL,
            credentialsStripped: request.credentialsStripped, indexes: indexes)
        }
        let presentation = try compile(accepted)
        try cancellationToken.throwIfCancelled()
        guard DispatchTime.now() < deadline else {
          throw NativePlayerError(category: "network", code: "network.read_timeout",
            message: "The DASH presentation preparation timed out.")
        }
        try stateLock.withLock {
          guard !cancelled else { throw Self.cancelledError() }
          for resource in presentation.strippedResources { credentialContext.strip(resource) }
          dashPresentation = presentation
          acceptedDashSnapshot = accepted
        }
      } else {
        let request = PreflightRequest(url: try encodedAssetURL())
        _ = startLoading(request)
        try wait(request)
      }
    } catch {
      cancelAll()
      if let admission = error as? YlDashAdmissionError { throw admission.nativeError }
      if let index = error as? YlDashSidxError { throw index.nativeError }
      throw error
    }
  }

  func cancelAll() {
    let pending = stateLock.withLock { () -> [TaskRecord] in
      guard !cancelled else { return [] }
      cancelled = true
      let pending = Array(records.values)
      records.removeAll()
      cachedResponses.removeAll()
      dashPresentation = nil
      acceptedDashSnapshot = nil
      return pending
    }
    for record in pending {
      record.task?.cancel()
      record.request.finishLoading(with: Self.cancelledError())
    }
    session.invalidateAndCancel()
    mediaProxy.cancelAll()
  }

  func resourceLoader(
    _ resourceLoader: AVAssetResourceLoader,
    shouldWaitForLoadingOfRequestedResource loadingRequest: AVAssetResourceLoadingRequest
  ) -> Bool {
    guard let adapter = YlAVAssetLoadingRequestAdapter(loadingRequest) else {
      loadingRequest.finishLoading(with: NativePlayerError(
        category: "container",
        code: "container.hls_url_invalid",
        message: "The HLS resource request URL is missing."
      ))
      return true
    }
    return startLoading(adapter)
  }

  func resourceLoader(
    _ resourceLoader: AVAssetResourceLoader,
    didCancel loadingRequest: AVAssetResourceLoadingRequest
  ) {
    let matching = stateLock.withLock { () -> TaskRecord? in
      guard let pair = records.first(where: {
        ($0.value.request as? YlAVAssetLoadingRequestAdapter)?.loadingRequest
          === loadingRequest
      }) else { return nil }
      records.removeValue(forKey: pair.key)
      return pair.value
    }
    matching?.task?.cancel()
  }

  deinit {
    cancelAll()
  }

  private func makeRequest(url: URL, rangeHeader: String?, credentialsStripped: Bool = false) -> URLRequest {
    var request = URLRequest(url: url)
    request.timeoutInterval = TimeInterval(max(1, configuration.readTimeoutMs)) / 1_000
    let ownedHeaders = Set(["range", "if-range", "host", "content-length"])
    for (name, value) in headerPolicy.headers(for: url, credentialsStripped: credentialsStripped)
      where !ownedHeaders.contains(name.lowercased()) {
      request.setValue(value, forHTTPHeaderField: name)
    }
    if let rangeHeader {
      request.setValue(rangeHeader, forHTTPHeaderField: "Range")
    }
    return request
  }

  private func respond(_ cached: CachedResponse, to request: YlHlsLoadingRequest) {
    request.setContentInformation(
      contentType: cached.contentType,
      contentLength: cached.contentLength,
      byteRangeAccessSupported: cached.byteRangeAccessSupported
    )
    request.respond(with: Self.requestedSlice(of: cached.data, for: request))
    request.finishLoading()
  }

  private func finish(
    task: URLSessionTask,
    result: Result<CachedResponse?, NativePlayerError>
  ) {
    let record = stateLock.withLock { () -> TaskRecord? in
      guard let record = records.removeValue(forKey: task.taskIdentifier) else {
        return nil
      }
      if !cancelled, !isDash,
         case let .success(cached?) = result,
         record.cacheKey == originURL.absoluteString {
        cachedResponses["\(record.credentialsStripped):\(record.cacheKey)"] = cached
      }
      return record
    }
    guard let record else { return }
    switch result {
    case let .success(cached):
      upstreamDiagnostics.succeeded(resource: record.cacheKey)
      if let preflight = record.request as? PreflightRequest {
        preflight.effectiveURL = record.destinationURL
        preflight.credentialsStripped = record.credentialsStripped
      }
      if let cached {
        if record.indexRequest != nil {
          // These bytes already represent the absolute requested range; do not
          // slice them again at the original file offset.
          record.request.respond(with: cached.data)
          record.request.finishLoading()
        } else { respond(cached, to: record.request) }
      } else {
        record.request.finishLoading()
      }
    case let .failure(error):
      upstreamDiagnostics.record(error, resource: record.cacheKey, httpStatus: record.response?.statusCode)
      task.cancel()
      record.request.finishLoading(with: error)
    }
  }

  private func record(for task: URLSessionTask) -> TaskRecord? {
    stateLock.withLock { records[task.taskIdentifier] }
  }

  private func isCurrent(_ record: TaskRecord, task: URLSessionTask) -> Bool {
    stateLock.withLock { records[task.taskIdentifier] === record }
  }

  private static func requestedSlice(
    of data: Data,
    for request: YlHlsLoadingRequest
  ) -> Data {
    let offset = max(0, request.currentOffset == 0
      ? request.requestedOffset : request.currentOffset)
    guard offset < data.count else { return Data() }
    let start = Int(offset)
    let end: Int
    if request.requestsAllDataToEnd || request.requestedLength <= 0 {
      end = data.count
    } else {
      end = start + min(data.count - start, request.requestedLength)
    }
    return data.subdata(in: start..<end)
  }

  private static func rangeHeader(for request: YlHlsLoadingRequest) -> String? {
    let offset = max(0, request.currentOffset == 0
      ? request.requestedOffset : request.currentOffset)
    if request.requestsAllDataToEnd {
      return offset > 0 ? "bytes=\(offset)-" : nil
    }
    guard request.requestedLength > 0 else { return nil }
    let addition = Int64(request.requestedLength - 1)
    let end = offset.addingReportingOverflow(addition)
    guard !end.overflow else { return "bytes=\(offset)-" }
    return "bytes=\(offset)-\(end.partialValue)"
  }

  private static func isManifestResponse(_ response: HTTPURLResponse) -> Bool {
    guard let mime = response.mimeType?.lowercased() else { return false }
    return mime.contains("mpegurl") || mime.contains("m3u")
  }

  private static func contentType(_ response: HTTPURLResponse) -> String? {
    guard let mime = response.mimeType else { return nil }
    if #available(iOS 14.0, macOS 14.0, *) {
      return UTType(mimeType: mime)?.identifier ?? mime
    }
    return UTTypeCreatePreferredIdentifierForTag(
      kUTTagClassMIMEType,
      mime as CFString,
      nil
    )?.takeRetainedValue() as String? ?? mime
  }

  private static func responseContentLength(_ response: HTTPURLResponse) -> Int64 {
    if response.statusCode == 206,
       let range = parsedContentRange(response) {
      return range.total
    }
    return max(0, response.expectedContentLength)
  }

  private static func parsedContentRange(
    _ response: HTTPURLResponse
  ) -> (start: Int64, total: Int64)? {
    guard let value = response.value(forHTTPHeaderField: "Content-Range"),
          value.lowercased().hasPrefix("bytes "),
          let space = value.firstIndex(of: " "),
          let dash = value[value.index(after: space)...].firstIndex(of: "-"),
          let slash = value[dash...].firstIndex(of: "/"),
          let start = Int64(value[value.index(after: space)..<dash]),
          let total = Int64(value[value.index(after: slash)...]) else { return nil }
    return (start, total)
  }

  private static func supportsByteRanges(_ response: HTTPURLResponse) -> Bool {
    response.statusCode == 206
      || response.value(forHTTPHeaderField: "Accept-Ranges")?.lowercased() == "bytes"
  }

  private static func transportError(_ error: Error) -> NativePlayerError {
    YlNetworkByteSource.transportError(error)
  }

  private static func indexRangeError() -> NativePlayerError {
    NativePlayerError(category: "network", code: "network.range_invalid",
      message: "The DASH index server did not return the exact requested byte range. Use a source with byte-range support.")
  }

  private static func virtualResourceError() -> NativePlayerError {
    NativePlayerError(category: "container", code: "container.hls_url_invalid",
      message: "The private manifest resource is unavailable.")
  }

  private static func virtualResponse(_ data: Data) -> CachedResponse {
    CachedResponse(data: data, contentType: "com.apple.m3u-playlist",
      contentLength: Int64(data.count), byteRangeAccessSupported: true)
  }

  private var manifestLimitError: NativePlayerError {
    NativePlayerError(category: "resource",
      code: isDash ? "resource.dash_manifest_too_large" : "resource.hls_manifest_too_large",
      message: "The manifest exceeds the 2 MiB limit.")
  }

  private static func cancelledError() -> NativePlayerError {
    NativePlayerError(
      category: "cancelled",
      code: "network.cancelled",
      message: "The HLS resource request was cancelled."
    )
  }

  private static func internalError(_ error: Error) -> NativePlayerError {
    NativePlayerError(
      category: "internal",
      code: "\(YlApplePlatform.current.rawValue).hls_loader_failed",
      message: "The HLS resource loader failed.",
      diagnostic: YlAppleSafeDiagnostics.diagnostic(error)
    )
  }
}

extension YlHlsResourceLoader: URLSessionDataDelegate, URLSessionTaskDelegate {
  func urlSession(
    _ session: URLSession,
    dataTask: URLSessionDataTask,
    didReceive response: URLResponse,
    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void
  ) {
    guard let record = record(for: dataTask),
          let response = response as? HTTPURLResponse else {
      completionHandler(.cancel)
      if record(for: dataTask) != nil {
        finish(task: dataTask, result: .failure(NativePlayerError(
          category: "network",
          code: "network.http_status",
          message: "The HLS server returned an invalid response."
        )))
      }
      return
    }
    guard (200...299).contains(response.statusCode) else {
      completionHandler(.cancel)
      finish(task: dataTask, result: .failure(YlHTTPFailure.error(status: response.statusCode)))
      return
    }
    record.response = response
    record.destinationURL = response.url ?? record.destinationURL
    if let fetch = record.indexRequest, let index = fetch.index {
      let expectedEnd = index.start + Int64(index.length - 1)
      let value = response.value(forHTTPHeaderField: "Content-Range") ?? ""
      let parts = value.components(separatedBy: "/")
      let total = parts.count == 2 ? Int64(parts[1]) : nil
      guard response.statusCode == 206, parts.first == "bytes \(index.start)-\(expectedEnd)",
        let total, total > expectedEnd,
        response.expectedContentLength == -1 || response.expectedContentLength == index.length,
        response.value(forHTTPHeaderField: "Content-Encoding") == nil || response.value(forHTTPHeaderField: "Content-Encoding") == "identity" else {
        completionHandler(.cancel)
        finish(task: dataTask, result: .failure(Self.indexRangeError()))
        return
      }
      fetch.resourceLength = total
      completionHandler(.allow)
      return
    }
    record.isManifest = record.isManifest || Self.isManifestResponse(response)
    if response.statusCode == 206 {
      guard let range = Self.parsedContentRange(response),
            range.start == record.requestedStart else {
        completionHandler(.cancel)
        finish(task: dataTask, result: .failure(NativePlayerError(
          category: "network",
          code: "network.range_invalid",
          message: "The HLS byte-range response is invalid."
        )))
        return
      }
    } else if !record.isManifest {
      record.bytesToSkip = record.requestedStart
    }
    if record.isManifest,
       response.expectedContentLength > Self.manifestByteLimit {
      completionHandler(.cancel)
      finish(task: dataTask, result: .failure(manifestLimitError))
      return
    }
    if !record.isManifest {
      record.request.setContentInformation(
        contentType: Self.contentType(response),
        contentLength: Self.responseContentLength(response),
        byteRangeAccessSupported: Self.supportsByteRanges(response)
      )
    }
    completionHandler(.allow)
  }

  func urlSession(
    _ session: URLSession,
    dataTask: URLSessionDataTask,
    didReceive data: Data
  ) {
    guard let record = record(for: dataTask), isCurrent(record, task: dataTask)
    else { return }
    trafficScope?.recordNetworkBytes(data.count)
    if let fetch = record.indexRequest {
      guard data.count <= fetch.requestedLength - record.manifestData.count else {
        finish(task: dataTask, result: .failure(Self.indexRangeError()))
        return
      }
      record.manifestData.append(data)
    } else if record.isManifest {
      guard data.count <= Self.manifestByteLimit - record.manifestData.count else {
        finish(task: dataTask, result: .failure(manifestLimitError))
        return
      }
      record.manifestData.append(data)
    } else {
      var payload = data
      if record.bytesToSkip > 0 {
        let skipped = min(Int64(payload.count), record.bytesToSkip)
        payload.removeFirst(Int(skipped))
        record.bytesToSkip -= skipped
      }
      if let requestedLength = record.requestedLength {
        let remaining = max(0, requestedLength - record.bytesDelivered)
        if payload.count > remaining { payload = Data(payload.prefix(remaining)) }
      }
      guard !payload.isEmpty else { return }
      record.bytesDelivered += payload.count
      record.request.respond(with: payload)
    }
  }

  func urlSession(
    _ session: URLSession,
    task: URLSessionTask,
    didCompleteWithError error: Error?
  ) {
    guard let record = record(for: task) else { return }
    if let error {
      finish(task: task, result: .failure(Self.transportError(error)))
      return
    }
    if let fetch = record.indexRequest {
      guard record.manifestData.count == fetch.requestedLength else {
        finish(task: task, result: .failure(Self.indexRangeError()))
        return
      }
      finish(task: task, result: .success(Self.virtualResponse(record.manifestData)))
      return
    }
    guard record.isManifest else {
      finish(task: task, result: .success(nil))
      return
    }
    do {
      if isDash {
        finish(task: task, result: .success(Self.virtualResponse(record.manifestData)))
        return
      }
      let rewritten = try YlHlsManifestRewriter.rewrite(
        data: record.manifestData,
        baseURL: record.destinationURL,
        credentialsStripped: record.credentialsStripped,
        mediaURL: { [mediaProxy] in try mediaProxy.proxyURL(for: $0, credentialsStripped: record.credentialsStripped) }
      )
      let response = record.response
      finish(task: task, result: .success(CachedResponse(
        opaqueRetention: opaqueRetention,
        data: rewritten,
        contentType: response.flatMap(Self.contentType),
        contentLength: Int64(rewritten.count),
        byteRangeAccessSupported: false
      )))
    } catch let error as NativePlayerError {
      finish(task: task, result: .failure(error))
    } catch {
      finish(task: task, result: .failure(Self.internalError(error)))
    }
  }

  func urlSession(
    _ session: URLSession,
    task: URLSessionTask,
    willPerformHTTPRedirection response: HTTPURLResponse,
    newRequest request: URLRequest,
    completionHandler: @escaping (URLRequest?) -> Void
  ) {
    guard let record = record(for: task), let destination = request.url else {
      completionHandler(nil)
      return
    }
    record.requestContext = record.requestContext?.child(at: destination, redirect: true)
    if record.credentialsStripped { credentialContext.strip(record.cacheKey) }
    guard record.redirectCount <= configuration.maxRedirects else {
      completionHandler(nil)
      finish(task: task, result: .failure(NativePlayerError(
        category: "network",
        code: "network.redirect_limit",
        message: "The HLS redirect limit was exceeded."
      )))
      return
    }
    do {
      _ = try YlHlsURLCodec.encode(destination)
    } catch {
      completionHandler(nil)
      finish(task: task, result: .failure(NativePlayerError(
        category: "network",
        code: "network.redirect_invalid",
        message: "The HLS redirect target is invalid."
      )))
      return
    }
    record.destinationURL = destination
    var redirected = makeRequest(url: destination, rangeHeader: record.rangeHeader, credentialsStripped: record.credentialsStripped)
    if record.indexRequest != nil { redirected.setValue("identity", forHTTPHeaderField: "Accept-Encoding") }
    completionHandler(redirected)
  }
}

/// Accepted, bounded original MPD input. Value semantics preserve the unfiltered
/// bytes and effective redirect origin across projections and restoration.
struct YlDashManifestSnapshot {
  let data: Data
  let effectiveURL: URL
  let credentialsStripped: Bool
  let indexes: [YlDashIndexRequest: YlDashResolvedIndex]
  init(data: Data, effectiveURL: URL, credentialsStripped: Bool,
    indexes: [YlDashIndexRequest: YlDashResolvedIndex] = [:]) {
    self.data = data; self.effectiveURL = effectiveURL
    self.credentialsStripped = credentialsStripped; self.indexes = indexes
  }
}

final class YlPreparedHlsAsset {
  let asset: AVURLAsset
  let loader: YlHlsResourceLoader
  private let ownershipLock = NSLock()
  private var ownsLoader = true
  var automaticCandidate: YlPreparedHlsAsset?

  func takeAutomaticCandidate() -> YlPreparedHlsAsset? {
    let candidate = automaticCandidate; automaticCandidate = nil; return candidate
  }

  init(
    originURL: URL,
    isDash: Bool = false,
    videoConstraints: YlAppleVideoConstraints = .unconstrained,
    fixedTrackId: String? = nil,
    headers: [String: String],
    credentials: [String: String] = [:],
    configuration: YlNetworkConfiguration,
    cancellationToken: YlOpenCancellationToken,
    dashSnapshot: YlDashManifestSnapshot? = nil,
    credentialContext: YlHlsCredentialContext = YlHlsCredentialContext(),
    sessionConfiguration: URLSessionConfiguration = .ephemeral,
    opaqueRetention: YlManagedBufferLedger.OpaqueHlsRetention? = nil,
    trafficScope: YlManagedBufferScope? = nil
  ) throws {
    let loader = try YlHlsResourceLoader(
      originURL: originURL,
      isDash: isDash,
      videoConstraints: videoConstraints, fixedTrackId: fixedTrackId,
      headers: headers,
      credentials: credentials,
      configuration: configuration,
      credentialContext: credentialContext,
      sessionConfiguration: sessionConfiguration, opaqueRetention: opaqueRetention, trafficScope: trafficScope
    )
    self.loader = loader
    do {
      try loader.preflight(cancellationToken: cancellationToken, snapshot: dashSnapshot)
      let asset = AVURLAsset(url: try loader.encodedAssetURL())
      asset.resourceLoader.setDelegate(loader, queue: loader.resourceLoaderQueue)
      self.asset = asset
    } catch {
      loader.cancelAll()
      throw error
    }
  }

  func discard() {
    automaticCandidate?.discard(); automaticCandidate = nil
    let shouldCancel = ownershipLock.withLock { () -> Bool in
      guard ownsLoader else { return false }
      ownsLoader = false
      return true
    }
    if shouldCancel { loader.cancelAll() }
  }

  func takeLoader() throws -> YlHlsResourceLoader {
    try ownershipLock.withLock {
      guard ownsLoader else {
        throw NativePlayerError(
          category: "internal",
          code: "internal.fallback_invariant",
          message: "The prepared HLS asset was already consumed."
        )
      }
      ownsLoader = false
      return loader
    }
  }

  deinit {
    discard()
  }
}

private extension NSLock {
  func withLock<T>(_ body: () throws -> T) rethrows -> T {
    lock()
    defer { unlock() }
    return try body()
  }
}
