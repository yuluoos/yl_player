from pathlib import Path
import asyncio, contextlib, hashlib, json, shutil, sys, time
root = Path('/Users/yy2021_8689/.codex/worktrees/p04-weak-network-live/yl_player')
ns = {}
exec(Path('/private/tmp/p04_device_exclusive.py').read_text().split('async def main():')[0], ns)
Relay, LiveFixture, SOURCE = ns['Relay'], ns['LiveFixture'], ns['SOURCE']
run = 'p04-iphone-manual-av-' + time.strftime('%Y%m%d-%H%M%S')
out = ns['logs'] / run
out.mkdir()
test = root/'packages/yl_player/example/integration_test/p04_manual_av_test.dart'
proxy = Path('/Users/yy2021_8689/flutter/bin/cache/artifacts/libusbmuxd/iproxy')
backup = Path('/private/tmp/p04-iproxy-original-x86_64')
original_hash = 'e90e52022d917852d7b48bc7ff123b4a1ded3a4d8692e85c9ad0adca8bf78865'
wrapper = '#!/bin/sh\nunset DYLD_LIBRARY_PATH DYLD_FALLBACK_LIBRARY_PATH\nexec /opt/homebrew/bin/iproxy "$@"\n'
async def main():
    assert not test.exists()
    assert hashlib.sha256(proxy.read_bytes()).hexdigest() == original_hash
    assert hashlib.sha256(backup.read_bytes()).hexdigest() == original_hash
    relay = Relay()
    print('MANUAL_CAPTURE=' + str(out), flush=True)
    try:
        proxy.write_text(wrapper)
        shutil.copy2('/private/tmp/p04_manual_av_test.dart', test)
        shutil.copy2(test, out/test.name)
        with contextlib.ExitStack() as stack:
            urls = {}
            for protocol in ['hls', 'flv']:
                fixture = stack.enter_context(LiveFixture(protocol, SOURCE, out/(protocol+'-source'), run+'-'+protocol, '/opt/homebrew/bin/ffmpeg'))
                await relay.start(fixture.port)
                urls[protocol] = f'http://192.168.50.196:{fixture.port}/live.' + ('m3u8' if protocol=='hls' else 'flv')
            await relay.start(19351)
            urls['rtmp'] = 'rtmp://192.168.50.196:19351/live/owned'
            args = ['/Users/yy2021_8689/flutter/bin/flutter', 'test', '--no-pub', '--no-uninstall',
                    'integration_test/p04_manual_av_test.dart', '-d', ns['DEVICE'], '--reporter', 'expanded',
                    '--dart-define=YL_LIVE_RUN='+run]
            args += [f'--dart-define=P04_{k.upper()}={v}' for k,v in urls.items()]
            (out/'command.json').write_text(json.dumps(args))
            with (out/'capture.log').open('w') as log:
                child = await asyncio.create_subprocess_exec(*args,cwd=root/'packages/yl_player/example',stdout=log,stderr=asyncio.subprocess.STDOUT)
                try:
                    code = await asyncio.wait_for(child.wait(), 600)
                except asyncio.TimeoutError:
                    child.terminate()
                    try: await asyncio.wait_for(child.wait(), 10)
                    except asyncio.TimeoutError: child.kill(); await child.wait()
                    code = 124
            (out/'exit-code').write_text(str(code))
            print('MANUAL_EXIT='+str(code), flush=True)
            return code
    finally:
        await relay.close()
        test.unlink(missing_ok=True)
        assert proxy.read_text() == wrapper
        shutil.copy2(backup, proxy)
        restored = hashlib.sha256(proxy.read_bytes()).hexdigest() == original_hash
        (out/'cleanup.json').write_text(json.dumps({'relayTasks':len(relay.tasks),'relayWriters':len(relay.writers),'iproxyRestored':restored,'temporaryTestRemoved':not test.exists()}))
        print('MANUAL_CLEANUP='+str(restored), flush=True)
sys.exit(asyncio.run(main()))
