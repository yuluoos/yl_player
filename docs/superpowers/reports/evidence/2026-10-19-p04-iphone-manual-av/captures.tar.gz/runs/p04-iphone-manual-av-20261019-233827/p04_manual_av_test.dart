import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:yl_player/yl_player.dart';
import 'support/live_mode_series.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  testWidgets('iPhone guided physical audio video observation', (tester) async {
    final label = ValueNotifier<String>('准备音画观察');
    for (final protocol in ['hls', 'flv', 'rtmp']) {
      final urls = {
        'hls': const String.fromEnvironment('P04_HLS'),
        'flv': const String.fromEnvironment('P04_FLV'),
        'rtmp': const String.fromEnvironment('P04_RTMP'),
      };
      final config = parseLiveModeConfig({
        'runId': const String.fromEnvironment('YL_LIVE_RUN'),
        'protocol': protocol,
        'url': urls[protocol]!,
        'owned': 'true',
        'ownedHost': '192.168.50.196',
        'mediaHash': 'cfe009b1b03b6cacf4ae9f037eed4441a32b99508d4fabccb429bea439cf570b',
      });
      final player = await YlPlayerController.create();
      var completed = false;
      try {
        await tester.pumpWidget(MaterialApp(
          home: Scaffold(backgroundColor: Colors.black, body: SafeArea(
            child: Column(children: [
              ValueListenableBuilder<String>(
                valueListenable: label,
                builder: (_, value, _) => Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(value, textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 24)),
                ),
              ),
              Expanded(child: YlPlayerView(controller: player)),
            ]),
          )),
        ));
        Future<void> show(String stage, int seconds) async {
          debugPrintSynchronously('P04_MANUAL_STAGE=${jsonEncode({
            'protocol': protocol, 'stage': stage, 'seconds': seconds,
          })}');
          for (var remaining = seconds; remaining > 0; remaining--) {
            label.value = '${protocol.toUpperCase()} · $stage\n剩余 $remaining 秒';
            await tester.pump();
            await Future<void>.delayed(const Duration(seconds: 1));
            expect(player.state.failure, isNull);
          }
        }
        await show('即将开始，请看画面并听声音', 5);
        final session = await player.load(YlNetworkSource(
          Uri.parse(config['url']!), intent: YlStreamIntent.live,
          format: protocol == 'hls' ? YlMediaFormat.hls : YlMediaFormat.flv,
        )).timeout(const Duration(seconds: 20));
        await session.ready.timeout(const Duration(seconds: 20));
        await player.setVolume(1);
        await session.play();
        await session.firstFrame.timeout(const Duration(seconds: 20));
        Future<void> pauseAndObserve() async {
          await session.pause();
          if (player.state.status != YlPlaybackStatus.paused) {
            await player.states.firstWhere(
              (state) => state.sessionId == session.id &&
                  state.status == YlPlaybackStatus.paused,
            ).timeout(const Duration(seconds: 5));
          }
          expect(player.state.status, YlPlaybackStatus.paused);
        }
        await show('流畅模式播放：画面变化、有声音', 15);
        await pauseAndObserve();
        await show('暂停：画面停止、声音停止', 5);
        await session.setLivePlaybackMode(YlLivePlaybackMode.lowLatency);
        await session.play();
        await show('低延迟模式播放：画面变化、有声音', 15);
        await pauseAndObserve();
        await show('再次暂停：画面停止、声音停止', 5);
        await session.play();
        await show('恢复播放：画面变化、有声音', 15);
        await player.stop();
        completed = true;
      } finally {
        await player.dispose().timeout(const Duration(seconds: 5));
        debugPrintSynchronously('P04_MANUAL_RESULT=${jsonEncode({
          'protocol': protocol, 'completed': completed,
          'physicalObservation': 'pending-user', 'endToEndLatencyUs': null,
        })}');
      }
    }
    await tester.pumpWidget(const MaterialApp(home: Scaffold(body: Center(
      child: Text('音画观察结束\n请在聊天中反馈 HLS / FLV / RTMP 的观察结果',
        textAlign: TextAlign.center),
    ))));
    await Future<void>.delayed(const Duration(seconds: 5));
    label.dispose();
  }, timeout: const Timeout(Duration(minutes: 7)));
}
