import Foundation
final class Probe: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
  let done = DispatchSemaphore(value: 0)
  func urlSession(_ session: URLSession, task: URLSessionTask, didFinishCollecting metrics: URLSessionTaskMetrics) {
    let rows = metrics.transactionMetrics.map { t in ["fetch": t.fetchStartDate != nil, "requestStart": t.requestStartDate != nil, "requestEnd": t.requestEndDate != nil, "responseStart": t.responseStartDate != nil, "responseEnd": t.responseEndDate != nil] }
    print(String(decoding: try! JSONSerialization.data(withJSONObject: ["transactions": rows, "redirects": metrics.redirectCount]), as: UTF8.self))
  }
}
let p = Probe(), c = URLSessionConfiguration.ephemeral
c.timeoutIntervalForRequest = 3
let session = URLSession(configuration: c, delegate: p, delegateQueue: nil)
session.dataTask(with: URL(string: CommandLine.arguments[1])!) { data, _, error in
  print("bytes=\(data?.count ?? 0) error=\((error as NSError?)?.code ?? 0)");p.done.signal()
}.resume()
_ = p.done.wait(timeout: .now() + 8)
session.invalidateAndCancel()
