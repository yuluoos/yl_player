import os,sys,subprocess,time,signal
from pathlib import Path
root=Path(sys.argv[1]);out=Path('/private/tmp/yl-remaining-20261026-rtmp-jvm-retry')
signal.signal(signal.SIGTERM,lambda *_:sys.exit(143))
cmd=['/opt/homebrew/bin/ffmpeg','-nostdin','-hide_banner','-loglevel','warning','-re','-stream_loop','-1','-i',str(root/'tool/consumer_fixtures/apple_flutter/Resources/h264_aac.flv'),'-c:v','libx264','-preset','ultrafast','-tune','zerolatency','-b:v','4M','-minrate','4M','-maxrate','4M','-bufsize','8M','-x264-params','nal-hrd=cbr:force-cfr=1','-c:a','copy','-f','flv','rtmp://127.0.0.1:19350/live/burst']
with (out/'burst-publisher.log').open('w') as log:
 peer=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
 try:
  time.sleep(1)
  if peer.poll() is not None:raise RuntimeError('Owned burst publisher failed')
  result=subprocess.run(['./gradlew',':yl_player_android:testDebugUnitTest','--tests','dev.ylplayer.yl_player_android.YlRtmpExtractorTest','--console=plain'],cwd=root/'packages/yl_player_android/example/android')
  sys.exit(result.returncode)
 finally:
  if peer.poll() is None:
   peer.terminate()
   try:peer.wait(timeout=10)
   except subprocess.TimeoutExpired:peer.kill();peer.wait()
