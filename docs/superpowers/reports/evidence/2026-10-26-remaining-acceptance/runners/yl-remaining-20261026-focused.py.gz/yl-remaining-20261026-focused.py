import os,sys,json,time,subprocess,signal,hashlib
from pathlib import Path
root=Path(sys.argv[1]);out=Path('/private/tmp/yl-remaining-20261026-focused');out.mkdir(exist_ok=False)
env=os.environ.copy();env['PATH']='/private/tmp/yl-remaining-20261026-python/bin:/Users/yy2021_8689/flutter/bin:'+env['PATH'];results=[]
def run(name,cmd,cwd=root,timeout=900):
 print('START '+name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   code=124
 results.append(dict(name=name,command=cmd,exitCode=code,seconds=round(time.monotonic()-start,3)))
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('END '+name+' '+str(code),flush=True);return code
for platform,dest,sdk in [('macos','platform=macOS,arch=arm64','macosx'),('ios','platform=iOS Simulator,id=B4B1FA2D-8FFC-490D-8E1E-29EE3FEB5EB8','iphonesimulator')]:
 command=['flutter','build',platform,'--debug','--config-only']
 if platform=='ios':command.append('--simulator')
 if run(platform+'-config',command,root/'packages/yl_player/example'):continue
 cases=['YlAppleCompatibilityTests/testIosOverflowPreservesTheNextFramesForPresentation()','YlAppleCompatibilityTests/testMacosOverflowRejectsNewestAndPreservesQueuedOrder()','YlDashResourceLoaderTests/testIndexedPreflightRejectsWrongRangesWholeFilesAndTruncatedBodies()']
 if platform=='macos':cases.append('YlMacosPresentationTests/testFrameSchedulerBackpressuresUntilPresentationFreesCapacity()')
 else:cases += ['YlFrameSchedulerTests/testDefaultQueuePresentsSixteenPictureHEVCReorderGroupWithoutDrops()', 'YlOpenCoordinatorTests/testHeaderedHlsPreflightFailureDoesNotReplaceActiveCandidate()']
 bundle=out/(platform+'.xcresult')
 cmd=['xcodebuild','test','-quiet','CODE_SIGNING_ALLOWED=NO','ENABLE_TESTABILITY=YES','-sdk',sdk,'-configuration','Debug','-workspace',str(root/f'packages/yl_player/example/{platform}/Runner.xcworkspace'),'-scheme','Runner','-destination',dest,'-derivedDataPath','/private/tmp/yl-remaining-20261026-'+platform,'-parallel-testing-enabled','NO','-resultBundlePath',str(bundle)]+['-only-testing:RunnerTests/'+c.removesuffix('()') for c in cases]
 if platform=='macos':cmd=['python3','-B','tool/run_with_display_awake.py']+cmd
 run(platform+'-native',cmd)
 cmd=['python3','-B','tool/consumer_fixtures/apple_flutter/main_example_tests.py','--result-bundle',str(bundle),'--platform',platform,'--output',str(out/(platform+'-runtime'))]
 for c in cases:cmd+=['--selected-case',c]
 run(platform+'-identities',cmd)
 products=Path('/private/tmp/yl-remaining-20261026-'+platform)/'Build/Products'
 (out/(platform+'-binary-hashes.json')).write_text(json.dumps({str(p.relative_to(products)):hashlib.sha256(p.read_bytes()).hexdigest() for p in products.rglob('*') if p.is_file() and ('.app/' in str(p) or p.suffix=='.xctestrun')},indent=2)+'\n')
