import os,sys,subprocess,json,time,signal
from pathlib import Path
root=Path(sys.argv[1]); out=Path('/private/tmp/yl-remaining-20261026-validation');out.mkdir(exist_ok=False)
env=os.environ.copy();env['PATH']='/private/tmp/yl-remaining-20261026-python/bin:/Users/yy2021_8689/flutter/bin:'+env['PATH'];env['YL_RUN_DECODE_PROBE']='1';env['JAVA_HOME']='/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home'
results=[]
def run(name,command,cwd=root,timeout=2400):
 print('START '+name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  p=subprocess.Popen(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try: code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   code=124
 result=dict(name=name,command=command,cwd=str(cwd),exitCode=code,seconds=round(time.monotonic()-start,3))
 results.append(result);(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('END '+name+' '+str(code),flush=True)
run('foundation',['sh','tool/check_foundation.sh'])
run('android-jvm',['./gradlew',':yl_player_android:testDebugUnitTest','--console=plain'],root/'packages/yl_player_android/example/android')
for platform,destination in [('macos','platform=macOS,arch=arm64'),('ios','platform=iOS Simulator,id=B4B1FA2D-8FFC-490D-8E1E-29EE3FEB5EB8')]:
 products=Path('/private/tmp/yl-remaining-20261026-'+platform)/'Build/Products'
 manifests=list(products.glob('*.xctestrun'))
 if len(manifests)!=1:raise RuntimeError('test manifest missing or ambiguous')
 bundle=out/(platform+'.xcresult')
 command=['xcodebuild','test-without-building','-quiet','-xctestrun',str(manifests[0]),'-destination',destination,'-parallel-testing-enabled','NO','-test-timeouts-enabled','YES','-default-test-execution-time-allowance','180','-maximum-test-execution-time-allowance','180','-resultBundlePath',str(bundle)]
 if platform=='macos':command=['python3','-B','tool/run_with_display_awake.py']+command
 run(platform+'-native',command,timeout=3600)
 run(platform+'-identities',['python3','-B','tool/consumer_fixtures/apple_flutter/main_example_tests.py','--result-bundle',str(bundle),'--platform',platform,'--output',str(out/(platform+'-runtime'))])
run('p08-extra',['sh','tool/check_p08.sh','--validate'])
