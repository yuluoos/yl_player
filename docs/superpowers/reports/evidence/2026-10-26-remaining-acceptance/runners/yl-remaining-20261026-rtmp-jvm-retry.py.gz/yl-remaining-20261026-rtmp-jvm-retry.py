import os,subprocess,sys,json,time,gzip,signal
from pathlib import Path
root=Path(sys.argv[1]);out=Path('/private/tmp/yl-remaining-20261026-rtmp-jvm-retry');out.mkdir(exist_ok=False)
env=os.environ.copy();env['JAVA_HOME']='/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home';env['YL_RTMP_PEER_PORT']='19350'
cmd=['python3','-B',str(root/'tool/rtmp_acceptance/run.py'),'--','python3','/private/tmp/yl-remaining-20261026-rtmp-gradle-retry.py',str(root)]
start=time.monotonic()
with (out/'run.log').open('w') as log:
 r=subprocess.Popen(cmd,cwd=root/'packages/yl_player_android/example/android',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:r.wait(timeout=600)
 except subprocess.TimeoutExpired:
  os.killpg(r.pid,signal.SIGTERM)
  try:r.wait(timeout=60)
  except subprocess.TimeoutExpired:os.killpg(r.pid,signal.SIGKILL);r.wait()
(out/'result.json').write_text(json.dumps({'command':cmd,'exitCode':r.returncode,'seconds':time.monotonic()-start,'peerPort':19350},indent=2)+'\n')
for p in (root/'packages/yl_player_android/example/build/yl_player_android/test-results/testDebugUnitTest').glob('TEST-*.xml'):
 (out/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
print('RTMP JVM exit',r.returncode,flush=True)
