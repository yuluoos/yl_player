/private/tmp/yl-remaining-20261026-consumers/android/android/gradlew -p /private/tmp/yl-remaining-20261026-consumers/android/android :app:assembleDebug --stacktrace
