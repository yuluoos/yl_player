package dev.ylplayer.yl_player_android

import android.graphics.SurfaceTexture
import android.opengl.GLES20
import android.os.Handler
import android.view.Surface
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import java.nio.ByteBuffer
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit

/** Samples the center of the latched decoder buffer and its timestamp on the playback looper. */
internal class YlDashSurfaceProbe(private val handler: Handler) {
    private fun <T> onPlaybackThread(action: () -> T): T {
        val task = FutureTask(action)
        check(handler.post(task))
        return task.get(5, TimeUnit.SECONDS)
    }

    private class Output {
        val display = GlUtil.getDefaultEglDisplay()
        val context = GlUtil.createEglContext(display)
        private val eglSurface = GlUtil.createFocusedPlaceholderEglSurface(context, display)
        private val sampleTexture = GlUtil.createTexture(1, 1, false)
        private val framebuffer = GlUtil.createFboForTexture(sampleTexture)
        private val decoderTexture = GlUtil.createExternalTexture()
        val texture = SurfaceTexture(decoderTexture)
        val surface = Surface(texture)
        private val pixel = ByteBuffer.allocateDirect(4)
        private val transform = FloatArray(16)
        private val program = GlProgram(
            "attribute vec4 position; void main() { gl_Position = position; }",
            """
                #extension GL_OES_EGL_image_external : require
                precision mediump float;
                uniform samplerExternalOES frame;
                uniform mat4 transform;
                void main() { gl_FragColor = texture2D(frame, (transform * vec4(0.5, 0.5, 0.0, 1.0)).xy); }
            """.trimIndent(),
        )

        init {
            GlUtil.focusFramebuffer(display, context, eglSurface, framebuffer, 1, 1)
            program.setBufferAttribute("position", floatArrayOf(-1f, -1f, 3f, -1f, -1f, 3f), 2)
            program.setSamplerTexIdUniform("frame", decoderTexture, 0)
        }

        fun sample(): List<Int> {
            texture.updateTexImage()
            texture.getTransformMatrix(transform)
            program.use()
            program.setFloatsUniform("transform", transform)
            program.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 3)
            pixel.clear()
            GLES20.glReadPixels(0, 0, 1, 1, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, pixel)
            GlUtil.checkGlError()
            return (0..2).map { pixel.get(it).toInt() and 255 }
        }

        fun close() {
            texture.setOnFrameAvailableListener(null)
            surface.release()
            texture.release()
            program.delete()
            GlUtil.deleteFbo(framebuffer)
            GlUtil.deleteTexture(sampleTexture)
            GlUtil.deleteTexture(decoderTexture)
            GlUtil.destroyEglSurface(display, eglSurface)
            GlUtil.destroyEglContext(display, context)
        }
    }

    private val output = onPlaybackThread { Output() }
    val surface: Surface get() = output.surface

    fun observe(onFrame: (Long, List<Int>) -> Unit, onError: (Throwable) -> Unit) {
        output.texture.setOnFrameAvailableListener({
            try {
                val rgb = output.sample()
                onFrame(output.texture.timestamp, rgb)
            } catch (error: Exception) {
                onError(error)
            }
        }, handler)
    }

    fun close() = onPlaybackThread { output.close() }
}
