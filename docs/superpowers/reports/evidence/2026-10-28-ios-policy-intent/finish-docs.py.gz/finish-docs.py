from pathlib import Path
import json,subprocess,hashlib,collections
b=Path('/private/tmp/yl-policy-intent')
for name in ['analyze.py','policy-proof.py','write-report.py']:subprocess.run(['python3','-B',str(b/name)],check=True)
proof=json.loads((b/'policy-proof.json').read_text());assert len(proof)==4
for name in ['caps','fixed']:
 q=proof[name]['policyProof'];assert all(q[k] for k in ['injected','oldCandidateCancelled','policyPreserved','widthCompliant','noAutomaticInstallation','oneBudgetSpent'])
scope={}
for kind,total in [('device',171),('macos',146)]:
 d=json.loads((b/(kind+'-contracts-summary.json')).read_text());assert d['passedTests']==total and d['failedTests']==d['skippedTests']==0
 r=subprocess.run(['xcrun','xcresulttool','get','test-results','tests','--path',str(b/(kind+'-contracts.xcresult'))],capture_output=True,text=True);assert r.returncode==0;(b/(kind+'-contracts-tests.json')).write_text(r.stdout);cases=[]
 def walk(n):
  if n.get('nodeType')=='Test Case':cases.append(n)
  for c in n.get('children',[]):walk(c)
 for n in json.loads(r.stdout)['testNodes']:walk(n)
 assert len(cases)==total and all(c['result']=='Passed' for c in cases)
 scope[kind]=dict(total=total,classes=dict(collections.Counter(c['nodeIdentifier'].split('/')[0] for c in cases)),results=dict(collections.Counter(c['result'] for c in cases)))
(b/'native-scope.json').write_text(json.dumps(scope,indent=2)+'\n')
for r in json.loads((b/'checks/results.json').read_text()):assert r['exitCode']==0
for name,total in [('network',116),('benchmark',294)]:assert f'Ran {total} tests' in (b/'checks'/f'{name}.log').read_text()
p=Path('docs/superpowers/reports/2026-10-28-ios-policy-intent.md');s=p.read_text().replace('FINAL_TESTS_PENDING','最终iPhone七类171项、macOS六类146项通过，均0失败/0跳过；完整测试树和实际类计数保存。包括DASH loader、Apple session/publication、network byte source、platform services、nonblocking metadata，以及仅iOS现有live reconnect。网络工具116项、benchmark完整发现294项（包含15项台账测试）、镜像/固定历史来源及diff检查通过。无媒体环境的探针不执行真实媒体，四轮媒体另列。未将受影响范围回归冒充完整Dart/Android/全部Apple/独立消费者验收。')
a=proof['auto-control'];o=proof['original-control'];installed=sum(e['outcome']=='installed' for e in a['events']);s=s.replace('MEDIA_INTERPRETATION_PENDING',f"无约束对照实际安装{installed}次，说明新增策略守卫没有把本轮合格自动路径一律禁用。原配置对照发出{len(o['events'])}张票据，完整窗口与原始策略原因保留；不将诊断配置的触发情况外推为原配置稳定恢复通过。caps/fixed两轮的新帧间隔只对应用户策略切换，不与自动恢复空档直接比较。")
p.write_text(s)
p=Path('tool/release_readiness/inventory.json');d=json.loads(p.read_text());key='ios-policy-intent-20261028';report=Path('docs/superpowers/reports/2026-10-28-ios-policy-intent.md');d['evidence'][key]=dict(path=str(report),sha256=hashlib.sha256(report.read_bytes()).hexdigest(),kind='report')
for r in d['rows']:
 if (r['requirement']=='CAP-ABR' and r['platform'] in ['ios','macos']) or (r['requirement']=='CAP-DASH' and r['platform']=='ios'):
  if key not in r['evidence']:r['evidence'].append(key)
  if r['requirement']=='CAP-ABR' and r['platform']=='ios':r['nextAction']='qualify-original-auto-recovery-public-policy-credential-races-shorter-frame-gap-and-physical-output-matrix'
p.write_text(json.dumps(d,indent=2)+'\n')
