from pathlib import Path
import sys
p=Path('tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift');s=p.read_text();mark='private struct AbrDiagnosticRecoveryPolicy {'
helper='''private enum AbrDiagnosticRecoveryEligibility {
  static func permitsPolicy(peakBitRate: Double, maximumResolution: CGSize, fixedTrackId: String?) -> Bool {
    peakBitRate == 0
  }
}

''';assert mark in s;s=s.replace(mark,helper+mark,1)
s=s.replace('item?.preferredPeakBitRate == 0 && item?.isPlaybackLikelyToKeepUp == true,','AbrDiagnosticRecoveryEligibility.permitsPolicy(peakBitRate: item?.preferredPeakBitRate ?? -1,\n            maximumResolution: item?.preferredMaximumResolution ?? CGSize(width: -1, height: -1),\n            fixedTrackId: backend?.videoSelection.fixedTrackId) && item?.isPlaybackLikelyToKeepUp == true,',1)
mark='  func testAutomaticRecoveryExplainsUntriggeredWindows() {'
test='''  func testAutomaticRecoveryCannotReserveUnderDimensionCapsOrFixedSelection() {
    let cases: [(String, Double, CGSize, String?, Int)] = [
      ("automatic", 0, .zero, nil, 1),
      ("bitrate", 500_000, .zero, nil, 0),
      ("width", 0, CGSize(width: 320, height: 100_000), nil, 0),
      ("height", 0, CGSize(width: 100_000, height: 180), nil, 0),
      ("fixed", 0, .zero, "low-track", 0),
    ]
    for (name, peak, resolution, fixed, expectedAttempts) in cases {
      var policy = AbrDiagnosticRecoveryPolicy()
      let allowed = AbrDiagnosticRecoveryEligibility.permitsPolicy(
        peakBitRate: peak, maximumResolution: resolution, fixedTrackId: fixed)
      for time in [0.0, 1, 9, 17, 17.5] {
        _ = policy.observe(.init(time: time, generation: 0, allowed: allowed,
          width: time == 0 ? 640 : 320, position: time + 10, remaining: 110 - time,
          bufferAhead: 10, bytes: Int64(time * 200_000), transfer: time,
          requests: Int(time * 4), overdue: 1))
      }
      XCTAssertEqual(policy.attempts, expectedAttempts, name)
    }
  }

''';assert mark in s;s=s.replace(mark,test+mark,1);p.write_text(s);Path('/private/tmp/yl-policy-intent/native-red.swift').write_text(s)
sys.path.insert(0,'tool/consumer_fixtures/apple_flutter');from media_delivery_fixture_adapter import native_test_source
for platform in ['ios','macos']:Path(f'packages/yl_player/example/{platform}/RunnerTests/{p.name}').write_bytes(native_test_source(p))
p=Path('tool/playback_network/test_abr_accesslog.py');s=p.read_text();mark='    def test_intent_scenarios_require_their_actual_preparation_path(self):';test='''    def test_policy_scenarios_require_preroll_preparation(self):
        for scenario in ['caps-during-preparation', 'fixed-during-preparation']:
            for mode in ['manifest-only', 'asset-metadata', 'asset-preroll']:
                args = SimpleNamespace(recovery_action='auto-reload', duration_seconds=120,
                    direct_hls_control=False, candidate_preparation=mode, auto_scenario=scenario)
                if mode == 'asset-preroll':
                    self.assertEqual(abr_accesslog.candidate_preparation(args), mode)
                else:
                    with self.subTest(scenario=scenario, mode=mode), self.assertRaises(ValueError):
                        abr_accesslog.candidate_preparation(args)

''';assert mark in s;p.write_text(s.replace(mark,test+mark,1))
