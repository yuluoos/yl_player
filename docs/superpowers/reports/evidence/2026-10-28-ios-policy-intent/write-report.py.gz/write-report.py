from pathlib import Path
import json
b=Path('/private/tmp/yl-policy-intent');p=b/'policy-proof.json';d=json.loads(p.read_text()) if p.exists() else {};rows=[];details=[]
for name in ['caps','fixed','auto-control','original-control']:
 if name not in d:continue
 r=d[name];desc='；'.join(f"{e['attempt']}:{e['outcome']} / {e.get('warmupOutcome','无')}" for e in r['events']) or '零票据';gap=' / '.join(f"{g['publicationGapMs']:.3f}ms，清空{g['textureClears']}" for g in r['continuity']['replacementBoundaries']) or '无替换'
 rows.append(f"| {name} | {r['capturePassed']} | {r['end']:.6f} | {desc} | {gap} |")
 if name in ['caps','fixed']:
  q=r['policyProof'];details.append(f"{name}：实际策略提交及item变化={q['injected']}，旧候选取消={q['oldCandidateCancelled']}；后续{q['postRows']}条主采样保持新策略={q['policyPreserved']}，新策略后{q['publishedFramesAfterPolicy']}次新帧提交的宽度集合为{q['publishedWidths']}，均不超过320={q['widthCompliant']}。没有自动恢复安装={q['noAutomaticInstallation']}；只消耗首票且未退回={q['oneBudgetSpent']}。全程最大新帧间隔{r['continuity']['maximumPublishedFrameGapMs']:.3f}ms。")
 else:details.append(name+'窗口bitrate：'+(','.join(f"{w['bitrate']:.0f}({w['reason']})" for w in r['windows']) or '无完整窗')+'。')
text='''# iOS 恢复资格与清晰度策略竞争验证

基线 `024afebc`，本地分支 `codex/abr-recovery`。沿用系统排障、测试驱动和集中验收。承接[准备意图报告](2026-10-28-ios-preparation-intent.md)，[完整证据](evidence/2026-10-28-ios-policy-intent/)保留原始失败、采样、源码身份和完整xcresult。本轮仅修改诊断夹具、镜像及工具，生产自动恢复未接入；不发布。

## 修复和边界

原探针只用preferredPeakBitRate==0判定清晰度策略是否不受限，遗漏preferredMaximumResolution和固定档位。将原判断提取并接回automaticSample后，真机策略回归在受控合格带宽/缓冲输入下确认：width-only、height-only和fixed三种状态都错误预留了1张票据。`policy-red`为1方法失败、3条独立断言失败；完整action保留，摘要只显示首条width错误。它证明诊断资格逻辑有缺口，不代表生产自动恢复曾实际覆盖用户策略。

最小修复要求peak=0、maximumResolution为zero且fixedTrackId=nil。红灯同方法转为通过，无约束控制仍预留1票，三类限制和码率限制均为0票。带宽、窗口、剩余时间、缓冲、预算与退避数值未改。

新增caps-during-preparation和fixed-during-preparation，均仅允许asset-preroll。原生首票候选真正ready后，作废旧票据，通过现有backend.replaceActiveDash提交另一个由同一manifest快照准备的320宽度上限或固定低档资产。事件记录实际调用成功和item变化；主采样记录尺寸上限、固定ID和资格。新活动loader转移所有权后不会被defer discard取消，旧自动候选则取消preroll/seek/asset并清理自己的loader。

这两轮是backend实际媒体路径的策略注入，不是完整public-host命令端到端矩阵。新generation来自用户策略，不能算作自动恢复成功。原事件分类preparationFailed搭配warmupOutcome=cancelled表示旧候选失效取消，不是播放器故障或用户新策略失败。发生策略切换时按原规则清空纹理，未将该行为包装为连续性优化。

Python不匹配场景红灯1方法4子失败保留，修复后accesslog完整定向27通过。镜像声明iOS836/macOS880，不能冒充实际执行数量。

## 真机观测

设备iPhone16（iPhone17,3）/iOS27.2，沿用已授权开发签名。预登记同一构建四轮顺序：caps、fixed、无约束auto-control、原配置original-control。前三轮用独立零延迟诊断配置，最后一轮用原冻结配置。素材120秒、原生140秒、采集240秒。

| 运行 | 采集passed | 片尾位置（秒） | 自动票据/候选结果 | item变化处新帧间隔 |
| --- | --- | --- | --- | --- |
'''+ '\n'.join(rows)+'\n\n'+'\n\n'.join(details)+'''

MEDIA_INTERPRETATION_PENDING

原配置哈希 `4e4f256c59465f4a573d6ab1c48f7a7571294638025088d0cddba9325f5032ea`；诊断配置哈希 `9f63acdf1ab0ce92c5565bc3a750478f0c6c5ba76cef88c7e1092cfcd89b01f1`。保持先高后低、有逾期、至少5秒连续缓冲和20秒剩余、双8秒窗/每窗3请求及955000bit/s、源级两次预算和500/1000ms退避。准备最多2秒且受原票据5秒有效期限制。

采集passed仅表示探针完成。策略实际提交、后续持续选择和新帧宽度另行核对；continuityAccepted、physicalOutputVerified、audioSynchronizationVerified仍为false。新帧证据来自AVPlayer像素缓冲与测试纹理接收器，并非物理屏幕实拍；有限采样不能证明物理屏幕、音画/字幕无中断。

## 集中验收与后续

FINAL_TESTS_PENDING

13组历史证据3222个清单文件逐一校验未变。本轮生产源码身份仍为 `9fd66d341470a59bbc1eca827c85f52e63b81766ce7a0f361477e1abe7db8064`；采集与最终诊断源码身份单列。构建/运行警告原样保留。

REVIEW_PENDING

仍保留：原配置稳定安全自动恢复、缩短替换新帧空档、真实物理路由断开、完整public-host auto/caps/fixed及清除限制/恢复矩阵、凭据与其他意图竞争、物理音画/字幕连续性、多设备/最低系统、DRM/Dolby授权、外接输出及历史iOS33失败/1skip。旧终末停顿按用户指令维持移出后续待办，不恢复跟踪，历史证据不改。

台账仅补本轮证据和后续行动，102行全部状态保持：67 implemented / 34 partial / 1 unreviewed；69 not_run / 30 external_missing / 3 failed / 0 passed，无新增完整acceptance，releaseReady=false。仅本地提交，不合并、不推送、不打标签、不发布。
'''
Path('docs/superpowers/reports/2026-10-28-ios-policy-intent.md').write_text(text)
