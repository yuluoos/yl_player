from pathlib import Path
import json
b=Path('/private/tmp/yl-policy-intent');d=json.loads((b/'analysis.json').read_text());out={}
for name,r in d.items():
 out[name]=dict(capturePassed=r['passed'],end=r.get('end',{}).get('position'),events=r['events'],continuity=r['continuity'],policy=r['policy'],windows=[dict(bitrate=w['windowBitrate'],reason=w['reason']) for w in r.get('windows',[])],finalProxy=r.get('end',{}).get('proxy'))
 if name in ['caps','fixed']:
  events=r['events'];e=events[0] if events else {};t=e.get('policyChangeElapsed');main=[json.loads(x) for x in (b/'media'/name/'rows.jsonl').read_text().splitlines()];frames=[json.loads(x) for x in (b/'media'/name/'frame-samples.jsonl').read_text().splitlines()]
  post=[x for x in main if t is not None and x['elapsed']>t];published=[x for x in frames if t is not None and x['elapsed']>t and x['generation']>0 and x['frames']>0]
  expectedId=e.get('policyFixedTrackId');holds=bool(post) and all(x.get('unconstrainedPolicy') is False and x.get('automaticAttempts')==1 and ((x.get('maximumWidth')==320 and x.get('fixedTrackId') is None) if name=='caps' else (expectedId is not None and x.get('fixedTrackId')==expectedId and x.get('maximumWidth')==0 and x.get('maximumHeight')==0)) for x in post)
  out[name]['policyProof']=dict(injected=e.get('policyChangeApplied') is True and e.get('policyChangedItem') is True,oldCandidateCancelled=e.get('warmupOutcome')=='cancelled' and e.get('warmupDetached') is True,postRows=len(post),policyPreserved=holds,publishedFramesAfterPolicy=sum(x['frames'] for x in published),publishedWidths=sorted(set(x['width'] for x in published)),widthCompliant=bool(published) and all(0<x['width']<=320 for x in published),generationsAfterPolicy=sorted(set(x['generation'] for x in published)),noAutomaticInstallation=all(x['outcome']!='installed' for x in events),oneBudgetSpent=len(events)==1 and main[-1]['automaticAttempts']==1,capabilityAccepted=False)
(b/'policy-proof.json').write_text(json.dumps(out,indent=2)+'\n')
for n,r in out.items():print(n,r['capturePassed'],r['end'],r.get('policyProof'))
