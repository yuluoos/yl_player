from pathlib import Path
import sys
p=Path('tool/consumer_fixtures/apple_flutter/RunnerTests/YlDashResourceLoaderTests.swift');s=p.read_text();s=s.replace('    peakBitRate == 0\n  }\n}\n\nprivate struct AbrDiagnosticRecoveryPolicy','    peakBitRate == 0 && maximumResolution == .zero && fixedTrackId == nil\n  }\n}\n\nprivate struct AbrDiagnosticRecoveryPolicy',1)
s=s.replace('"pause-during-metadata", "seek-during-preparation"]','"pause-during-metadata", "seek-during-preparation", "caps-during-preparation", "fixed-during-preparation"]',1)
s=s.replace('!["pause-during-preparation", "seek-during-preparation"].contains(autoScenario)','!["pause-during-preparation", "seek-during-preparation", "caps-during-preparation", "fixed-during-preparation"].contains(autoScenario)',1)
needle='''          event["manifestPreparedElapsed"] = ProcessInfo.processInfo.systemUptime - started
          var preparationSucceeded = true'''
new='''          event["manifestPreparedElapsed"] = ProcessInfo.processInfo.systemUptime - started
          var policyCandidate: YlPreparedHlsAsset?
          var policyFixedId: String?
          defer { policyCandidate?.discard() } // Transferred loader ownership is not cancelled.
          if ["caps-during-preparation", "fixed-during-preparation"].contains(autoScenario), ticket.attempt == 1 {
            let snapshot = try XCTUnwrap(replacement.loader.dashSnapshot)
            if autoScenario == "fixed-during-preparation" {
              policyFixedId = try XCTUnwrap(replacement.loader.videoCatalog?.tracks(
                at: Int64(CMTimeGetSeconds(player.currentTime()) * 1_000_000)).first { $0.width == 320 }?.id)
            }
            let fixedId = policyFixedId
            let constraints: YlAppleVideoConstraints = autoScenario == "caps-during-preparation"
              ? .init(maxWidth: 320, maxHeight: nil, maxBitrate: nil) : .unconstrained
            let context = replacement.loader.credentialContext
            policyCandidate = try await Task.detached {
              try YlPreparedHlsAsset(originURL: url, isDash: true, videoConstraints: constraints,
                fixedTrackId: fixedId, headers: [:], configuration: .init(map: [:]),
                cancellationToken: .init(), dashSnapshot: snapshot, credentialContext: context)
            }.value
            event["policyCandidatePreparedElapsed"] = ProcessInfo.processInfo.systemUptime - started
          }
          var preparationSucceeded = true'''
assert needle in s;s=s.replace(needle,new,1)
needle='''              onReady: {
                if autoScenario == "seek-during-preparation", ticket.attempt == 1 {'''
new='''              onReady: {
                if ["caps-during-preparation", "fixed-during-preparation"].contains(autoScenario), ticket.attempt == 1 {
                  automaticPolicy.invalidateIntent()
                  do {
                    let target = try XCTUnwrap(backend)
                    try target.replaceActiveDash(source: source, prepared: XCTUnwrap(policyCandidate),
                      selection: .init(fixedTrackId: policyFixedId, reason: "user"))
                    event["policyChangeApplied"] = true
                    event["policyChangeElapsed"] = ProcessInfo.processInfo.systemUptime - started
                    event["policyChangedItem"] = player.currentItem !== item
                    event["policyFixedTrackId"] = target.videoSelection.fixedTrackId as Any? ?? NSNull()
                    event["policyMaximumWidth"] = player.currentItem?.preferredMaximumResolution.width ?? -1
                    event["policyMaximumHeight"] = player.currentItem?.preferredMaximumResolution.height ?? -1
                  } catch { event["policyChangeApplied"] = false }
                }
                if autoScenario == "seek-during-preparation", ticket.attempt == 1 {'''
assert needle in s;s=s.replace(needle,new,1)
needle='''        "height": item.presentationSize.height, "peak": item.preferredPeakBitRate,'''
new='''        "height": item.presentationSize.height, "peak": item.preferredPeakBitRate,
        "maximumWidth": item.preferredMaximumResolution.width,
        "maximumHeight": item.preferredMaximumResolution.height,
        "fixedTrackId": backend?.videoSelection.fixedTrackId as Any? ?? NSNull(),
        "unconstrainedPolicy": AbrDiagnosticRecoveryEligibility.permitsPolicy(
          peakBitRate: item.preferredPeakBitRate, maximumResolution: item.preferredMaximumResolution,
          fixedTrackId: backend?.videoSelection.fixedTrackId),'''
assert needle in s;s=s.replace(needle,new,1)
p.write_text(s);Path('/private/tmp/yl-policy-intent/native-green.swift').write_text(s)
sys.path.insert(0,'tool/consumer_fixtures/apple_flutter');from media_delivery_fixture_adapter import native_test_source
for platform in ['ios','macos']:Path(f'packages/yl_player/example/{platform}/RunnerTests/{p.name}').write_bytes(native_test_source(p))
p=Path('tool/consumer_fixtures/apple_flutter/main_example_tests.py');s=p.read_text().replace("{'ios': 835, 'macos': 879}","{'ios': 836, 'macos': 880}");p.write_text(s)
