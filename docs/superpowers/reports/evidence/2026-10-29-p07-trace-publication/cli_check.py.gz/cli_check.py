from pathlib import Path
import hashlib,json,os,subprocess,stat
root=Path.cwd();out=Path('/private/tmp/yl-p07-publication');old=Path('/private/tmp/yl-p07-wire')
media=old/'retained-synthetic_media.mp4';inspector=old/'patched/target/release/yl-dovi-stream-inspector';decoder=old/'retained-decoder'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
for module,extra,key in [('stream_inventory',['--dm-blocks'],'presentation_trace_sha256'),('decoded_alignment',['--metadata','--decoder',str(decoder)],'trace_sha256')]:
 trace=out/(module+'.jsonl')
 cmd=['python3','-B',str(root/'tool/dolby_reference'/(module+'.py')),'--media',str(media),'--sha256',digest(media),'--inspector',str(inspector),'--trace',str(trace),*extra]
 p=subprocess.run(cmd,capture_output=True,timeout=60)
 (out/(module+'-cli.json')).write_bytes(p.stdout)
 (out/(module+'-cli.stderr')).write_bytes(p.stderr)
 assert p.returncode==0,(p.returncode,p.stdout,p.stderr)
 summary=json.loads(p.stdout);data=trace.read_bytes();rows=[json.loads(v) for v in data.splitlines()]
 assert len(rows)==12 and digest(trace)==summary[key] and stat.S_IMODE(trace.stat().st_mode)==0o600
 before=digest(trace);again=subprocess.run(cmd,capture_output=True,timeout=60)
 (out/(module+'-exists.json')).write_bytes(again.stdout)
 assert again.returncode==2 and digest(trace)==before
 assert summary['mapping_quality']=='external_missing' and summary['native_dv_signal']=='external_missing'
 records.append(dict(command=cmd,exit=p.returncode,repeat_exit=again.returncode,trace_sha256=before,rows=len(rows),mode=oct(stat.S_IMODE(trace.stat().st_mode))))
(out/'cli-checks.json').write_text(json.dumps(dict(inputs={str(p):digest(p) for p in [media,inspector,decoder]},checks=records),indent=2)+'\n')
print('real CM4 CLI: both 12 rows, hashes and 0600 match; repeat refuses existing traces')
