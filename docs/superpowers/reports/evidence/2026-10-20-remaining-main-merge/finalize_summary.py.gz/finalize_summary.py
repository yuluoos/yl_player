from pathlib import Path
import json,sys,subprocess,collections
root=Path('$MAIN');out=Path(__file__).parent
sys.path.insert(0,str(root/'tool/consumer_fixtures/apple_flutter'))
from main_example_tests import case_nodes,expected_identities
full=json.loads((out/'full-run-comparison.json').read_text())
coverage={n['nodeIdentifier']:n['result'] for n in case_nodes(json.loads((out/'macos-results/tests.json').read_text())['testNodes'])}
reruns=[]
for i in [1,2,3]:
 p=out/f'macos-recheck-{i}-results';r=json.loads((p/'case-identities.json').read_text());assert r['summary']['failedTests']==0 and r['summary']['skippedTests']==0
 nodes=list(case_nodes(json.loads((p/'tests.json').read_text())['testNodes']));coverage.update({n['nodeIdentifier']:n['result'] for n in nodes});reruns.append({'run':i,'summary':r['summary'],'observed':r['observed'],'strictIdentityGatePassed':True})
assert set(coverage)==expected_identities(root/'tool/consumer_fixtures/apple_flutter','macos') and set(coverage.values())=={'Passed'}
d={'mergeCommit':'b24282a5d5812237b5c15a7f425a0a4ed264b629','validatedFinalCodeCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'branchHead':'11c7f5c357b5b0b46273949f327a4b0f5dae052d','productionSourceHash':'69f6e5fc191dc55021a1f96b8a2398f8441eee84deeca9ca57521e1819053b60','foundation':json.loads((out/'foundation-summary.json').read_text()),'nativeFullRuns':full,'macosDirectedRechecks':reruns,'macosFinalCoverage':{'counts':dict(collections.Counter(coverage.values())),'canonicalIdentityCoverage':True,'singleFreshFullRunPassed':False,'basis':'Fresh merged-main full suite plus recompiled affected helper and replay neighbors; only test waits changed. All original full-run failures retained.'},'iosFinalCoverage':{'counts':full['ios']['counts'],'canonicalIdentityCoverage':True,'newFailures':[],'strictGatePassed':False},'readiness':json.loads((out/'readiness-commands.json').read_text()),'retention':json.loads((out/'final-preservation.json').read_text()),'review':{'critical':0,'important':0,'minor':0,'scopedImportantFixed':1},'scope':'Authorized local merge and unified validation; not release acceptance. No push or branch/worktree cleanup.'}
(out/'validation.json').write_text(json.dumps(d,indent=2)+'\n')
(out/'macos-final-coverage.json').write_text(json.dumps({'observed':coverage,'basis':d['macosFinalCoverage']},indent=2)+'\n')
(out/'foundation-command.json').write_text(json.dumps({'command':['sh','tool/check_foundation.sh'],'cwd':str(root),'environment':{'PATH_prefix':['$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin','$HOME/flutter/bin'],'YL_RUN_DECODE_PROBE':'1'},'exitCode':0,'revision':d['mergeCommit'],'reuseForFinal':'Only macOS lifecycle test waits changed; Dart/Python/interfaces/dependencies/production unchanged. Updated native test paths were recompiled and rerun.'},indent=2)+'\n')
print('validated final code',d['validatedFinalCodeCommit'],'macOS coverage',d['macosFinalCoverage']['counts'],'iOS',d['iosFinalCoverage']['counts'])
