import subprocess,json,time,sys
from pathlib import Path
root=Path('$MAIN');out=Path(__file__).parent;records=[]
def run(name,cmd):
 print(name,flush=True);start=time.time()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(name=name,command=cmd,exitCode=p.returncode,startedAt=start,durationSeconds=time.time()-start));(out/'macos-recheck-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,'exit',p.returncode,flush=True);return p.returncode
build=out/'build-macos';dest='platform=macOS,arch=arm64'
if run('macos-recheck-build',['xcodebuild','build-for-testing','-quiet','-workspace','packages/yl_player/example/macos/Runner.xcworkspace','-scheme','Runner','-configuration','Debug','-derivedDataPath',str(build),'-destination',dest,'ARCHS=arm64','ONLY_ACTIVE_ARCH=YES','CODE_SIGNING_ALLOWED=NO','ENABLE_TESTABILITY=YES']):sys.exit(1)
spec=next((build/'Build/Products').glob('*.xctestrun'))
# Both paths of the changed helper, plus real replay/lifecycle neighbors.
methods=['testActualDecodedLegacyEOFSuspendResumeDoesNotAutoplay','testActualDecodedCandidateEOFSuspendResumeDoesNotAutoplay','testActualDecodedLegacyEOFSeekReplayWithoutManualStop','testActualDecodedCandidateEOFSeekReplayWithoutManualStop','testActualDecodedLegacyEOFStopSeekReplay','testActualDecodedCandidateEOFStopSeekReplay']
# One grouped run, then repeat only the two changed branches twice using separate bundles.
for i,selected in enumerate([methods,methods[:2],methods[:2]],1):
 name=f'macos-recheck-{i}';result=out/(name+'.xcresult')
 run(name,['xcodebuild','test-without-building','-quiet','-xctestrun',str(spec),'-destination',dest,'-parallel-testing-enabled','NO','-collect-test-diagnostics','never','-resultBundlePath',str(result),*[f'-only-testing:RunnerTests/YlMacosAudioTests/{m}' for m in selected]])
 run(name+'-identity',[sys.executable,'-B','tool/consumer_fixtures/apple_flutter/main_example_tests.py','--result-bundle',str(result),'--platform','macos','--output',str(out/(name+'-results')),*[v for m in selected for v in ['--selected-case',f'YlMacosAudioTests/{m}()']]])
