import subprocess,json
from pathlib import Path
p=Path(__file__).parent
commands=[]
def run(cmd,target=None):
 r=subprocess.run(cmd,capture_output=True);commands.append({'command':cmd,'exitCode':r.returncode,'stderr':r.stderr.decode(errors='replace')})
 if target: target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(r.stdout)
 return r
comparison=json.loads((p/'full-run-comparison.json').read_text())
for platform in ['macos','ios']:
 result=p/(platform+'.xcresult')
 for identity in comparison[platform]['failures']:
  safe=identity.replace('/','__').replace('()','')
  run(['xcrun','xcresulttool','get','test-results','test-details','--path',str(result),'--test-id',identity],p/(platform+'-failure-details')/(safe+'.json'))
 if platform=='macos':
  identity=comparison[platform]['failures'][0]
  run(['xcrun','xcresulttool','get','test-results','activities','--path',str(result),'--test-id',identity],p/'macos-failure-activities.json')
  selected=[identity,'YlMacosAudioTests/testActualDecodedEOFResourceObservation()','YlMacosAudioTests/testActualDecodedRepeatedLifecycleResources()']
 else:selected=['YlManagedFallbackCharacterizationTests/testBoundedFLVRealManagedFixtureMustProgressAndReleasePayload()']
 for i,identity in enumerate(selected):
  run(['xcrun','xcresulttool','export','attachments','--path',str(result),'--test-id',identity,'--output-path',str(p/(platform+'-attachments')/str(i))])
 if platform=='ios':run(['xcrun','xcresulttool','export','diagnostics','--path',str(result),'--output-path',str(p/'ios-diagnostics')])
(p/'export-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print('exports',len(commands),'failed',sum(x['exitCode']!=0 for x in commands))
