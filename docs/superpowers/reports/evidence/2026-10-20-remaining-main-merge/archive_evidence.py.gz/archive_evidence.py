from pathlib import Path
import json,gzip,hashlib,re
root=Path('$MAIN');src=Path(__file__).parent
out=root/'docs/superpowers/reports/evidence/2026-10-20-remaining-main-merge';out.mkdir(parents=True,exist_ok=True)
manifest=[]
def anonymous(s):
 s=s.replace(str(root),'$MAIN').replace('$HOME','$HOME')
 s=re.sub(r'(?i)\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b',lambda m:'LOCAL-'+hashlib.sha256(m.group(0).lower().encode()).hexdigest()[:16],s)
 s=re.sub(r'("token"\s*:\s*")[^"]+(")',r'\1<RUN-TOKEN>\2',s)
 return s
def save(p,name,compress=True):
 raw=p.read_bytes();data=anonymous(raw.decode()).encode();name=anonymous(name)+('.gz' if compress else '');dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True)
 assert name not in {m['path'] for m in manifest},name
 if compress:
  with dest.open('wb') as f,gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as z:z.write(data)
 else:dest.write_bytes(data)
 manifest.append(dict(path=name,originalSha256=hashlib.sha256(raw).hexdigest(),contentSha256=hashlib.sha256(data).hexdigest(),archivedSha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
for p in sorted(src.iterdir()):
 if p.is_file() and p.suffix in ('.json','.log','.stderr','.exit','.py','.md','.patch') and p.stat().st_size:
  save(p,p.name,compress=p.suffix not in ('.json','.md'))
for folder in sorted(src.iterdir()):
 if not folder.is_dir() or folder.name.startswith('build-') or folder.suffix=='.xcresult':continue
 for p in sorted(folder.rglob('*')):
  if p.is_file() and p.suffix in ('.json','.txt','.log'):save(p,p.relative_to(src).as_posix())
(out/'verification-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Archived',len(manifest),'records')
