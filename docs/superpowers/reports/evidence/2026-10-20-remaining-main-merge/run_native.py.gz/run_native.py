import subprocess,json,time,sys,os
from pathlib import Path
root=Path('$MAIN')
out=Path(__file__).parent
records=[]
def run(name,cmd):
 print(name,flush=True)
 start=time.time()
 with (out/(name+'.log')).open('w') as log:
  p=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(name=name,command=cmd,exitCode=p.returncode,startedAt=start,durationSeconds=time.time()-start))
 (out/'native-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,'exit',p.returncode,flush=True)
 return p.returncode
for platform,dest in [('macos','platform=macOS,arch=arm64'),('ios','platform=iOS Simulator,id=LOCAL-45e96df4297dafb9')]:
 derived=out/('build-'+platform)
 cmd=['xcodebuild','build-for-testing','-quiet','-workspace',f'packages/yl_player/example/{platform}/Runner.xcworkspace','-scheme','Runner','-configuration','Debug','-derivedDataPath',str(derived),'-destination',dest,'ARCHS=arm64','ONLY_ACTIVE_ARCH=YES','CODE_SIGNING_ALLOWED=NO','ENABLE_TESTABILITY=YES']
 if platform=='ios': cmd+=['-sdk','iphonesimulator']
 if run(platform+'-build',cmd): continue
 specs=list((derived/'Build/Products').glob('*.xctestrun'))
 if len(specs)!=1: raise RuntimeError(str(specs))
 result=out/(platform+'.xcresult')
 run(platform+'-test',['xcodebuild','test-without-building','-quiet','-xctestrun',str(specs[0]),'-destination',dest,'-parallel-testing-enabled','NO','-collect-test-diagnostics','never','-resultBundlePath',str(result)])
 run(platform+'-identity',[sys.executable,'-B','tool/consumer_fixtures/apple_flutter/main_example_tests.py','--result-bundle',str(result),'--platform',platform,'--output',str(out/(platform+'-results'))])
