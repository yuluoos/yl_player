from pathlib import Path
import subprocess,json
out=Path('/private/tmp/yl-device-followup');products=Path('/private/tmp/yl-continuity-device-build/Build/Products')
manifest=list(products.glob('*.xctestrun'));assert len(manifest)==1
cmd=['xcodebuild','test-without-building','-quiet','-xctestrun',str(manifest[0]),'-destination','platform=iOS,id=00008140-000C49CC3493001C','-parallel-testing-enabled','NO','-resultBundlePath',str(out/'device-contracts.xcresult'),'-only-testing:RunnerTests/YlDashResourceLoaderTests','-only-testing:RunnerTests/YlAppleSessionTests','-only-testing:RunnerTests/YlApplePublicationTests']
(out/'device-contracts-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'device-contracts.log').open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
(out/'device-contracts-result.json').write_text(json.dumps(dict(exitCode=p.returncode))+'\n')
r=subprocess.run(['xcrun','xcresulttool','get','test-results','summary','--path',str(out/'device-contracts.xcresult')],capture_output=True,text=True);(out/'device-contracts-summary.json').write_text(r.stdout);print(p.returncode)
