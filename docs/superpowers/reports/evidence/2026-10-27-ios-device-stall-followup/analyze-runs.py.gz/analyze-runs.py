from pathlib import Path
import json,sys
sys.path.insert(0,str(Path.cwd()/'tool/playback_network'))
from abr_accesslog import summarize_frames,summarize_policy
root=Path('/private/tmp/yl-device-followup/runs');results=[]
for entry in json.loads((root/'results.json').read_text()):
 name=entry['name'];p=root/name;receipt=json.loads((p/'receipt.json').read_text());rows=[json.loads(x) for x in (p/'rows.jsonl').read_text().splitlines()] if (p/'rows.jsonl').exists() else [];frames=[json.loads(x) for x in (p/'frame-samples.jsonl').read_text().splitlines()] if (p/'frame-samples.jsonl').exists() else [];trace=[json.loads(x) for x in (p/'policy-decisions.jsonl').read_text().splitlines()] if (p/'policy-decisions.jsonl').exists() else []
 pub=[r for r in frames if r['frames']];transitions=[];width=None
 for r in pub:
  if r['width']!=width:transitions.append({k:r[k] for k in ['elapsed','width','generation','position']});width=r['width']
 signals=[]
 action=root/(name+'-action.json')
 def walk(v):
  if isinstance(v,str):
   signals.extend(line for line in v.splitlines() if '[YL-ABR]' in line or '[YLPlayer][AVPlayer]' in line or 'YlPlayer upstream ' in line)
  elif isinstance(v,dict):
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 if action.exists():walk(json.loads(action.read_text()))
 signals=list(dict.fromkeys(signals));(root/(name+'-signals.log')).write_text('\n'.join(signals)+'\n')
 request=[json.loads(x) for x in (p/'requests.jsonl').read_text().splitlines()]
 result=dict(name=name,passed=receipt['passed'],errors=receipt['errors'],profile=entry['command'][entry['command'].index('--profile')+1],profileSha256=receipt.get('profileSha256'),position=rows[-1]['position'] if rows else None,backendStatus=rows[-1].get('backendStatus') if rows else None,backendFailure=rows[-1].get('backendFailureCode') if rows else None,attempts=rows[-1].get('automaticAttempts') if rows else None,events=rows[-1].get('automaticEvents') if rows else None,transitions=transitions,signals=signals,requestCount=len(request),latestServerResponseMs=max((r['endMs'] for r in request),default=None),ownedProcessExited=receipt['ownedProcessExited'],binaryIdentityUnchanged=receipt['binaryIdentityUnchanged'],capabilityAccepted=False)
 if frames and rows:result['continuity']=summarize_frames(frames,expected_frames=rows[-1]['framesPublished'])
 if trace and rows:result['policy']=summarize_policy(trace,expected_attempts=rows[-1]['automaticAttempts'])
 results.append(result)
(root/'analysis.json').write_text(json.dumps(results,indent=2)+'\n')
for r in results:print(r['name'],'passed',r['passed'],'pos',r['position'],'events',r['events'],'policy',r.get('policy',{}).get('reasonCounts'),'signals',len(r['signals']))
