from pathlib import Path
import subprocess,json,time,hashlib
root=Path.cwd();out=Path('/private/tmp/yl-device-followup/runs');plan=json.loads(Path('/private/tmp/yl-device-followup/headroom-plan.json').read_text())
results=json.loads((out/'results.json').read_text());assert len(results)==4
for name,digest in json.loads((out/'source-identity.json').read_text()).items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
for name,action,scenario in plan['runs']:
 cmd=['python3','-B','tool/playback_network/abr_accesslog.py','--products','/private/tmp/yl-continuity-device-build/Build/Products','--directory',str(out/name),'--physical-device','00008140-000C49CC3493001C','--owned-host','192.168.50.196','--duration-seconds','120','--profiles','/private/tmp/yl-device-followup/headroom-profiles.json','--profile','stall-headroom-diagnostic-v1','--recovery-action',action,'--auto-scenario',scenario]
 print('START',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=360)
 results.append(dict(name=name,command=cmd,exitCode=p.returncode,seconds=time.monotonic()-start));(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,p.returncode,flush=True)
 for kind,command in [('tests',['get','test-results','summary']),('action',['get','log','--type','action'])]:
  x=subprocess.run(['xcrun','xcresulttool',*command,'--path',str(out/(name+'.xcresult'))],capture_output=True,text=True,timeout=45)
  (out/(name+'-'+kind+'.json')).write_text(x.stdout);(out/(name+'-'+kind+'-exit.json')).write_text(json.dumps(dict(exitCode=x.returncode,stderr=x.stderr))+'\n')
