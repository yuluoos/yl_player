from pathlib import Path
import subprocess,json,time,signal,sys
root=Path('/Users/yy2021_8689/.codex/worktrees/p04-weak-network-live/yl_player');logs=root/'.superpowers/sdd/2026-09-26-remaining-04-abr-live/logs'
mode=sys.argv[1]; run=sys.argv[2];device=sys.argv[3] if len(sys.argv)>3 else 'macos';out=logs/run;out.mkdir()
p=subprocess.run([sys.executable,'-B',str(root/'tool/playback_network/prepare_fixture.py'),'--output',str(out/'media')],capture_output=True,text=True,check=True);(out/'fixture.json').write_text(p.stdout)
# Extend only this experiment to 80s. Preserve the original owned bytes and
# alternating 4s Periods; do not change the network profile or quality ladders.
import copy,hashlib,shutil,xml.etree.ElementTree as ET,re
fixture=json.loads(p.stdout);ns='urn:mpeg:dash:schema:mpd:2011'
manifest=out/'media/manifest.mpd';tree=ET.fromstring(manifest.read_bytes())
periods=tree.findall('{'+ns+'}Period');assert len(periods)==10
for index in range(10,20):
 period=copy.deepcopy(periods[index%2]);period.set('id',f'network-period-{index}');period.set('start',f'PT{index*4}S')
 period.find('{'+ns+'}BaseURL').text=f'network-period-{index}/';tree.append(period)
 shutil.copytree(out/f'media/network-period-{index%2}',out/f'media/network-period-{index}')
tree.set('mediaPresentationDuration','PT80S');ET.register_namespace('',ns);ET.indent(tree,space='  ')
manifest.write_bytes(ET.tostring(tree,encoding='utf-8',xml_declaration=True))
assets=sorted(x for x in (out/'media').rglob('*') if x.is_file() and x.name!='SHA256SUMS')
(out/'media/SHA256SUMS').write_text(''.join(f'{hashlib.sha256(x.read_bytes()).hexdigest()}  ./{x.relative_to(out/"media")}\n' for x in assets))
fixture.update(durationSeconds=80,periodCount=20,assetCount=len(assets),base40sManifestSha256=fixture['manifestSha256'],manifestSha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),inventorySha256=hashlib.sha256((out/'media/SHA256SUMS').read_bytes()).hexdigest())
(out/'fixture.json').write_text(json.dumps(fixture,indent=2)+'\n')
media=fixture['manifestSha256']
with (out/'server.jsonl').open('w') as f:
 server=subprocess.Popen([sys.executable,'-u','-B',str(root/'tool/playback_network/network_profile.py'),'--root',str(out/'media'),'--profile','down-and-recover-v1','--start-on-first-get','--run-id',run,'--log',str(out/'requests.jsonl')],stdout=f,stderr=subprocess.STDOUT)
 try:
  for _ in range(100):
   rows=(out/'server.jsonl').read_text().splitlines()
   if rows:break
   assert server.poll() is None;time.sleep(.1)
  row=json.loads(rows[0])
  if device.startswith('emulator-'):
   subprocess.run(['/opt/homebrew/share/android-commandlinetools/platform-tools/adb','-s',device,'reverse','tcp:18779','tcp:18779'],check=True)
  args=['/Users/yy2021_8689/flutter/bin/flutter','test','--no-pub','integration_test/abr_network_profile_test.dart','-d',device,'--reporter','expanded']
  for k,v in dict(YL_ABR_RUN=run,YL_ABR_MODE=mode,YL_ABR_URL=row['url'],YL_ABR_PROFILE='down-and-recover-v1',YL_ABR_PROFILE_SHA256=row['profileSha256'],YL_ABR_MEDIA_SHA256=media).items():args.append(f'--dart-define={k}={v}')
  (out/'command.json').write_text(json.dumps(args))
  with (out/'capture.log').open('w') as output:r=subprocess.run(args,cwd=root/'packages/yl_player/example',stdout=output,stderr=subprocess.STDOUT,timeout=500)
  (out/'exit-code').write_text(str(r.returncode))
 finally:
  server.send_signal(signal.SIGINT);server.wait(timeout=10)
r=subprocess.run([sys.executable,'-B',str(root/'tool/playback_network/summarize_capture.py'),'--capture',str(out/'capture.log'),'--requests',str(out/'requests.jsonl'),'--server-stdout',str(out/'server.jsonl'),'--exit-code',(out/'exit-code').read_text(),'--output',str(out/'summary.json')])
print(run,'summary exit',r.returncode,flush=True)
if (out/'summary.json').exists():print((out/'summary.json').read_text(),flush=True)

samples=[]
for line in (out/'capture.log').read_text().splitlines():
 match=re.search(r'YL_ABR_SAMPLE=(\{.*\})',line)
 if match:samples.append(json.loads(match[1]))
last=max((x.get('positionUs',0) for x in samples),default=0)
validation={'expectedDurationUs':80000000,'maximumObservedPositionUs':last,'fullProgrammeObserved':last>=79500000,'profileUnchanged':True,'comparedTo40SecondRuns':False}
(out/'extended-program-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
assert validation['fullProgrammeObserved'],validation
