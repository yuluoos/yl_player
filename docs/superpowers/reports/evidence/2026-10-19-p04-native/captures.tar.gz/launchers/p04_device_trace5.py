from pathlib import Path
import asyncio,sys,json,hashlib,subprocess
root=Path('/Users/yy2021_8689/.codex/worktrees/p04-weak-network-live/yl_player')
sys.path.insert(0,str(root/'tool/playback_network'))
from live_fixture import LiveFixture,SOURCE,SOURCE_SHA256
from network_profile import load_profiles
HOST='192.168.50.196'; DEVICE='00008140-000C49CC3493001C'
logs=root/'.superpowers/sdd/2026-09-26-remaining-04-abr-live/logs'
class Relay:
 def __init__(self):self.tasks=set();self.writers=set();self.servers=[]
 async def start(self,port):
  async def accept(reader,writer):
   task=asyncio.current_task();self.tasks.add(task);self.writers.add(writer)
   try:
    if len(self.tasks)>8:return
    upstream,out=await asyncio.wait_for(asyncio.open_connection('127.0.0.1',port),5);self.writers.add(out)
    async def copy(r,w):
     while data:=await r.read(8192):w.write(data);await asyncio.wait_for(w.drain(),5)
    pipes=[asyncio.create_task(copy(reader,out)),asyncio.create_task(copy(upstream,writer))]
    try:await asyncio.wait(pipes,return_when=asyncio.FIRST_COMPLETED)
    finally:
     for p in pipes:p.cancel()
     await asyncio.gather(*pipes,return_exceptions=True)
     out.close();await out.wait_closed();self.writers.discard(out)
   except (OSError,asyncio.TimeoutError):pass
   finally:
    writer.close();self.writers.discard(writer);self.tasks.discard(task)
  self.servers.append(await asyncio.start_server(accept,HOST,port,limit=65536))
 async def close(self):
  for s in self.servers:s.close();await s.wait_closed()
  for w in list(self.writers):w.close()
  for t in list(self.tasks):t.cancel()
  await asyncio.gather(*list(self.tasks),return_exceptions=True)
  self.writers.clear()
async def capture(protocol,run,ports,url,extra=None):
 out=logs/run;out.mkdir();relay=Relay()
 try:
  for port in ports:await relay.start(port)
  args=['/Users/yy2021_8689/flutter/bin/flutter','test','--no-pub','--no-uninstall','integration_test/live_mode_switch_test.dart','-d',DEVICE,'--reporter','expanded']
  for k,v in dict(YL_LIVE_RUN=run,YL_LIVE_PROTOCOL=protocol,YL_LIVE_URL=url,YL_LIVE_OWNED_HOST=HOST,YL_LIVE_MEDIA_SHA256=SOURCE_SHA256,YL_LIVE_OWNED='true').items():args.append(f'--dart-define={k}={v}')
  if extra:args=extra
  (out/'command.json').write_text(json.dumps(args));paths=subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
  (out/'source-identity.json').write_text(json.dumps({p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths if Path(p).suffix in {'.dart','.swift','.kt','.py'} and (root/p).is_file()}))
  with (out/'capture.log').open('w') as f:
   child=await asyncio.create_subprocess_exec(*args,cwd=root/'packages/yl_player/example',stdout=f,stderr=asyncio.subprocess.STDOUT)
   try:code=await asyncio.wait_for(child.wait(),450)
   except asyncio.TimeoutError:
    child.terminate()
    try:await asyncio.wait_for(child.wait(),10)
    except asyncio.TimeoutError:child.kill();await child.wait()
    code=124
  (out/'exit-code').write_text(str(code));print(run,code,flush=True)
 finally:
  await relay.close();(out/'relay-cleanup.json').write_text(json.dumps({'host':HOST,'ports':ports,'pending':len(relay.tasks),'writers':len(relay.writers)}))
 return code
async def main():
 for protocol in sys.argv[1:]:
  run='p04-iphone-'+protocol+'-trace-5'
  if protocol!='rtmp':
   server=logs/(run+'-source')
   with LiveFixture(protocol,SOURCE,server,run,'/opt/homebrew/bin/ffmpeg',profile=load_profiles(root/'tool/playback_network/profiles.json')['stall-and-recover-v1']) as f:
    await capture(protocol,run,[f.port],f'http://{HOST}:{f.port}/live.'+('flv' if protocol=='flv' else 'm3u8'))
  else:
   await capture(protocol,run,[19351,19352],f'rtmp://{HOST}:19351/live/owned')

asyncio.run(main())
