import http.server, subprocess, threading, tempfile, pathlib, time, json, hashlib, signal, sys
root=pathlib.Path('/Users/yy2021_8689/.codex/worktrees/p04-weak-network-live/yl_player')
protocol=sys.argv[1]; out=root/'.superpowers/sdd/2026-09-26-remaining-04-abr-live/logs'/sys.argv[2]; out.mkdir()
fixture=root/'tool/consumer_fixtures/apple_flutter/Resources/h264_aac.flv'
sha=hashlib.sha256(fixture.read_bytes()).hexdigest(); assert sha=='cfe009b1b03b6cacf4ae9f037eed4441a32b99508d4fabccb429bea439cf570b'
children=[]; handles=[]; records=[]; lock=threading.Lock()
def spawn(extra,name):
 log=(out/name).open('wb');handles.append(log)
 p=subprocess.Popen(['/opt/homebrew/bin/ffmpeg','-nostdin','-hide_banner','-loglevel','error','-re','-stream_loop','-1','-i',str(fixture),'-c','copy',*extra],stdout=subprocess.PIPE if protocol=='flv' else log,stderr=log,start_new_session=True);children.append(p);return p
class Handler(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):
  if protocol=='flv' and self.path=='/live.flv':
   with lock:
    n=len(records);records.append({'id':n,'bytes':0,'started':time.monotonic()})
   if n>=32: self.send_error(503);return
   p=spawn(['-f','flv','pipe:1'],f'publisher-{n}.log')
   self.send_response(200);self.send_header('Content-Type','video/x-flv');self.send_header('Cache-Control','no-store');self.end_headers()
   try:
    while p.poll() is None:
     b=p.stdout.read1(16384)
     if not b:break
     self.wfile.write(b);self.wfile.flush();records[n]['bytes']+=len(b)
   except (BrokenPipeError,ConnectionResetError):pass
   finally:
    if p.poll() is None:p.terminate()
    try:p.wait(timeout=3)
    except subprocess.TimeoutExpired:p.kill();p.wait()
    records[n]['ended']=time.monotonic()
  elif protocol=='hls' and (self.path=='/live.m3u8' or self.path.startswith('/segment') and self.path.endswith('.ts') and self.path[8:-3].isdigit()):
   try:b=(out/self.path[1:]).read_bytes()
   except OSError:self.send_error(404);return
   self.send_response(200);self.send_header('Content-Length',str(len(b)));self.send_header('Cache-Control','no-store');self.send_header('Content-Type','application/vnd.apple.mpegurl' if self.path.endswith('m3u8') else 'video/mp2t');self.end_headers()
   try:self.wfile.write(b)
   except (BrokenPipeError,ConnectionResetError):pass
  else:self.send_error(404)
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
try:
 if protocol=='hls':
  p=spawn(['-f','hls','-hls_time','1','-hls_list_size','6','-hls_delete_threshold','10','-hls_flags','delete_segments+temp_file','-hls_segment_filename',str(out/'segment%d.ts'),str(out/'live.m3u8')],'publisher.log')
  for _ in range(150):
   if (out/'live.m3u8').exists():break
   assert p.poll() is None;time.sleep(.1)
 threading.Thread(target=server.serve_forever,daemon=True).start()
 url=f'http://127.0.0.1:{server.server_port}/live.'+('flv' if protocol=='flv' else 'm3u8')
 args=['/Users/yy2021_8689/flutter/bin/flutter','test','--no-pub','integration_test/live_mode_switch_test.dart','-d','macos','--reporter','expanded',f'--dart-define=YL_LIVE_RUN={sys.argv[2]}',f'--dart-define=YL_LIVE_PROTOCOL={protocol}',f'--dart-define=YL_LIVE_URL={url}',f'--dart-define=YL_LIVE_MEDIA_SHA256={sha}','--dart-define=YL_LIVE_OWNED=true']
 with (out/'capture.log').open('w') as f:r=subprocess.run(args,cwd=root/'packages/yl_player/example',stdout=f,stderr=subprocess.STDOUT,timeout=300)
 (out/'exit-code').write_text(str(r.returncode));print('exit',r.returncode,flush=True)
finally:
 server.shutdown();server.server_close()
 for p in children:
  if p.poll() is None:p.terminate()
 for p in children:
  try:p.wait(timeout=3)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 for h in handles:h.close()
 (out/'receipt.json').write_text(json.dumps({'protocol':protocol,'mediaHash':sha,'requests':records,'childrenExited':all(p.poll() is not None for p in children)},indent=2))
