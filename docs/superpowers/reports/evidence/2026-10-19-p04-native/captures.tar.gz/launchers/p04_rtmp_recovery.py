from pathlib import Path
import subprocess, json, hashlib
root=Path('/Users/yy2021_8689/.codex/worktrees/p04-weak-network-live/yl_player')
logs=root/'.superpowers/sdd/2026-09-26-remaining-04-abr-live/logs'
flutter='/Users/yy2021_8689/flutter/bin/flutter'
adb='/opt/homebrew/share/android-commandlinetools/platform-tools/adb'
results=[]
for device in ['macos','emulator-5554']:
 platform='macos' if device=='macos' else 'android'
 if platform=='android':
  for port in [19351,19352]: subprocess.run([adb,'-s',device,'reverse',f'tcp:{port}',f'tcp:{port}'],check=True)
 try:
  for name,test,extra in [
   ('expanded','integration_test/live_mode_switch_test.dart',['--dart-define=YL_LIVE_PROTOCOL=rtmp','--dart-define=YL_LIVE_URL=rtmp://127.0.0.1:19351/live/owned','--dart-define=YL_LIVE_MEDIA_SHA256=cfe009b1b03b6cacf4ae9f037eed4441a32b99508d4fabccb429bea439cf570b','--dart-define=YL_LIVE_OWNED=true']),
   ('low-recovery','integration_test/rtmp_playback_test.dart',['--plain-name','RTMP three lifetime recoveries fresh output fourth drop terminal and stop fences backoff','--dart-define=YL_RTMP_LOW_LATENCY=true'])]:
   
   if name == 'expanded': continue
   run=f'p04-{platform}-rtmp-{name}-2';out=logs/run;out.mkdir()
   args=[flutter,'test','--no-pub',test,'-d',device,'--reporter','expanded',*extra,f'--dart-define=YL_LIVE_RUN={run}']
   (out/'command.json').write_text(json.dumps(args))
   paths=subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
   (out/'source-identity.json').write_text(json.dumps({p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths if Path(p).suffix in {'.dart','.swift','.kt','.py'} and (root/p).is_file()}))
   with (out/'capture.log').open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=350)
   (out/'exit-code').write_text(str(r.returncode));results.append([run,r.returncode]);print(run,r.returncode,flush=True)
 finally:
  if platform=='android':
   for port in [19351,19352]:subprocess.run([adb,'-s',device,'reverse','--remove',f'tcp:{port}'])
print(json.dumps(results),flush=True)
raise SystemExit(1 if any(code for _,code in results) else 0)
