from pathlib import Path
import subprocess,sys,json
root=Path('/Users/yy2021_8689/.codex/worktrees/p04-weak-network-live/yl_player')
sys.path.insert(0,str(root/'tool/playback_network'))
from live_fixture import LiveFixture,SOURCE,SOURCE_SHA256
from network_profile import load_profiles
protocol,run,device=sys.argv[1:4]; profile=load_profiles(root/'tool/playback_network/profiles.json').get(sys.argv[4] if len(sys.argv)>4 else '')
out=root/'.superpowers/sdd/2026-09-26-remaining-04-abr-live/logs'/run;out.mkdir()
with LiveFixture(protocol,SOURCE,out/'server',run,'/opt/homebrew/bin/ffmpeg',profile=profile) as fixture:
 if device.startswith('emulator-'):
  subprocess.run(['/opt/homebrew/share/android-commandlinetools/platform-tools/adb','-s',device,'reverse',f'tcp:{fixture.port}',f'tcp:{fixture.port}'],check=True)
 args=['/Users/yy2021_8689/flutter/bin/flutter','test','--no-pub','integration_test/live_mode_switch_test.dart','-d',device,'--reporter','expanded']
 for k,v in dict(YL_LIVE_RUN=run,YL_LIVE_PROTOCOL=protocol,YL_LIVE_URL=f'http://127.0.0.1:{fixture.port}/live.'+('flv' if protocol=='flv' else 'm3u8'),YL_LIVE_MEDIA_SHA256=SOURCE_SHA256,YL_LIVE_OWNED='true').items():args.append(f'--dart-define={k}={v}')
 if len(device)==36: args += ['--verbose','--dart-define=YL_TRACE_LIVE_BARRIER=true']
 (out/'command.json').write_text(json.dumps(args))
 import hashlib,platform
 paths=subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
 source={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths if Path(p).suffix in {'.dart','.swift','.kt','.py'} and (root/p).is_file()}
 (out/'source-identity.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sources':source,'host':platform.platform()},indent=2))
 try:
  with (out/'capture.log').open('w') as f:r=subprocess.run(args,cwd=root/'packages/yl_player/example',stdout=f,stderr=subprocess.STDOUT,timeout=450)
  (out/'exit-code').write_text(str(r.returncode));print(run,r.returncode,flush=True)
 finally:
  if device.startswith('emulator-'):
   subprocess.run(['/opt/homebrew/share/android-commandlinetools/platform-tools/adb','-s',device,'reverse','--remove',f'tcp:{fixture.port}'])
