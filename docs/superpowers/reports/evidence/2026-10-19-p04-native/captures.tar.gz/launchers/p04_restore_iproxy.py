from pathlib import Path
import json,shutil,hashlib
m=json.loads(Path('/private/tmp/p04-iproxy-backup.json').read_text());p=Path(m['path']);b=Path(m['backup'])
assert hashlib.sha256(b.read_bytes()).hexdigest()==m['sha256']
assert p.read_text()=='#!/bin/sh\nunset DYLD_LIBRARY_PATH DYLD_FALLBACK_LIBRARY_PATH\nexec /opt/homebrew/bin/iproxy "$@"\n'
shutil.copy2(b,p)
assert hashlib.sha256(p.read_bytes()).hexdigest()==m['sha256']
Path('/private/tmp/p04-iproxy-restored.json').write_text(json.dumps({'restored':True,'sha256':m['sha256'],'path':m['path']}))
print('Original Flutter iproxy restored and hash verified')
