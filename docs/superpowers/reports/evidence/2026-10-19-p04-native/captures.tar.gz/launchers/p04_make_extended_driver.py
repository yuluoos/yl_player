from pathlib import Path
p=Path('/private/tmp/p04_abr_run.py');s=p.read_text();needle="media=json.loads(p.stdout)['manifestSha256']"
extra='''# Extend only this experiment to 80s. Preserve the original owned bytes and
# alternating 4s Periods; do not change the network profile or quality ladders.
import copy,hashlib,shutil,xml.etree.ElementTree as ET,re
fixture=json.loads(p.stdout);ns='urn:mpeg:dash:schema:mpd:2011'
manifest=out/'media/manifest.mpd';tree=ET.fromstring(manifest.read_bytes())
periods=tree.findall('{'+ns+'}Period');assert len(periods)==10
for index in range(10,20):
 period=copy.deepcopy(periods[index%2]);period.set('id',f'network-period-{index}');period.set('start',f'PT{index*4}S')
 period.find('{'+ns+'}BaseURL').text=f'network-period-{index}/';tree.append(period)
 shutil.copytree(out/f'media/network-period-{index%2}',out/f'media/network-period-{index}')
tree.set('mediaPresentationDuration','PT80S');ET.register_namespace('',ns);ET.indent(tree,space='  ')
manifest.write_bytes(ET.tostring(tree,encoding='utf-8',xml_declaration=True))
assets=sorted(x for x in (out/'media').rglob('*') if x.is_file() and x.name!='SHA256SUMS')
(out/'media/SHA256SUMS').write_text(''.join(f'{hashlib.sha256(x.read_bytes()).hexdigest()}  ./{x.relative_to(out/"media")}\\n' for x in assets))
fixture.update(durationSeconds=80,periodCount=20,assetCount=len(assets),base40sManifestSha256=fixture['manifestSha256'],manifestSha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),inventorySha256=hashlib.sha256((out/'media/SHA256SUMS').read_bytes()).hexdigest())
(out/'fixture.json').write_text(json.dumps(fixture,indent=2)+'\\n')
media=fixture['manifestSha256']'''
assert needle in s;s=s.replace(needle,extra)
s+='''
samples=[]
for line in (out/'capture.log').read_text().splitlines():
 match=re.search(r'YL_ABR_SAMPLE=(\\{.*\\})',line)
 if match:samples.append(json.loads(match[1]))
last=max((x.get('positionUs',0) for x in samples),default=0)
validation={'expectedDurationUs':80000000,'maximumObservedPositionUs':last,'fullProgrammeObserved':last>=79500000,'profileUnchanged':True,'comparedTo40SecondRuns':False}
(out/'extended-program-validation.json').write_text(json.dumps(validation,indent=2)+'\\n')
assert validation['fullProgrammeObserved'],validation
'''
Path('/private/tmp/p04_abr_extended.py').write_text(s)
