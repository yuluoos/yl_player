from pathlib import Path
import json,tarfile,hashlib,io,re,subprocess
root=Path('/Users/yy2021_8689/.codex/worktrees/p04-weak-network-live/yl_player')
work=root/'.superpowers/sdd/2026-09-26-remaining-04-abr-live';logs=work/'logs'
dest=root/'docs/superpowers/reports/evidence/2026-10-19-p04-native';dest.mkdir(parents=True,exist_ok=True)
entries=[];manifest=[]
for p in sorted(logs.rglob('*')):
 if not p.is_file() or any(v in p.relative_to(logs).parts for v in ['media','__pycache__']):continue
 if p.suffix not in ['.log','.json','.jsonl','.txt','.yml','.xml'] and p.name!='exit-code':continue
 entries.append((p,'logs/'+str(p.relative_to(logs))))
for name in ['progress.md','final-review.md']:entries.append((work/name,name))
for name in ['p04_abr_run.py','p04_abr_extended.py','p04_make_extended_driver.py','p04_http_live_run.py','p04_live_run_v2.py','p04_live_trace.py','p04_rtmp_cases.py','p04_rtmp_recovery.py','p04_device_live.py','p04_device_live_repeat.py','p04_device_trace.py','p04_device_trace4.py','p04_device_trace5.py','p04_device_exclusive.py','p04_restore_iproxy.py','p04_finalize_evidence.py','p04_archive.py']:
 p=Path('/private/tmp')/name
 if p.exists():entries.append((p,'launchers/'+name))
peers=['app-bhcnh7sm','app-xdju75nm','app-mghd9he4']
for p in logs.glob('iphone-rtmp*runner.log'):
 match=re.search(r'RTMP acceptance logs: /private/tmp/yl-rtmp-foundation/(app-[a-z0-9_]+)',p.read_text())
 if match and match[1] not in peers:peers.append(match[1])
for name in peers:
 for p in sorted((Path('/private/tmp/yl-rtmp-foundation')/name).glob('*')):
  if p.is_file():entries.append((p,'rtmp-peers/'+name+'/'+p.name))
for name in ['p04-rtmp-current.log','p04-libusbmuxd-install.log','p04-iproxy-backup.json','p04-iproxy-restored.json']:
 p=Path('/private/tmp')/name
 if p.exists():entries.append((p,'environment/'+name))
with tarfile.open(dest/'captures.tar.gz','w:gz') as tar:
 for p,name in entries:
  raw=p.read_bytes();data=raw;redacted=False
  if p.suffix=='.log':
   text=data.decode('utf-8',errors='replace');lines=text.splitlines(keepends=True);out=[]
   # Verbose Flutter emits all device processes. Only retain our test Runner,
   # and remove unrelated installed-app rows and signing account emails.
   for line in lines:
    if ('Runner.app/' not in line and
        (re.search(r'\s\d+\s+/.*(?:\.app/|/usr/|/System/|/Applications/)',line) or
         '/private/var/containers/Bundle/Application/' in line or
         '/private/var/mobile/Containers/' in line)):
     redacted=True;continue
    cleaned=re.sub(r'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}', '[redacted-account]',line)
    redacted |= cleaned!=line;out.append(cleaned)
   data=''.join(out).encode()
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=int(p.stat().st_mtime);tar.addfile(info,io.BytesIO(data))
  manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'originalSha256':hashlib.sha256(raw).hexdigest(),'redactedUnrelatedDeviceInventoryOrAccount':redacted})
(dest/'files.json').write_text(json.dumps(manifest,indent=2)+'\n')
records=[]
for folder in sorted(logs.iterdir()):
 if not folder.is_dir():continue
 capture=folder/'capture.log'
 if not capture.exists():continue
 record={'runId':folder.name,'capture':'logs/'+folder.name+'/capture.log','exactCommandRecorded':(folder/'command.json').exists(),'sourceIdentityRecorded':(folder/'source-identity.json').exists()}
 results=[]
 for line in capture.read_text(errors='replace').splitlines():
  match=re.search(r'YL_(LIVE|ABR)_RESULT=(\{.*\})',line)
  if match:
   try:results.append(json.loads(match[2]))
   except json.JSONDecodeError:pass
 record['results']=results
 code=folder/'exit-code'
 if code.exists():record['processExitCode']=code.read_text().strip()
 summary=folder/'summary-v2.json'
 if not summary.exists():summary=folder/'summary.json'
 if summary.exists():record['summary']=json.loads(summary.read_text())
 records.append(record)
(dest/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
paths=subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
sources={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths if Path(p).suffix in {'.dart','.swift','.kt','.py','.yaml','.sh'} and (root/p).is_file()}
(dest/'source-identity.json').write_text(json.dumps({'base':'c218d52bc28c367286d246fd0b8ef1a4fafd281a','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sources':sources},indent=2)+'\n')
with tarfile.open(dest/'captures.tar.gz') as tar:
 for m in manifest:assert hashlib.sha256(tar.extractfile(m['path']).read()).hexdigest()==m['sha256']
print(json.dumps({'files':len(manifest),'runs':len(records),'archiveSha256':hashlib.sha256((dest/'captures.tar.gz').read_bytes()).hexdigest(),'archiveBytes':(dest/'captures.tar.gz').stat().st_size}))
